"""Apply verified generation and visible-provenance revisions with bounded rollback."""
import argparse, ast, hashlib, importlib.util, json, os, shlex, sqlite3, time, urllib.request
from pathlib import Path
BASE=Path('/mnt/d/KDDeployment')
REPORT=BASE/'case-signal-generation-patch-v5.json'
TARGET=BASE/'CaseSignal/releases/20260909-v1/summaries.py'
ORIGINAL='aea33e2a350990a1fd6c10729a8b0cd5fec40534eed89e5b2c66ff93dbcc334f'
UI_TARGET=TARGET.parent/'static/app.js'
UI_ORIGINAL='fda39f377b9c4e023d45f32b24c07cc7c80f0b2bde9e74daf30b2b87cd92cbf9'
STATE=Path('/var/lib/case-signal/case-signal.sqlite3')
def require(ok,message):
    if not ok:raise RuntimeError(message)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()

def verified_file(name,candidate,target,expected,candidate_sha,backup):
    require(candidate.is_file() and not candidate.is_symlink(),name+' candidate unavailable.')
    raw=candidate.read_bytes()
    require(0<len(raw)<100000 and digest(raw)==candidate_sha,name+' candidate identity mismatch.')
    require(target.is_file() and not target.is_symlink() and not any(p.is_symlink() for p in target.parents),name+' installed path is not a regular retained release path.')
    original=target.read_bytes()
    require(digest(original)==expected,name+' installed source differs from the accepted original.')
    require(not backup.exists() and not backup.is_symlink(),name+' original backup already exists; inspect prior work.')
    return {'name':name,'target':target,'backup':backup,'original':original,'raw':raw,
            'original_sha256':expected,'candidate_sha256':candidate_sha,'replaced':False}

def exclusive_bytes(path,raw):
    with path.open('xb') as output:
        output.write(raw);output.flush();os.fsync(output.fileno())
    path.chmod(0o644)

def install_files(files,report,save):
    # Back up both originals before replacing either runtime file.
    for item in files:
        require(digest(item['target'].read_bytes())==item['original_sha256'],item['name']+' changed before replacement.')
        exclusive_bytes(item['backup'],item['original'])
    for item in files:
        require(digest(item['target'].read_bytes())==item['original_sha256'],item['name']+' changed before replacement.')
        temporary=item['target'].with_suffix(item['target'].suffix+'.patch')
        exclusive_bytes(temporary,item['raw'])
        os.replace(temporary,item['target'])
        # Set the in-memory flag before journal I/O so partial writes remain recoverable.
        item['replaced']=True
        report['files'][item['name']]['replaced']=True
        save()

def restore_files(files):
    results={}
    for item in files:
        try:
            current=digest(item['target'].read_bytes())
            if item['replaced'] and current!=item['original_sha256']:
                require(current==item['candidate_sha256'],item['name']+' changed after replacement; automatic restore refused.')
                restored=item['target'].with_suffix(item['target'].suffix+'.restore')
                exclusive_bytes(restored,item['original'])
                os.replace(restored,item['target'])
            require(digest(item['target'].read_bytes())==item['original_sha256'],item['name']+' original did not verify after restore.')
            results[item['name']]={'original_restored':True}
        except Exception as exc:
            results[item['name']]={'original_restored':False,'error':type(exc).__name__+': '+str(exc)[:300]}
    return results

def verify_served_ui(expected):
    url='http://127.0.0.1:8096/static/app.js'
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(urllib.request.Request(url,headers={'Cache-Control':'no-cache'}),timeout=15) as response:
        require(response.status==200 and response.geturl()==url,'UI verification did not return the local static asset.')
        raw=response.read(100001)
    require(len(raw)<100000 and digest(raw)==expected,'Served UI does not match the verified candidate.')
    return digest(raw)

def logical_state():
    require(STATE.is_file() and not STATE.is_symlink(),'Expected existing Case Signal SQLite state.')
    db=sqlite3.connect(STATE.as_uri()+'?mode=ro',uri=True,timeout=10)
    try:
        db.execute('PRAGMA query_only=ON')
        result={}
        for table in ('runs','summaries'):
            rows=db.execute('SELECT * FROM '+table+' ORDER BY id').fetchall()
            require(len(rows)<=10000,'Case Signal state exceeds patch inspection bound.')
            schema=db.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone()
            result[table]={'count':len(rows),'rows_sha256':digest(canonical(rows)),'schema_sha256':digest(canonical(schema))}
        return result
    finally:db.close()

def wait_ready(deployer):
    deadline=time.monotonic()+30
    while True:
        try:
            require(deployer.request('/api/health')['status']=='ok','Application not ready.')
            require(deployer.command(['systemctl','is-active','case-signal-demo.service'])=='active','Case Signal service is not active.')
            return
        except Exception:
            if time.monotonic()>deadline:raise
            time.sleep(1)
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--candidate',type=Path,required=True)
    parser.add_argument('--sha256',required=True)
    parser.add_argument('--ui-candidate',type=Path,required=True)
    parser.add_argument('--ui-sha256',required=True)
    args=parser.parse_args()
    require(os.geteuid()==0 and not REPORT.exists(),'New owner-root patch execution required.')
    files=[verified_file('summaries',args.candidate,TARGET,ORIGINAL,args.sha256,BASE/'case-signal-summaries-original-v1.py'),
           verified_file('ui',args.ui_candidate,UI_TARGET,UI_ORIGINAL,args.ui_sha256,BASE/'case-signal-app-original-v1.js')]
    ast.parse(files[0]['raw'])
    require(b'const notice = summary.notice' in files[1]['raw'] and b'${escape(notice)}</p>' in files[1]['raw'],
            'UI candidate must visibly render the escaped summary notice.')
    diagnostic=json.loads((BASE/'case-signal-generation-candidate-v5.json').read_text())
    require(diagnostic.get('complete') is True and diagnostic.get('candidate_sha256')==args.sha256,'This exact candidate must pass actual model validation before installation.')
    summary=diagnostic.get('summary',{})
    require(diagnostic.get('case_id')=='CS-2048' and summary.get('case_id')=='CS-2048' and summary.get('mode')=='generated'
            and summary.get('generation_contract')=='case-synopsis-hybrid-v5' and summary.get('requires_review') is True
            and summary.get('overview') and summary.get('findings'),'Candidate report lacks the validated CS-2048 generation result.')
    provenance=summary.get('field_provenance',{})
    require(isinstance(provenance,dict) and provenance.get('overview')=='model_synthesis'
            and provenance.get('findings')=='exact_source_excerpts' and provenance.get('next_actions')=='explicit_source_actions',
            'Candidate report lacks explicit hybrid provenance for its overview, findings and actions.')
    require(isinstance(summary.get('notice'),str) and 'overview' in summary['notice'].lower() and 'source' in summary['notice'].lower(),
            'Candidate hybrid provenance must also be explained in the displayed review notice.')
    require(summary.get('snapshot_sha256')==diagnostic.get('snapshot_sha256') and isinstance(diagnostic.get('elapsed_seconds'),(int,float))
            and 0<diagnostic['elapsed_seconds']<300,'Candidate report lacks bounded actual-generation and source identity evidence.')
    response=json.loads(diagnostic.get('raw_response',''))
    require(response.get('choices') and response['choices'][0].get('finish_reason')=='stop'
            and response['choices'][0].get('message',{}).get('content'),'Candidate model response was not complete.')
    model_endpoint=None
    for line in Path('/etc/systemd/system/case-signal-demo.service').read_text().splitlines():
        if line.startswith('Environment='):
            for item in shlex.split(line.partition('=')[2]):
                key,_,value=item.partition('=')
                if key=='KD_LLM_URL':model_endpoint=value
    require(model_endpoint and diagnostic.get('endpoint')==model_endpoint,'Candidate was not tested against the configured local model endpoint.')
    spec=importlib.util.spec_from_file_location('case_patch_deployer',BASE/'case-signal-deploy-v1.py')
    deployer=importlib.util.module_from_spec(spec);spec.loader.exec_module(deployer)
    before=deployer.preservation.snapshot()
    activity=deployer.container_activity()
    require(deployer.request('/api/health')['status']=='ok','New application unavailable before patch.')
    detail=deployer.request('/api/cases/CS-2048')
    current_snapshot=digest(canonical([detail['case']['payload_sha256'],[(s['id'],s['payload_sha256']) for s in detail['sources']]]))
    require(current_snapshot==diagnostic['snapshot_sha256'],'Candidate summary does not identify the currently served exact KD source snapshot.')
    require(before['databases'].get('CASE_SIGNAL_DEMO',{}).get('count')==35,'Expected 35 dedicated case records before patch.')
    own_before=logical_state()
    report={'complete':False,'intent_at':time.time(),'original_sha256':ORIGINAL,'candidate_sha256':args.sha256,
            'ui_original_sha256':UI_ORIGINAL,'ui_candidate_sha256':args.ui_sha256,
            'files':{item['name']:{'original_sha256':item['original_sha256'],'candidate_sha256':item['candidate_sha256'],'replaced':False} for item in files},
            'candidate_snapshot_sha256':current_snapshot,'case_state_before':own_before,'case_database_before':before['databases']['CASE_SIGNAL_DEMO']}
    def save():
        temporary=REPORT.with_suffix('.json.tmp')
        fd=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
        with os.fdopen(fd,'w',encoding='utf-8') as output:
            json.dump(report,output,indent=2);output.flush();os.fsync(output.fileno())
        os.replace(temporary,REPORT);REPORT.chmod(0o600)
    save()
    try:
        install_files(files,report,save)
        deployer.command(['systemctl','restart','case-signal-demo.service'])
        wait_ready(deployer)
        after=deployer.preservation.snapshot()
        report['preservation']=deployer.compare(before,after)
        require(after['databases']['CASE_SIGNAL_DEMO']==before['databases']['CASE_SIGNAL_DEMO'],'Dedicated case references changed during generation patch.')
        report['case_state_after']=logical_state()
        require(report['case_state_after']==own_before,'Retained Case Signal runs or summaries changed across patch restart.')
        require(deployer.container_activity()==activity,'Existing container states changed.')
        for item in files:
            require(digest(item['target'].read_bytes())==item['candidate_sha256'],item['name']+' installed source hash changed.')
        report['served_ui_sha256']=verify_served_ui(args.ui_sha256)
        report.update(complete=True,completed_at=time.time(),container_activity_unchanged=True)
        save()
    except Exception as exc:
        report['complete']=False
        report['error']=type(exc).__name__+': '+str(exc)[:300]
        if any(item['replaced'] for item in files):
            report['rollback']={'attempted_at':time.time(),'complete':False}
            try:
                report['rollback']['files']=restore_files(files)
                # One restart attempt, even after a partial replacement; never touch Fleet or KD.
                deployer.command(['systemctl','restart','case-signal-demo.service'])
                wait_ready(deployer)
                require(all(item['original_restored'] for item in report['rollback']['files'].values()),'One or more originals could not be restored.')
                report['rollback']['served_ui_sha256']=verify_served_ui(UI_ORIGINAL)
                rollback_snapshot=deployer.preservation.snapshot()
                report['rollback']['preservation']=deployer.compare(before,rollback_snapshot)
                require(rollback_snapshot['databases']['CASE_SIGNAL_DEMO']==before['databases']['CASE_SIGNAL_DEMO'],'Dedicated case references differ after rollback.')
                require(logical_state()==own_before,'Retained Case Signal state differs after rollback.')
                require(deployer.container_activity()==activity,'Existing container states differ after rollback.')
                report['rollback'].update(complete=True,completed_at=time.time(),original_restored=True)
            except Exception as rollback_error:
                report['rollback']['error']=type(rollback_error).__name__+': '+str(rollback_error)[:300]
        save()
        print(json.dumps({'complete':False,'report':str(REPORT),'error':report['error'],'rollback':report.get('rollback')}),flush=True)
        raise
    print(json.dumps({'complete':report['complete'],'report':str(REPORT),'candidate_sha256':args.sha256,
                      'ui_candidate_sha256':args.ui_sha256,'served_ui_sha256':report['served_ui_sha256'],
                      'case_records':35,'retained_state_unchanged':True,'container_activity_unchanged':True}),flush=True)
if __name__=='__main__':main()
