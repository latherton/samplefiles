# Case Signal: hybrid summary patch v5

Source-only overlay for base release `20260909-v1`. The base archive remains unchanged (SHA-256 `7552c1f8ac4824a2edc251cbc8df1dd049e6e5f9297830d51f0de93845cde28b`).

The patch replaces two runtime files:
- `summaries.py`: the configured local model writes a concise current-case overview. Findings and recorded next actions are exact source excerpts. The response retains explicit field provenance, source citations and the complete source snapshot. Model errors remain explicit; no substitute output is presented as AI.
- `static/app.js`: displays the AI/source distinction, escapes the review notice, labels recorded actions and counts retained sources accurately.

The internal generation contract is `case-synopsis-hybrid-v5`. Source evidence is untrusted input. Citations and exact quotations are checked, while model interpretation remains subject to human review. Demonstration records are synthetic; the separate real AppWorks HTTP adapter still requires configuration and validation against the intended tenant.

`apply_generation_patch.py` is a bounded helper for the matching existing demonstration layout. It is not a standalone installer. It requires exact original file identities, candidate hashes, and a separately retained successful native model diagnostic for the current source snapshot. Those private receipts are not distributed in this archive. Review the candidate's meaning before applying it.

The helper preserves both original files, journals the two-file replacement, restarts only Case Signal, verifies both installed files and the HTTP-served UI hash, and compares retained application and shared-backend state. It attempts bounded restoration on a post-replacement failure. Inspect existing intents and receipts instead of replaying an uncertain operation.

`manifest.json` records the exact payload hashes. The ZIP preserves source bytes and line endings. It contains application/helper source and these instructions only: no credentials, configuration secrets, customer records, runtime state, browser/session material, model responses or execution receipts.
