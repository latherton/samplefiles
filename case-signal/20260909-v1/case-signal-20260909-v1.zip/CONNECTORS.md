# Case Signal source connectors

Case Signal currently demonstrates synthetic records through the shared KD backend. Its AppWorks adapter executes real, read-only HTTP GET requests with configured authentication, field mappings, child collections and pagination. Passing the local HTTP tests is evidence of connector behavior; no actual AppWorks instance or OTDS token exchange has been verified.

The source mode is explicit. `CASE_SIGNAL_SOURCE=fixture` loads the bundled records with `synthetic=true` and `source_system= Synthetic fixture`. `CASE_SIGNAL_SOURCE=appworks` loads the file named by `APPWORKS_CONFIG` and uses its configured credential environment variable. An AppWorks error never switches to fixtures.

## Connection configuration

Copy [config/appworks.example.json](config/appworks.example.json) to an operator-owned configuration file, such as `/etc/case-signal/appworks.json`. Replace every `REPLACE_...` value with information from the actual AppWorks application's API documentation or inspected response. The example is intentionally not a working customer endpoint. No credential belongs in this JSON file.

| Setting | Actual behavior |
| --- | --- |
| `product_mode` | Must be `appworks_entity_rest` |
| `schema_map_version` | Identifies the exact mapping retained with acquired records |
| `base_url` | HTTPS origin plus approved API service path; no user information, query or fragment |
| `entity_namespace`, `entity_name` | URL-encoded values substituted into endpoint templates |
| `case_ids` | Explicit source IDs; maximum 100; returned IDs must match requested IDs |
| `item_path_template` | Configured item route, with `{id}`, `{namespace}` and `{entity}` placeholders |
| `property_map` | JSON Pointer for each normalized case field; `id` and `title` are required |
| `required_fields` | Additional mapped case fields that must have nonempty scalar values |
| `relations` | Named child collections with their own route and field mapping; none are assumed |
| `auth` | `header`, credential `env` name and optional `prefix`; allowed headers are `SAMLart`, `Authorization` and `X-Api-Key` |
| `timeout_seconds`, `max_pages` | Request timeout and complete-pagination bounds; defaults are 20 seconds and 10 pages |

With a base such as `https://host/home/organization/app/entityRestService`, use the **relative** item path `api/{namespace}/entities/{entity}/items/{id}`. A leading slash means an origin-root path and would discard the service prefix. The client confines reads to the exact configured origin and API path, rejects redirects and credential-bearing URL queries, and requests JSON with `X-Requested-With: XMLHttpRequest`. Plain HTTP is allowed only for explicit loopback testing with `allow_http_local: true`.

The published 22.4 example supports `Identity.Id` and custom `Properties`. It does not establish the title, status, owner, timestamps, notes or document names in your application. All `REPLACE_..._PROPERTY` values must therefore be mapped. Missing optional values remain unavailable; status and priority display `Unknown` / `Unspecified`. The example requires `description` so a missing case narrative fails visibly. Remove that requirement only when another explicitly mapped evidence collection supplies the intended case content.

## Lists and child collections

Start with explicit `case_ids`. Add list configuration only after obtaining the actual list route and response schema. To hydrate full case records from an ID list, remove `case_ids` and supply:

```json
{
  "list_path": "REPLACE_WITH_OBSERVED_RELATIVE_LIST_ROUTE",
  "list_items_pointer": "/REPLACE_ITEMS_ARRAY",
  "list_id_pointer": "/Identity/Id",
  "next_link_pointer": "/REPLACE_NEXT_LINK",
  "list_contains_items": false
}
```

Set `list_contains_items: true` only if each list row already contains the fields required by `property_map`. `next_link_pointer` is optional; configure it when the API paginates. Its value must resolve to a URL string or an empty/null final-page value. The connector follows safe relative links, detects cycles and fails if the page limit leaves acquisition incomplete. It does not invent offset parameters or discover pagination conventions.

Add relationships using their actual supported paths. This is a mapping template, **not a vendor-defined notes endpoint**:

```json
{
  "relations": {
    "notes": {
      "path_template": "api/{namespace}/entities/{entity}/items/{id}/REPLACE_NOTES_ROUTE",
      "items_pointer": "/REPLACE_ITEMS_ARRAY",
      "next_link_pointer": "/REPLACE_NEXT_LINK",
      "kind": "note",
      "field_map": {
        "id": "/REPLACE_NOTE_ID",
        "case_id": "/REPLACE_PARENT_CASE_ID",
        "title": "/REPLACE_TITLE",
        "text": "/REPLACE_TEXT",
        "updated_at": "/REPLACE_UPDATED_AT"
      }
    }
  }
}
```

Each child requires an ID, title and text; a mapped parent case ID must match. Configure separate collections for tasks, events or document text so their source types remain clear. Raw binary attachment download and content extraction are not implemented by this JSON adapter; provide an approved text-bearing source operation or add and verify an attachment-specific adapter. Each case is bounded to 50 evidence records including its primary case record. Individual responses are limited to 4 MiB. An incomplete pull must not replace the active source inventory.

## Validate before switching the running service

Obtain the actual product/build, organization, namespace/entity names, read-only record scope, API responses, credential flow and read permissions from the AppWorks owner. Provision the credential through the server's approved secret handling; do not paste it into command arguments, URLs, screenshots or a committed file. The example expects a valid `APPWORKS_SAMLART`; it does not exchange an OTDS ticket for that artifact. Authentication expires independently of the demonstration web page.

From the Case Signal application directory, set these non-secret environment values and provide the credential environment variable separately:

```sh
export CASE_SIGNAL_SOURCE=appworks
export APPWORKS_CONFIG=/etc/case-signal/appworks.json
python3 -c "from sources import source_from_env; rows=source_from_env().pull(); print({'cases':len(rows),'evidence_records':sum(len(c['sources']) for c in rows)})"
```

This checks the configured source without indexing into KD or printing source records. Compare the acquired IDs, mappings, children and counts against the selected AppWorks records through an appropriate private inspection. Confirm negative cases as well as a successful pull. The synthetic contract suite can be run independently:

```sh
python3 -m unittest discover -s tests -p test_appworks_http.py -v
```

For the installed remote service, configure a dedicated `case-signal-demo.service` systemd drop-in with `CASE_SIGNAL_SOURCE=appworks`, `APPWORKS_CONFIG` and a root-readable `EnvironmentFile` containing the approved auth variable. Keep secrets out of the unit's literal `Environment=` lines. Ensure the service account can read the non-secret mapping file. Use the existing service's working directory and preserve its KD endpoints, `/var/lib/case-signal` state directory and port 8096.

After the standalone source check passes, reload the unit configuration and restart **only** Case Signal:

```sh
sudo systemctl daemon-reload
sudo systemctl restart case-signal-demo.service
```

Open the new demo's source view, confirm the source mode, run **Sync**, and inspect its receipt through successful KD exact readback. Verify a selected case's source excerpts and citations. Check both Case Signal on port 8096 and Fleet Evidence on port 8095; leave Fleet Evidence's unit, retained cases, index references and paused synthetic feed intact. Restarting Case Signal does not itself pull records or prove source synchronization.

To return to the synthetic demo, set this service's `CASE_SIGNAL_SOURCE=fixture`, restart only this service, and explicitly sync the fixture. Historical KD/source/summary snapshots remain retained; do not delete them to switch modes.

## Evidence and limits

The real HTTP contract suite passed 23 checks on September 9, covering transport/authentication, mapping, paginated cases/children, errors, identity and URL scoping, partial-pull bounds and synthetic labeling. The current demo does not establish production ACL synchronization, token renewal or workflow write-back. Confirm these separately before connecting protected operational content.

Source references: [OpenText's 22.4 Entity REST example](https://forums.opentext.com/forums/developer/discussion/311337/angular-appworks-noob), [Process Automation developer product page](https://developer.opentext.com/ce/products/appworks-platform), and the [workspace research and acceptance contract](../../docs/appworks-integration-research-2026-09-09.md). The linked release guide and authentication KB content were not obtainable during research; their presence is not a compatibility verification.
