#!/usr/bin/env python3
"""Case Signal: same KD backend, separate case workflow and durable state."""
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
from pathlib import Path
import threading
import urllib.parse
import urllib.request

from indexer import Indexer, public_run
from kd_client import KDClient, KDError, DATABASE
from model import read_cases, source_snapshot, decode_hit
from sources import SourceError, now, source_from_env
from store import Store
from summaries import extractive, generated, export_html

ROOT = Path(__file__).resolve().parent


class App:
    def __init__(self, client=None, source=None, store=None):
        self.client = client
        self.source = source or source_from_env()
        self.store = store or Store(os.getenv('CASE_SIGNAL_STATE_DIR', str(ROOT / 'state')))
        self.sync_lock = threading.Lock()
        self.sync_thread = None

    def kd(self):
        return self.client or KDClient()

    def all_cases(self):
        client = self.kd()
        if DATABASE not in client.databases():
            return [], None
        return read_cases(client)

    def queue(self, q='', status='', priority=''):
        if len(q) > 256:
            raise ValueError('Search must be at most 256 characters.')
        cases, manifest = self.all_cases()
        if q.strip():
            current_references = {case['kd_reference']: case['payload_sha256'] for case in cases}
            current_references.update({source['kd_reference']: source['payload_sha256'] for case in cases for source in case['sources']})
            result = self.kd().query(q, limit=10000)
            if result['total'] != len(result['hits']):
                raise KDError('Search exceeded the bounded case result limit.', 'kd_results_incomplete')
            ids = set()
            for hit in result['hits']:
                item = decode_hit(hit)
                if current_references.get(item['kd_reference']) != item['payload_sha256']:
                    continue
                if item['record_type'] == 'source':
                    ids.add(item['case_id'])
                elif item['record_type'] == 'case':
                    ids.add(item['id'])
            cases = [case for case in cases if case['id'] in ids]
        rows = []
        for case in cases:
            if status and case['status'].casefold() != status.casefold() or priority and case['priority'].casefold() != priority.casefold():
                continue
            row = {k: case[k] for k in ['id', 'title', 'status', 'priority', 'owner', 'category', 'updated_at', 'source_system']}
            row.update(source_count=len(case['sources']), summary_preview=case['description'], synthetic=case.get('synthetic', False))
            rows.append(row)
        rows.sort(key=lambda c: c['updated_at'], reverse=True)
        rows.sort(key=lambda c: {'urgent': 0, 'high': 1, 'normal': 2}.get(c['priority'].lower(), 3))
        return {'cases': rows, 'total': len(rows), 'origin': 'Knowledge Discovery · ' + DATABASE,
                'source_mode': manifest.get('source_mode') if manifest else self.source.mode}

    def find(self, ident):
        cases, _ = self.all_cases()
        case = next((case for case in cases if case['id'] == ident), None)
        if case is None:
            raise KeyError('Case was not found in the current KD source manifest.')
        return case

    def detail(self, ident):
        case = self.find(ident)
        snapshot = source_snapshot(case)
        summary = self.store.latest_summary(ident, snapshot['sha256'])
        sources = [{k: v for k, v in source.items() if k != 'original_record'} for source in case['sources']]
        return {'case': {k: v for k, v in case.items() if k not in {'sources', 'source_refs'}},
                'sources': sources, 'timeline': [{'at': s['updated_at'], 'title': s['title'], 'text': s['text'], 'source_id': s['id']} for s in sources],
                'summary': summary, 'sync': public_run(self.store.runs()[0]) if self.store.runs() else {'status': 'not_synced'}}

    def summarize(self, ident, mode):
        if mode not in {'extractive', 'generated'}:
            raise ValueError('Choose extractive or generated summary mode.')
        case = self.find(ident)
        summary, snapshot = generated(case) if mode == 'generated' else extractive(case)
        self.store.save_summary(summary, snapshot)
        return {'summary': summary}

    def export(self, ident):
        case = self.find(ident)
        snapshot = source_snapshot(case)
        summary = self.store.latest_summary(ident, snapshot['sha256'])
        if summary is None:
            summary, snapshot = extractive(case)
            self.store.save_summary(summary, snapshot)
        return export_html(case, summary)

    def health(self):
        try:
            names = self.kd().databases()
            kd = {'connected': True, 'database': DATABASE, 'indexed': DATABASE in names,
                  'message': 'Content responds; dedicated case database ' + ('is present.' if DATABASE in names else 'is not yet indexed.')}
        except KDError as exc:
            kd = {'connected': False, 'database': DATABASE, 'message': str(exc)}
        return {'app': 'Case Signal', 'status': 'ok' if kd['connected'] else 'degraded', 'kd': kd, 'checked_at': now()}

    def source_info(self):
        public = self.source.public()
        runs = self.store.runs()
        latest = runs[0] if runs else None
        verified = next((r for r in runs if r['status'] == 'verified' and r['source_mode'] == self.source.mode), None)
        source = {k: v for k, v in public.items() if k not in {'mapping', 'requirements'}}
        source.update(last_sync=verified.get('completed_at') if verified else None,
                      status=('pending' if self.sync_thread and self.sync_thread.is_alive() else latest['status'] if latest else 'not_synced'),
                      message=latest.get('message') if latest else 'Run a source sync to populate the dedicated KD case database.')
        if self.source.mode == 'appworks' and verified:
            source['instance_verified'] = True
        return {'source': source, 'mapping': public['mapping'], 'runs': [public_run(r) for r in runs[:20]], 'requirements': public['requirements']}

    def bootstrap(self):
        health = self.health()
        stats = {'cases': 0, 'open': 0, 'urgent': 0, 'sources': 0}
        if health['kd']['connected']:
            try:
                cases, manifest = self.all_cases()
                stats = {'cases': len(cases), 'open': sum(c['status'].lower() != 'closed' for c in cases),
                         'urgent': sum(c['priority'].lower() == 'urgent' for c in cases), 'sources': sum(len(c['sources']) for c in cases)}
            except KDError as exc:
                health['kd'].update(message=str(exc), indexed=False)
        fleet_url = os.getenv('FLEET_EVIDENCE_URL', 'http://127.0.0.1:8095')
        try:
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(fleet_url + '/api/health', timeout=2) as response:
                fleet_available = response.status == 200
        except (OSError, ValueError):
            fleet_available = False
        return {'app': {'name': 'Case Signal', 'version': '20260909-v1'}, 'source': self.source_info()['source'],
                'kd': health['kd'], 'generation': {'configured': bool(os.getenv('KD_LLM_URL')), 'model': os.getenv('KD_LLM_MODEL', 'kd-local-qwen')},
                'fleet': {'url': fleet_url, 'available': fleet_available}, 'stats': stats, 'last_updated': now()}

    def sync(self, resume=False):
        if not self.sync_lock.acquire(blocking=False):
            raise KDError('Source synchronization is already running.', 'sync_busy')
        pending = next((r for r in self.store.runs() if r['status'] != 'verified' and r.get('jobs')), None)
        if pending and not resume:
            self.sync_lock.release()
            raise KDError('A prior indexing operation remains incomplete. Resume its retained receipt.', 'index_pending')
        if pending and any(j['index_id'] is None or j.get('commit') and j['commit']['index_id'] is None for j in pending['jobs']):
            self.sync_lock.release()
            raise KDError('A prior native index receipt is uncertain; manual receipt reconciliation is required.', 'index_receipt_uncertain')
        def worker():
            try:
                Indexer(self.kd(), self.store, self.source).execute(resume)
            except Exception:
                pass  # The sanitized durable run is the public error record; never log source/auth bodies.
            finally:
                self.sync_lock.release()
        self.sync_thread = threading.Thread(target=worker, name='case-signal-sync', daemon=True)
        self.sync_thread.start()
        return {'status': 'pending', 'message': 'Source sync started. Follow the retained source run for verified KD readback.'}


class Handler(BaseHTTPRequestHandler):
    server_version = 'CaseSignal/1'

    def log_message(self, format, *args):
        pass

    @property
    def app(self):
        return self.server.app

    def send(self, status, payload, content_type='application/json; charset=utf-8', disposition=None):
        raw = json.dumps(payload).encode() if content_type.startswith('application/json') else payload.encode() if isinstance(payload, str) else payload
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'")
        if disposition:
            self.send_header('Content-Disposition', disposition)
        self.end_headers()
        self.wfile.write(raw)

    def error(self, exc):
        code = getattr(exc, 'code', 'invalid_request')
        if isinstance(exc, KeyError):
            status, code, message = 404, 'not_found', str(exc.args[0])
        elif isinstance(exc, (KDError, SourceError)):
            status = 409 if code in {'sync_busy', 'generation_busy', 'index_pending', 'index_receipt_uncertain'} else 503
            message = str(exc)
        elif isinstance(exc, (ValueError, json.JSONDecodeError)):
            status, message = 400, str(exc)
        else:
            status, code, message = 500, 'internal_error', 'The request could not be completed. Retained case and sync state has not been discarded.'
        self.send(status, {'error': code, 'message': message})

    def do_GET(self):
        try:
            parsed = urllib.parse.urlsplit(self.path)
            path = urllib.parse.unquote(parsed.path)
            query = urllib.parse.parse_qs(parsed.query)
            if path == '/api/health':
                self.send(200, self.app.health())
            elif path == '/api/bootstrap':
                self.send(200, self.app.bootstrap())
            elif path == '/api/cases':
                self.send(200, self.app.queue(*(query.get(k, [''])[0] for k in ['q', 'status', 'priority'])))
            elif path == '/api/sources':
                self.send(200, self.app.source_info())
            elif path.startswith('/api/cases/'):
                rest = path[len('/api/cases/'):]
                if rest.endswith('/export'):
                    ident = rest[:-len('/export')]
                    self.send(200, self.app.export(ident), 'text/html; charset=utf-8', 'attachment; filename="case-signal-brief.html"')
                else:
                    self.send(200, self.app.detail(rest))
            elif path == '/' or path.startswith('/static/'):
                static = (ROOT / 'static').resolve()
                target = (static / ('index.html' if path == '/' else path[8:])).resolve()
                if not target.is_relative_to(static) or not target.is_file():
                    raise KeyError('Resource was not found.')
                self.send(200, target.read_bytes(), mimetypes.guess_type(target.name)[0] or 'application/octet-stream')
            else:
                raise KeyError('Endpoint was not found.')
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as exc:
            self.error(exc)

    def do_POST(self):
        try:
            # The demo binds loopback; reject cross-origin browser writes and unexpected content types.
            origin = self.headers.get('Origin')
            if origin and urllib.parse.urlsplit(origin).netloc != self.headers.get('Host'):
                raise ValueError('Cross-origin write requests are not accepted.')
            if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                raise ValueError('Use application/json for a source or summary request.')
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 <= length <= 4096:
                raise ValueError('Request body exceeds the demo limit.')
            data = json.loads(self.rfile.read(length) or b'{}')
            if not isinstance(data, dict):
                raise ValueError('Request body must be a JSON object.')
            path = urllib.parse.unquote(urllib.parse.urlsplit(self.path).path)
            if path == '/api/sync':
                self.send(202, self.app.sync(data.get('resume') is True))
            elif path.startswith('/api/cases/') and path.endswith('/summarize'):
                self.send(200, self.app.summarize(path[len('/api/cases/'):-len('/summarize')], data.get('mode', 'extractive')))
            else:
                raise KeyError('Endpoint was not found.')
        except Exception as exc:
            self.error(exc)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', default=os.getenv('CASE_SIGNAL_HOST', '127.0.0.1'))
    parser.add_argument('--port', type=int, default=int(os.getenv('CASE_SIGNAL_PORT', '8096')))
    args = parser.parse_args()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    server.app = App()
    print('Case Signal listening on ' + args.host + ':' + str(args.port), flush=True)
    server.serve_forever()


if __name__ == '__main__':
    main()
