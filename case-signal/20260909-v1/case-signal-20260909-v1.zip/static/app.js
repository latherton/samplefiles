'use strict';

const state = {
  page: 'overview', bootstrap: null, bootstrapError: '', cases: [], total: 0,
  casesLoading: true, casesError: '', selectedId: '', detail: null,
  detailLoading: false, detailError: '', tab: 'briefing', search: '', status: '', priority: '',
  sources: null, sourcesLoading: false, sourcesError: '', summarizing: '', summaryError: '',
  syncing: false, syncError: '', toastTimer: null, searchTimer: null, pollTimer: null,
  caseRequest: 0, detailRequest: 0, initialized: false, availableStatuses: [], availablePriorities: [], sourceFocusId: '',
};
const app = document.getElementById('app');
const dialog = document.getElementById('source-dialog');
const paths = {
  signal: '<path d="M3 14h4l3-9 4 14 3-9h4"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  cases: '<path d="M3 7h7l2 2h9v11H3z"/><path d="M3 7V4h7l2 3h8v2"/>',
  plug: '<path d="M8 3v5m8-5v5M6 8h12v3a6 6 0 0 1-12 0V8zm6 9v4"/>',
  arrow: '<path d="M5 12h14m-5-5 5 5-5 5"/>',
  upRight: '<path d="M6 18 18 6M6 6h12v12"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  file: '<path d="M14 3H5v18h14V8l-5-5zM14 3v5h5M8 12h8m-8 4h6"/>',
  refresh: '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M6.1 6.1A8 8 0 0 1 20 12M4 12a8 8 0 0 0 13.9 5.9"/>',
  spark: '<path d="m12 3 2.6 6.4L21 12l-6.4 2.6L12 21l-2.6-6.4L3 12l6.4-2.6L12 3zM20 2v4m-2-2h4"/>',
  download: '<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  circleCheck: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
  warning: '<path d="M12 3 2 21h20L12 3zM12 9v5m0 3v1"/>',
  close: '<path d="m6 6 12 12M6 18 18-12"/>',
  layers: '<path d="m12 3 10 5-10 5L2 8l10-5zm-10 9 10 5 10-5M2 16l10 5 10-5"/>',
  lock: '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 4v3"/>',
  activity: '<path d="M3 20V4m0 16h18M7 16l4-5 4 2 5-7"/>',
  copy: '<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V3H3v13h5"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
};
const icon = (name, size = 16, cls = '') => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" class="${cls}">${paths[name] || paths.file}</svg>`;
const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const label = value => String(value || '').replace(/[_-]/g, ' ');
const token = value => String(value || '').toLowerCase().replace(/[^a-z0-9_-]/g,'-');
const array = value => Array.isArray(value) ? value : [];
const textValue = value => typeof value === 'string' ? value : (value == null ? '' : JSON.stringify(value));
const initials = value => String(value || '?').split(/\s+/).map(word => word[0]).slice(0, 2).join('').toUpperCase();
const isSynthetic = () => ['fixture', 'synthetic', 'demo'].includes(String(state.bootstrap?.source?.mode || '').toLowerCase());
const sourceLabel = () => isSynthetic() ? 'Synthetic case demo' : (state.bootstrap?.source?.label || 'Source not verified');
function date(value, options = {}) {
  if (!value) return 'Not recorded';
  const parsed = new Date(value);
  if (!Number.isFinite(parsed.getTime())) return String(value);
  return parsed.toLocaleDateString(undefined, { month: 'short', day: 'numeric', ...options });
}
function stamp(value) {
  if (!value) return 'Not recorded';
  const parsed = new Date(value);
  return Number.isFinite(parsed.getTime()) ? parsed.toLocaleString(undefined, { month:'short',day:'numeric',hour:'numeric',minute:'2-digit' }) : String(value);
}
function safeURL(value) {
  if (!value) return '';
  try { const url = new URL(value, location.origin); return ['http:', 'https:'].includes(url.protocol) ? url.href : ''; } catch { return ''; }
}
function fleetURL() {
  const configured = safeURL(state.bootstrap?.fleet?.url);
  if (configured) return configured;
  const url = new URL(location.href); url.port = '8095'; url.pathname = '/'; url.search = ''; url.hash = ''; return url.href;
}
async function api(url, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), options.long ? 180000 : 45000);
  const {long, ...requestOptions} = options;
  try {
    const response = await fetch(url, {...requestOptions, signal: controller.signal, headers: {Accept:'application/json', ...(requestOptions.body ? {'Content-Type':'application/json'} : {}), ...requestOptions.headers}});
    const type = response.headers.get('content-type') || '';
    const data = type.includes('json') ? await response.json() : {message: await response.text()};
    if (!response.ok) throw new Error(data.message || data.error || `Request failed (${response.status}).`);
    return data;
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('The service did not respond in time. Refresh status before retrying.');
    if (error instanceof TypeError) throw new Error('The Case Signal service could not be reached. Check the connection and retry.');
    throw error;
  } finally { clearTimeout(timeout); }
}
function toast(message, error = false) {
  clearTimeout(state.toastTimer);
  document.getElementById('toast-region').innerHTML = `<div class="toast ${error ? 'error' : ''}">${icon(error ? 'warning' : 'circleCheck', 17)}<span>${escape(message)}</span></div>`;
  state.toastTimer = setTimeout(() => { document.getElementById('toast-region').innerHTML = ''; }, error ? 11000 : 6000);
}
function pendingStatus() {
  return /pending|pulling|running|syncing|indexing|submitted|in.progress/i.test(String(state.bootstrap?.source?.status || ''));
}
function healthHTML() {
  const kd = state.bootstrap?.kd;
  if (!state.bootstrap) return `<span class="health-pill pending"><span class="status-dot"></span>${state.bootstrapError ? 'Service unavailable' : 'Checking backend'}</span>`;
  if (pendingStatus()) return `<span class="health-pill pending">${icon('refresh',12,'spinning')}Source sync in progress</span>`;
  return `<span class="health-pill ${kd?.connected ? '' : 'error'}" title="${escape(kd?.message || '')}"><span class="status-dot"></span>KD ${kd?.connected ? 'connected' : 'unavailable'}</span>`;
}
function render() {
  const focused = document.activeElement;
  const focusId = focused?.id;
  const selection = focused instanceof HTMLInputElement ? [focused.selectionStart, focused.selectionEnd] : null;
  const queueScroll = document.querySelector('.queue-list')?.scrollTop || 0;
  const nav = [['overview','grid','Overview'],['cases','cases','Case queue'],['sources','plug','Sources']];
  app.innerHTML = `<header class="app-header">
    <a class="brand" href="#overview" aria-label="Case Signal home"><span class="brand-mark">${icon('signal',23)}</span><span class="wordmark">case<span>signal</span></span></a>
    <nav class="nav" aria-label="Main navigation">${nav.map(([id, graphic, title]) => `<a href="#${id}" ${state.page === id ? 'aria-current="page"' : ''}>${icon(graphic,14)}${title}</a>`).join('')}</nav>
    <div class="header-right"><span class="mode-pill"><span class="dot"></span>${escape(sourceLabel())}</span><a class="fleet-link" href="${escape(fleetURL())}" target="_blank" rel="noopener" title="Open Fleet Evidence on port 8095">Fleet Evidence ${icon('upRight',13)}</a><span class="user-mark" title="Case Signal workspace">CS</span></div>
  </header>
  <main class="workspace ${state.page === 'cases' ? 'compact' : ''}" id="workspace" tabindex="-1">
    ${pageHeading()}
    ${state.bootstrapError ? errorBanner(state.bootstrapError, 'retry-bootstrap') : ''}
    ${state.page === 'sources' ? sourcesHTML() : `${metricsHTML()}<div class="workbench">${queueHTML()}${detailHTML()}</div>`}
    <footer class="app-footer"><p>${icon('lock',11)}${escape(sourceLabel())} · Summaries require human review · <button class="footer-link" data-action="navigate-sources">Source provenance</button></p><p>Powered by OpenText Knowledge Discovery ${icon('signal',12)}</p></footer>
  </main>`;
  if (focusId) {
    const replacement = document.getElementById(focusId);
    if (replacement) { replacement.focus({preventScroll: true}); if (selection && replacement instanceof HTMLInputElement) replacement.setSelectionRange(...selection); }
  }
  const queue = document.querySelector('.queue-list'); if (queue) queue.scrollTop = queueScroll;
}
function pageHeading() {
  const titles = {overview: 'Every case.<br><em>A clearer next move.</em>', cases: 'The case queue.', sources: 'The sources behind<br><em>the signal.</em>'};
  const notes = {overview:'A connected view of the evidence, the decisions, and what comes next.', cases:'Find the case. Trace the evidence. Build a briefing you can stand behind.', sources:'Real connectors. Explicit provenance. One dedicated KD index.'};
  return `<div class="page-heading"><div><div class="eyebrow"><span class="tick"></span>${state.page === 'sources' ? 'Data & integrations' : 'Case intelligence workspace'}</div><h1>${titles[state.page]}</h1><p class="heading-note">${notes[state.page]}</p></div><div class="date-and-health"><p class="date-label">${escape(date(new Date(), {weekday:'short', year:'numeric'}))}</p>${healthHTML()}</div></div>`;
}
function metricsHTML() {
  const stats = state.bootstrap?.stats;
  const number = key => stats?.[key] ?? '—';
  return `<section class="overview-metrics" aria-label="Workspace metrics"><div class="metric"><div class="metric-label">${icon('cases',13)}Cases in the workspace</div><div class="metric-value">${escape(number('cases'))}<span class="annotation">KD indexed</span></div></div><div class="metric urgent"><div class="metric-label">${icon('activity',13)}Urgent cases</div><div class="metric-value">${escape(number('urgent'))}<span class="annotation">for closer review</span></div></div><div class="metric"><div class="metric-label">${icon('file',13)}Source records</div><div class="metric-value">${escape(number('sources'))}<span class="annotation">traceable evidence</span></div></div><div class="metric source"><div class="metric-label">${icon('plug',13)}Source environment</div><div class="metric-value">${escape(isSynthetic() ? 'Synthetic case demo' : state.bootstrap?.source?.label || 'Checking source')}</div><div class="annotation">${isSynthetic() ? 'AppWorks connector ready to configure' : `${escape(number('open'))} open cases · ${escape(label(state.bootstrap?.source?.status || 'Unknown status'))}`}</div></div></section>`;
}
function queueHTML() {
  const priorities = [...state.availablePriorities];
  const statuses = [...state.availableStatuses];
  for (const item of state.cases) { if (item.status && !statuses.includes(item.status)) statuses.push(item.status); if (item.priority && !priorities.includes(item.priority)) priorities.push(item.priority); }
  return `<aside class="queue" aria-label="Case queue"><div class="section-heading"><h2>Case queue <span class="count">${state.casesLoading ? '…' : escape(state.total)}</span></h2><button id="refresh-cases" class="quiet-button" data-action="refresh-cases" title="Refresh from Knowledge Discovery" aria-label="Refresh case queue" ${state.casesLoading ? 'disabled' : ''}>${icon('refresh',14)}</button></div><form id="search-form" role="search"><label class="sr-only" for="case-search">Search indexed cases</label><div class="search-wrap">${icon('search',15)}<input id="case-search" class="search-input" name="search" autocomplete="off" placeholder="Search cases, people, evidence…" value="${escape(state.search)}"></div><div class="filter-row"><label class="sr-only" for="status-filter">Case status</label><select class="filter" id="status-filter"><option value="">All statuses</option>${statuses.map(value => `<option value="${escape(value)}" ${state.status === value ? 'selected' : ''}>${escape(label(value))}</option>`).join('')}</select><label class="sr-only" for="priority-filter">Case priority</label><select class="filter" id="priority-filter"><option value="">All priorities</option>${priorities.map(value => `<option value="${escape(value)}" ${state.priority === value ? 'selected' : ''}>${escape(label(value))}</option>`).join('')}</select></div></form><div class="queue-list" aria-live="polite" aria-busy="${state.casesLoading}">${state.casesLoading ? '<div class="skeleton case"></div><div class="skeleton case"></div><div class="skeleton case"></div>' : state.casesError ? `<div class="list-message"><strong>Case retrieval unavailable</strong>${escape(state.casesError)}<br><button class="btn" data-action="refresh-cases" style="margin-top:15px">${icon('refresh',13)}Retry KD search</button></div>` : state.cases.length ? state.cases.map(caseItemHTML).join('') : `<div class="list-message"><strong>${state.search || state.status || state.priority ? 'No matching cases.' : 'No indexed cases yet.'}</strong>${state.search || state.status || state.priority ? 'Try another phrase or clear the filters.' : 'Open Sources to sync the configured source into Knowledge Discovery.'}<br><button class="btn" data-action="${state.search || state.status || state.priority ? 'clear-filters' : 'navigate-sources'}" style="margin-top:15px">${state.search || state.status || state.priority ? 'Clear filters' : 'Open sources'}</button></div>`}</div><p class="queue-foot">${icon('layers',12)}Retrieved from ${escape(state.bootstrap?.kd?.database || 'the dedicated KD index')}</p></aside>`;
}
function caseItemHTML(item) {
  return `<button class="case-item ${item.id === state.selectedId ? 'selected' : ''}" data-action="select-case" data-id="${escape(item.id)}" ${item.id === state.selectedId ? 'aria-current="true"' : ''}><span class="case-topline"><span class="case-id">${escape(item.id)}</span><span class="priority ${token(item.priority)}">${escape(label(item.priority))}</span></span><h3>${escape(item.title)}</h3><p class="case-preview">${escape(item.summary_preview || item.category || 'Open the case to review its source records.')}</p><span class="case-bottomline"><span class="status-label">${escape(label(item.status))}</span><span>${escape(item.source_count ?? 0)} records · ${escape(date(item.updated_at))}</span>${item.id === state.selectedId ? icon('arrow',12,'selected-arrow') : ''}</span></button>`;
}
function detailHTML() {
  if (state.detailLoading) return `<section class="brief" id="case-detail" aria-busy="true" aria-label="Loading case"><div class="skeleton-detail"><div class="skeleton header"></div><div class="skeleton line short"></div><div class="skeleton large"></div><div class="skeleton line"></div><div class="skeleton line"></div><div class="skeleton line short"></div><div class="skeleton large"></div></div></section>`;
  if (state.detailError) return `<section class="brief" id="case-detail"><div class="brief-empty">${icon('warning',32)}<h2>The case could not be loaded.</h2><p>${escape(state.detailError)}</p><button class="btn" data-action="retry-detail">${icon('refresh',13)}Try again</button></div></section>`;
  if (!state.detail?.case) return `<section class="brief" id="case-detail"><div class="brief-empty">${icon('signal',42)}<h2>The story starts with a case.</h2><p>Select a case from the queue to trace the source evidence, review its timeline, and build a grounded brief.</p></div></section>`;
  const detail = state.detail, item = detail.case;
  const generation = Boolean(state.bootstrap?.generation?.configured);
  const tabs = [['briefing','spark','Briefing'],['timeline','clock','Timeline'],['evidence','file','Source evidence']];
  const synthetic = isSynthetic() || /synthetic|fixture/i.test(item.source_system || '');
  return `<article class="brief" id="case-detail" aria-label="${escape(item.title)}"><header class="brief-hero"><div class="brief-topline"><div class="eyebrow"><span class="tick"></span>${escape(item.id)} / ${escape(item.category || 'Case briefing')}</div><span class="status-label">${escape(label(item.status))}</span></div><h2>${escape(item.title)}</h2><div class="brief-meta"><span class="meta-item"><span class="owner">${escape(initials(item.owner))}</span>${escape(item.owner || 'Owner not recorded')}</span><span class="priority ${token(item.priority)}">${escape(label(item.priority || 'Unspecified'))} priority</span><span class="meta-item">${icon('clock',12)}Updated ${escape(stamp(item.updated_at))}</span></div></header>${synthetic ? `<div class="source-notice">${icon('layers',11)}Synthetic case data · AppWorks connector not connected to a live tenant</div>` : ''}${summaryActionsHTML(item,detail,generation)}<div class="brief-nav" role="tablist" aria-label="Case views">${tabs.map(([id,graphic,title]) => `<button id="tab-${id}" class="brief-tab" role="tab" aria-selected="${state.tab === id}" aria-controls="case-tab-panel" tabindex="${state.tab === id ? '0' : '-1'}" data-action="tab" data-tab="${id}">${icon(graphic,13)}${title}${id === 'evidence' ? `<span class="tab-count">${array(detail.sources).length}</span>` : ''}</button>`).join('')}</div><div class="brief-body" id="case-tab-panel" role="tabpanel" aria-labelledby="tab-${state.tab}" tabindex="0">${state.summaryError ? errorBanner(state.summaryError) : ''}${state.tab === 'timeline' ? timelineHTML() : state.tab === 'evidence' ? evidenceHTML() : summaryHTML()}</div></article>`;
}
function summaryActionsHTML(item,detail,generation) {
  return `<div class="brief-footer brief-actions" aria-label="Case brief actions"><div class="button-group"><button class="btn primary ${state.summarizing === 'generated' ? 'loading' : ''}" id="generate-summary" data-action="summarize" data-mode="generated" ${!generation || state.summarizing ? 'disabled' : ''} title="${generation ? 'Generate a reviewable draft from retrieved case sources' : 'A generation service is not configured. Use the sourced brief.'}">${icon(state.summarizing === 'generated' ? 'refresh' : 'spark',13)}${state.summarizing === 'generated' ? 'Drafting summary…' : generation ? 'Generate AI draft' : 'AI not configured'}</button><button class="btn ${state.summarizing === 'extractive' ? 'loading' : ''}" id="extract-summary" data-action="summarize" data-mode="extractive" ${state.summarizing ? 'disabled' : ''}>${icon(state.summarizing === 'extractive' ? 'refresh' : 'file',13)}${state.summarizing === 'extractive' ? 'Building brief…' : detail.summary ? 'Refresh sourced brief' : 'Build sourced brief'}</button></div><a class="btn" href="/api/cases/${encodeURIComponent(item.id)}/export" target="_blank" rel="noopener" title="Open a printable HTML brief">${icon('download',13)}Export brief</a></div>`;
}
function citationHTML(ids) {
  const sources = array(state.detail?.sources);
  return array(ids).map(id => { const index = sources.findIndex(source => source.id === id); const source = sources[index]; return `<button class="citation" data-action="open-source" data-id="${escape(id)}" title="${escape(source?.title || id)}" aria-label="Open source ${escape(index >= 0 ? index + 1 : id)}: ${escape(source?.title || 'source record')}">[${index >= 0 ? index + 1 : '?'}]</button>`; }).join('');
}
function summaryHTML() {
  const summary = state.detail?.summary;
  if (!summary) return `<div class="brief-heading"><h3>${icon('spark',16)}Executive briefing</h3><span class="draft-badge">Source records available</span></div><p class="summary-overview">${escape(state.detail?.case?.description || 'Review the source evidence for this case, then build a sourced brief or generate a draft.')}</p><div class="summary-empty" style="margin-top:23px"><h3>Turn the case file into a clear brief.</h3><p>A sourced brief extracts evidence directly from the indexed records. An AI draft uses the configured model and still requires review. Both retain references to the original sources.</p><button class="btn primary" data-action="summarize" data-mode="extractive" ${state.summarizing ? 'disabled' : ''}>${icon('file',13)}${state.summarizing ? 'Building brief…' : 'Build sourced brief'}</button></div>`;
  const generated = summary.mode === 'generated';
  const findings = array(summary.findings), actions = array(summary.next_actions), gaps = array(summary.gaps);
  return `<div class="brief-heading"><h3>${icon('spark',16)}Executive briefing</h3><span class="draft-badge">${icon(generated ? 'spark' : 'file',10)}${generated ? 'AI-generated draft' : 'Sourced extractive brief'}</span></div>${summary.headline ? `<h4 class="summary-headline">${escape(summary.headline)}</h4>` : ''}<p class="summary-overview">${escape(summary.overview || 'No overview was returned.')}<span class="citations">${citationHTML(summary.overview_source_ids)}</span></p><div class="summary-provenance">${icon('layers',11)}${array(summary.source_ids).length} cited sources <span>·</span> ${escape(stamp(summary.created_at))}<span>·</span><span class="review-note">Human review required</span></div><hr class="rule"><h4 class="findings-heading">${icon('eye',12)}What the evidence says</h4><div class="finding-list">${findings.length ? findings.map((finding,index) => `<div class="finding"><span class="finding-index">${String(index+1).padStart(2,'0')}</span><p>${escape(typeof finding === 'string' ? finding : finding.text)}<span class="citations">${citationHTML(finding.source_ids)}</span></p></div>`).join('') : '<p class="source-description">No grounded findings were returned. Review the original records.</p>'}</div>${actions.length ? `<div class="action-strip"><h4 class="findings-heading">${icon('arrow',12)}${generated ? 'Next actions to review' : 'Recorded next actions'}</h4>${actions.map(action => `<div class="action-row">${icon('arrow',12)}<p>${escape(typeof action === 'string' ? action : action.text)}<span class="citations">${citationHTML(action.source_ids)}</span></p></div>`).join('')}</div>` : ''}${gaps.length ? `<details class="gaps"><summary>${gaps.length} ${gaps.length === 1 ? 'gap' : 'gaps'} to review</summary><ul>${gaps.map(gap => `<li>${escape(typeof gap === 'string' ? gap : gap.text || textValue(gap))}</li>`).join('')}</ul></details>` : ''}`;
}
function timelineHTML() {
  const entries = array(state.detail?.timeline);
  return `<div class="brief-heading"><h3>${icon('clock',16)}The case, in sequence</h3><span class="draft-badge">${entries.length} recorded events</span></div><p class="source-description">Follow the recorded updates. Open a reference to see the original source text behind each event.</p>${entries.length ? `<div class="timeline-list">${entries.map(entry => `<div class="timeline-entry"><div class="timeline-time"><strong>${escape(date(entry.at))}</strong>${escape(new Date(entry.at).toString() === 'Invalid Date' ? '' : new Date(entry.at).toLocaleTimeString(undefined,{hour:'numeric',minute:'2-digit'}))}</div><div class="timeline-content"><h3>${escape(entry.title)}</h3><p>${escape(entry.text)}</p>${citationHTML(entry.source_id ? [entry.source_id] : [])}</div></div>`).join('')}</div>` : '<p class="source-description">No timestamped events were returned for this case.</p>'}`;
}
function evidenceHTML() {
  const sources = array(state.detail?.sources);
  return `<div class="brief-heading"><h3>${icon('file',16)}Source evidence</h3><span class="draft-badge">${sources.length} source records</span></div><p class="source-description">The original records retrieved for this case. References preserve their source system and recorded update time.</p><div class="source-list">${sources.map((source,index) => `<button class="source-row" data-action="open-source" data-id="${escape(source.id)}"><span class="source-file-icon">${icon('file',19)}</span><span><h3><span style="color:#8b9c7c;font-weight:500">${String(index+1).padStart(2,'0')} /</span> ${escape(source.title)}</h3><p>${escape(label(source.kind || 'Record'))} · ${escape(source.source_system || 'Source not recorded')} · ${escape(date(source.updated_at))}</p></span>${icon('upRight',15)}</button>`).join('') || '<p class="source-description">No source records were returned.</p>'}</div>`;
}
function errorBanner(message, action) { return `<div class="error-banner" role="alert">${icon('warning',15)}<div>${escape(message)}${action ? `<br><button class="btn" data-action="${action}">${icon('refresh',12)}Retry connection</button>` : ''}</div></div>`; }
function sourcesHTML() {
  if (state.sourcesLoading && !state.sources) return `<div class="sources-layout"><div><div class="skeleton large" style="height:290px"></div><div class="skeleton line"></div><div class="skeleton line"></div></div><div><div class="skeleton header"></div><div class="skeleton large"></div></div></div>`;
  if (state.sourcesError && !state.sources) return errorBanner(state.sourcesError,'refresh-sources');
  const info = state.sources || {}, source = info.source || state.bootstrap?.source || {};
  const requirements = array(info.requirements);
  const mapping = info.mapping || {};
  const mappingEntries = Array.isArray(mapping) ? mapping.map(entry => [entry.field || entry.target || entry.name || 'Field', entry.source || entry.path || entry.value || entry]) : Object.entries(mapping);
  const runs = array(info.runs);
  const synthetic = isSynthetic();
  return `${state.sourcesError ? errorBanner(state.sourcesError,'refresh-sources') : ''}${state.syncError ? errorBanner(state.syncError) : ''}<div class="sources-layout"><section><div class="integration-feature"><div class="integration-topline"><span class="integration-brand">${icon('plug',24)}</span><span class="health-pill ${/error|failed/i.test(String(source.status)) ? 'error' : ''}"><span class="status-dot"></span>${escape(label(source.status || 'Status not recorded'))}</span></div><div class="eyebrow">Active source → Knowledge Discovery</div><h2>${synthetic ? 'Synthetic cases.<br>Production-shaped integration.' : escape(source.label || 'AppWorks case connector')}</h2><p>${synthetic ? 'The current case records are synthetic. The read-only AppWorks connector uses configured endpoints and field mappings; live tenant access has not been provided.' : 'Case records are pulled through the configured read-only adapter and indexed in the dedicated Case Signal database. Check each sync result before relying on its freshness.'}</p><div class="button-group"><button class="btn primary ${state.syncing ? 'loading' : ''}" data-action="sync" id="sync-source" ${state.syncing ? 'disabled' : ''}>${icon('refresh',13)}${state.syncing ? 'Sync in progress…' : 'Sync source to KD'}</button><button class="btn dark" data-action="refresh-sources">${icon('activity',13)}Refresh status</button></div>${state.syncing ? '<div class="loading-bar" aria-label="Sync in progress"></div>' : ''}</div><dl class="config-list"><div class="config-row"><dt>Source mode</dt><dd>${escape(source.mode || 'Not recorded')} ${synthetic ? '· explicitly synthetic' : ''}</dd></div><div class="config-row"><dt>Source system</dt><dd>${escape(source.label || sourceLabel())}</dd></div><div class="config-row"><dt>KD database</dt><dd>${escape(state.bootstrap?.kd?.database || 'Not recorded')}</dd></div><div class="config-row"><dt>Last sync</dt><dd>${escape(stamp(source.last_sync || state.bootstrap?.source?.last_sync))}</dd></div><div class="config-row"><dt>Generation model</dt><dd>${escape(state.bootstrap?.generation?.configured ? state.bootstrap.generation.model || 'Configured service' : 'Not configured; sourced briefs available')}</dd></div>${source.endpoint || source.base_url ? `<div class="config-row"><dt>Source endpoint</dt><dd>${escape(source.endpoint || source.base_url)}</dd></div>` : ''}</dl></section><section class="sources-requirements"><div class="eyebrow"><span class="tick"></span>AppWorks connection</div><h2 class="connection-heading">A real adapter. A deliberate handoff.</h2><p class="connection-copy">The connector is configured on the service, where credentials stay protected. These are the requirements and field mappings supplied by the backend.</p>${requirements.length ? `<ul class="requirement-list">${requirements.map(requirement => `<li>${icon('arrow',14)}<span>${escape(typeof requirement === 'string' ? requirement : requirement.message || requirement.description || requirement.label || textValue(requirement))}</span></li>`).join('')}</ul>` : `<p class="connection-copy">No connection requirements were returned by the service.</p>`}<div class="integration-note">${icon('lock',13)} Read-only ingestion. Source records keep their identity, timestamps, and original references. No changes are written back to AppWorks.</div><div class="mapping"><h3 class="connection-heading">Field mapping</h3>${mappingEntries.length ? `<table class="mapping-table"><thead><tr><th scope="col">Case Signal field</th><th scope="col">Source mapping</th></tr></thead><tbody>${mappingEntries.map(([key,value]) => `<tr><td>${escape(label(key))}</td><td>${escape(textValue(value))}</td></tr>`).join('')}</tbody></table>` : '<p class="connection-copy">A source field mapping has not been reported.</p>'}</div></section></div><section class="runs-section"><div class="section-heading"><h2>Sync journal <span class="count">${runs.length} ${runs.length === 1 ? 'run' : 'runs'}</span></h2><button class="quiet-button" data-action="refresh-sources">${icon('refresh',13)}Refresh journal</button></div>${runs.length ? runs.map(runHTML).join('') : '<p class="connection-copy">No sync runs have been recorded. A source sync creates a journal entry and reports its outcome here.</p>'}</section>`;
}
function runHTML(run) {
  const status = String(run.status || run.state || 'Recorded');
  const error = /error|fail/i.test(status);
  const running = /pending|running|submitted|indexing|syncing/i.test(status);
  const fields = ['source_case_count','source_record_count','verified_records','cases','source_count','records','submitted','verified','documents'];
  const counts = fields.filter(key => typeof run[key] === 'number').map(key => `${label(key)}: ${run[key]}`);
  const message = run.message || run.error || run.detail || run.summary || '';
  return `<div class="run-entry ${error ? 'error' : ''}">${icon(error ? 'warning' : running ? 'refresh' : 'circleCheck',17,running ? 'spinning' : '')}<div><div class="run-title">${escape(label(status))}${run.id ? ` <span style="color:var(--muted);font-weight:400;font-size:10px">/ ${escape(run.id)}</span>` : ''}</div><p class="run-details">${escape(textValue(message))}${counts.length ? ` · ${escape(counts.join(' · '))}` : ''}</p></div><span class="run-time">${escape(stamp(run.finished_at || run.completed_at || run.started_at || run.at || run.created_at))}</span></div>`;
}
function openSource(id) {
  const source = array(state.detail?.sources).find(item => item.id === id);
  if (!source) { toast('That source is not part of the retrieved case snapshot. Refresh the case before relying on this citation.', true); return; }
  state.sourceFocusId = id;
  const url = safeURL(source.source_url);
  dialog.innerHTML = `<div class="drawer-header"><div><div class="eyebrow"><span class="tick"></span>Original source record</div><h2 id="source-title">${escape(source.title)}</h2></div><button class="icon-button" data-action="close-source" aria-label="Close source record">${icon('close',18)}</button></div><div class="drawer-content"><dl class="drawer-metadata"><dt>Record ID</dt><dd>${escape(source.id)}</dd><dt>Source system</dt><dd>${escape(source.source_system || 'Not recorded')}</dd><dt>Record type</dt><dd>${escape(label(source.kind || 'Record'))}</dd><dt>Last updated</dt><dd>${escape(stamp(source.updated_at))}</dd><dt>Related case</dt><dd>${escape(state.detail?.case?.id)}</dd></dl><h3 class="findings-heading">Source text</h3><pre class="source-text">${escape(source.text || 'No source text was returned.')}</pre><div class="button-group"><button class="btn" data-action="copy-source" data-id="${escape(id)}">${icon('copy',13)}Copy source text</button>${url ? `<a class="btn" href="${escape(url)}" target="_blank" rel="noopener">${icon('upRight',13)}Open original record</a>` : ''}</div>${isSynthetic() || /synthetic|fixture/i.test(source.source_system || '') ? '<div class="integration-note">This record belongs to the synthetic demonstration corpus. It is not a live AppWorks customer record.</div>' : ''}</div>`;
  dialog.showModal();
}
async function copySource(id) {
  const source = array(state.detail?.sources).find(item => item.id === id);
  if (!source) return;
  const value = `${source.title}\nSource: ${source.source_system || 'Not recorded'}\nRecord: ${source.id}\nUpdated: ${source.updated_at || 'Not recorded'}\n\n${source.text || ''}`;
  try {
    if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(value);
    else { const box = document.createElement('textarea'); box.value = value; box.style.position = 'fixed'; box.style.opacity = '0'; dialog.appendChild(box); box.select(); const copied = document.execCommand('copy'); box.remove(); if (!copied) throw new Error('Clipboard unavailable'); }
    toast('Source text and provenance copied.');
  } catch { toast('The browser blocked clipboard access. Select the source text to copy it manually.',true); }
}
async function loadBootstrap({quiet = false} = {}) {
  try { state.bootstrap = await api('/api/bootstrap'); state.bootstrapError = ''; if (pendingStatus()) {state.syncing = true; schedulePoll();} }
  catch(error) { state.bootstrapError = error.message; }
  if (!quiet) render();
}
async function loadCases({keepSelection = true} = {}) {
  const request = ++state.caseRequest;
  state.casesLoading = true; state.casesError = ''; render();
  const query = new URLSearchParams();
  if (state.search) query.set('q',state.search); if (state.status) query.set('status',state.status); if (state.priority) query.set('priority',state.priority);
  try {
    const result = await api(`/api/cases?${query}`);
    if (request !== state.caseRequest) return;
    state.cases = array(result.cases); state.total = result.total ?? state.cases.length; state.casesLoading = false;
    if (!state.search && !state.status && !state.priority) {
      state.availableStatuses = [...new Set(state.cases.map(item => item.status).filter(Boolean))];
      state.availablePriorities = [...new Set(state.cases.map(item => item.priority).filter(Boolean))];
    }
    const selected = keepSelection && state.cases.some(item => item.id === state.selectedId);
    if (!selected) {state.selectedId = state.cases[0]?.id || ''; state.detail = null; state.detailError = '';}
    render();
    if (state.selectedId && (!state.detail || state.detail.case?.id !== state.selectedId)) await loadDetail(state.selectedId);
  } catch(error) {
    if (request !== state.caseRequest) return;
    state.casesError = error.message; state.cases = []; state.total = 0; state.casesLoading = false;
    state.detail = null; state.detailError = ''; render();
  }
}
async function loadDetail(id, {scroll = false} = {}) {
  if (!id) return;
  const request = ++state.detailRequest;
  state.selectedId = id; state.detailLoading = true; state.detailError = ''; state.summaryError = ''; state.tab = 'briefing'; render();
  try {
    const detail = await api(`/api/cases/${encodeURIComponent(id)}`);
    if (request !== state.detailRequest) return;
    state.detail = detail; state.detailLoading = false; render();
    if (scroll && matchMedia('(max-width:650px)').matches) document.getElementById('case-detail')?.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion:reduce)').matches ? 'auto' : 'smooth',block:'start'});
  } catch(error) { if (request !== state.detailRequest) return; state.detail = null; state.detailLoading = false; state.detailError = error.message; render(); }
}
async function loadSources({quiet = false} = {}) {
  if (!quiet) {state.sourcesLoading = true; render();}
  try { state.sources = await api('/api/sources'); state.sourcesError = ''; }
  catch(error) { state.sourcesError = error.message; }
  state.sourcesLoading = false; if (!quiet) render();
}
async function summarize(mode) {
  const id = state.detail?.case?.id;
  if (!id || state.summarizing || (mode === 'generated' && !state.bootstrap?.generation?.configured)) return;
  state.summarizing = mode; state.summaryError = ''; render();
  try {
    const result = await api(`/api/cases/${encodeURIComponent(id)}/summarize`, {method:'POST',body:JSON.stringify({mode}),long:true});
    if (state.detail?.case?.id === id) {state.detail.summary = result.summary; state.tab = 'briefing';}
    toast(mode === 'generated' ? 'AI draft saved with source references. Review it before use.' : 'Sourced brief saved with references to the evidence.');
  } catch(error) {if (state.detail?.case?.id === id) state.summaryError = error.message; toast(error.message,true);}
  finally {state.summarizing = ''; render();}
}
function schedulePoll() {
  clearTimeout(state.pollTimer);
  state.pollTimer = setTimeout(pollSync,3500);
}
async function pollSync() {
  await Promise.all([loadBootstrap({quiet:true}),loadSources({quiet:true})]);
  if (state.bootstrapError) {state.syncError = 'Sync status could not be verified. The request may still be running; refresh status before retrying.'; state.syncing = true; render(); schedulePoll(); return;}
  const recentRun = array(state.sources?.runs)[0];
  const runStatus = String(recentRun?.status || recentRun?.state || '');
  const pending = pendingStatus() || /pending|pulling|running|syncing|indexing|submitted|in.progress/i.test(runStatus);
  if (pending) {state.syncing = true; render(); schedulePoll(); return;}
  if (/error|fail/i.test(runStatus + ' ' + state.bootstrap?.source?.status)) {state.syncing = false; state.syncError = textValue(recentRun?.message || recentRun?.error) || 'Source sync failed. Review the sync journal for details.'; toast(state.syncError,true);}
  else if (/^verified$/i.test(runStatus) || /^verified$/i.test(state.bootstrap?.source?.status || '')) {state.syncing = false; state.syncError = ''; toast('Source sync verified in KD. Refreshing the case queue.');}
  else {state.syncing = true; state.syncError = 'Waiting for a verified sync result. The journal has not confirmed completion.'; render(); schedulePoll(); return;}
  render(); await loadCases();
}
async function syncSource() {
  if (state.syncing) return;
  state.syncing = true; state.syncError = ''; render();
  try {
    await api('/api/sync',{method:'POST',body:JSON.stringify({}),long:true});
    toast('Source sync requested. Following the journal for its outcome.');
    await Promise.all([loadBootstrap({quiet:true}),loadSources({quiet:true})]);
    render(); schedulePoll();
  } catch(error) {
    state.syncError = error.message;
    await Promise.all([loadBootstrap({quiet:true}),loadSources({quiet:true})]);
    const lastStatus = String(array(state.sources?.runs)[0]?.status || '');
    state.syncing = pendingStatus() || /pending|pulling|running|syncing|indexing|submitted/i.test(lastStatus) || Boolean(state.bootstrapError);
    if (state.syncing) {state.syncError += ' Checking the journal before allowing another request.'; schedulePoll();}
    toast(state.syncError,true); render();
  }
}
function applyRoute() {
  const hash = location.hash.replace(/^#/,'').split('/');
  state.page = ['overview','cases','sources'].includes(hash[0]) ? hash[0] : 'overview';
  render();
  if (state.page === 'sources') loadSources();
  if (hash[0] === 'cases' && hash[1]) {try {loadDetail(decodeURIComponent(hash.slice(1).join('/')));} catch {toast('The case link could not be read.',true);}}
}
document.addEventListener('click', async event => {
  const button = event.target.closest('[data-action]'); if (!button || button.disabled) return;
  const action = button.dataset.action;
  if (action === 'select-case') {await loadDetail(button.dataset.id,{scroll:true});}
  else if (action === 'tab') {state.tab = button.dataset.tab; render(); document.getElementById(`tab-${state.tab}`)?.focus({preventScroll:true});}
  else if (action === 'open-source') openSource(button.dataset.id);
  else if (action === 'close-source') dialog.close();
  else if (action === 'copy-source') await copySource(button.dataset.id);
  else if (action === 'summarize') await summarize(button.dataset.mode);
  else if (action === 'refresh-cases') {await Promise.all([loadBootstrap(),loadCases()]);}
  else if (action === 'retry-detail') await loadDetail(state.selectedId);
  else if (action === 'retry-bootstrap') {await loadBootstrap(); await loadCases();}
  else if (action === 'clear-filters') {state.search = ''; state.status = ''; state.priority = ''; await loadCases({keepSelection:false});}
  else if (action === 'navigate-sources') {location.hash = 'sources';}
  else if (action === 'refresh-sources') {await Promise.all([loadBootstrap(),loadSources()]); if (state.syncing) schedulePoll();}
  else if (action === 'sync') await syncSource();
});
document.addEventListener('input',event => {
  if (event.target.id !== 'case-search') return;
  state.search = event.target.value; clearTimeout(state.searchTimer);
  state.searchTimer = setTimeout(() => loadCases({keepSelection:false}),350);
});
document.addEventListener('change',event => {
  if (event.target.id === 'status-filter') {state.status = event.target.value; loadCases({keepSelection:false});}
  if (event.target.id === 'priority-filter') {state.priority = event.target.value; loadCases({keepSelection:false});}
});
document.addEventListener('submit',event => {if (event.target.id === 'search-form') {event.preventDefault(); clearTimeout(state.searchTimer); loadCases({keepSelection:false});}});
document.addEventListener('keydown',event => {
  const tab = event.target.closest('[role="tab"]');
  if (tab && ['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) {
    event.preventDefault(); const tabs = ['briefing','timeline','evidence']; const index = tabs.indexOf(state.tab);
    state.tab = event.key === 'Home' ? tabs[0] : event.key === 'End' ? tabs[2] : tabs[(index + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length];
    render(); document.getElementById(`tab-${state.tab}`)?.focus();
  }
});
dialog.addEventListener('click',event => {if (event.target === dialog) {const box = dialog.getBoundingClientRect(); if (event.clientX < box.left || event.clientX > box.right) dialog.close();}});
dialog.addEventListener('close',() => {
  const trigger = [...app.querySelectorAll('[data-action="open-source"]')].find(button => button.dataset.id === state.sourceFocusId);
  (trigger || document.getElementById(`tab-${state.tab}`))?.focus({preventScroll:true});
});
window.addEventListener('hashchange',applyRoute);
async function init() {
  state.page = ['overview','cases','sources'].includes(location.hash.slice(1).split('/')[0]) ? location.hash.slice(1).split('/')[0] : 'overview';
  render(); await Promise.all([loadBootstrap(),loadCases()]);
  if (state.page === 'sources') await loadSources();
  const routeId = location.hash.match(/^#cases\/(.+)$/)?.[1]; if (routeId) {try {await loadDetail(decodeURIComponent(routeId));} catch {toast('The case link could not be read.',true);}}
  state.initialized = true;
}
init();
