"""Read-only source adapters. AppWorks mappings are deployment configuration, not a vendor schema."""
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
MAX_SOURCE_BYTES = 4 * 1024 * 1024


def now():
    return datetime.now(timezone.utc).isoformat()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')


def digest(value):
    return hashlib.sha256(value if isinstance(value, bytes) else canonical(value)).hexdigest()


class SourceError(RuntimeError):
    def __init__(self, message, code='source_error'):
        super().__init__(message)
        self.code = code


def pointer(obj, path, default=None):
    """RFC6901 JSON pointer; missing optional fields do not become invented values."""
    if path == '':
        return obj
    if not isinstance(path, str) or not path.startswith('/'):
        raise SourceError('Mappings must use explicit JSON pointers.', 'mapping_invalid')
    try:
        for key in path[1:].split('/'):
            key = key.replace('~1', '/').replace('~0', '~')
            obj = obj[int(key)] if isinstance(obj, list) else obj[key]
        return obj
    except (KeyError, IndexError, ValueError, TypeError):
        return default


def scalar(value, field, required=False, limit=16000):
    if value is None and not required:
        return ''
    if not isinstance(value, (str, int, float)) or isinstance(value, bool):
        raise SourceError('Source field ' + field + ' must be a scalar.', 'mapping_invalid')
    result = str(value).strip()
    if required and not result or len(result) > limit or '\0' in result:
        raise SourceError('Source field ' + field + ' is empty or exceeds its bound.', 'mapping_invalid')
    return result


def safe_url(value):
    p = urllib.parse.urlsplit(value)
    if p.scheme not in {'https', 'http'} or not p.hostname or p.username or p.password or p.fragment:
        raise SourceError('Configure an HTTP(S) endpoint without embedded credentials.', 'source_configuration')
    if p.query:
        raise SourceError('Do not put authentication or query values in base_url.', 'source_configuration')
    return value.rstrip('/')


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise SourceError('Source redirected; configure the final approved API endpoint.', 'source_redirect')


class FixtureSource:
    mode = 'fixture'
    label = 'Synthetic AppWorks-shaped case records'
    configured = True

    def __init__(self, path=None):
        self.path = Path(path or ROOT / 'fixtures' / 'cases.json')

    def pull(self):
        data = json.loads(self.path.read_text(encoding='utf-8'))
        cases = data['cases']
        if not isinstance(cases, list) or not 1 <= len(cases) <= 100:
            raise SourceError('Synthetic fixture case inventory is invalid.')
        for case in cases:
            case.update(source_system='Synthetic fixture', synthetic=True, source_url='', retrieved_at=now())
            for source in case['sources']:
                source.update(source_system='Synthetic fixture', synthetic=True, source_url='', retrieved_at=case['retrieved_at'])
                source['original_reference'] = 'fixture://' + case['id'] + '/' + source['id']
                source['record_sha256'] = digest({k: v for k, v in source.items() if k not in {'record_sha256', 'retrieved_at'}})
        return validate_cases(cases)

    def public(self):
        return {'mode': self.mode, 'label': self.label, 'configured': True,
                'instance_verified': False, 'read_only': True,
                'mapping': {'schema': 'Authored demonstration records', 'version': '1'},
                'requirements': ['AppWorks endpoint, organization, generated entity mapping and an approved credential are required to connect a live instance.']}


def validate_cases(cases):
    seen = set()
    if len(cases) > 100:
        raise SourceError('Source exceeds the 100-case demo bound.', 'source_limit')
    for case in cases:
        for key in ['id', 'title', 'status', 'priority', 'owner', 'category', 'updated_at', 'description']:
            case[key] = scalar(case.get(key), key, required=key in {'id', 'title'}, limit=16000 if key == 'description' else 500)
        if case['id'] in seen:
            raise SourceError('Source contains duplicate case identities.', 'source_duplicate')
        seen.add(case['id'])
        case['status'] = case['status'] or 'Unknown'
        case['priority'] = case['priority'] or 'Unspecified'
        if not isinstance(case.get('sources'), list) or not 1 <= len(case['sources']) <= 50:
            raise SourceError('A case needs 1–50 mapped evidence records.', 'mapping_invalid')
        source_ids = set()
        for source in case['sources']:
            for key in ['id', 'title', 'kind', 'text', 'updated_at']:
                source[key] = scalar(source.get(key), key, required=key in {'id', 'title', 'text'}, limit=24000 if key == 'text' else 500)
            if source['id'] in source_ids:
                raise SourceError('Source contains duplicate evidence identities within a case.', 'source_duplicate')
            source_ids.add(source['id'])
            if source.get('case_id', case['id']) != case['id']:
                raise SourceError('A mapped record belongs to another case.', 'source_scope')
            source['case_id'] = case['id']
    return cases


class AppWorksSource:
    mode = 'appworks'
    label = 'AppWorks Entity REST connector'

    def __init__(self, config, opener=None):
        self.config = config
        self.base = safe_url(config['base_url'])
        self.origin = urllib.parse.urlsplit(self.base)
        if self.origin.scheme != 'https':
            try:
                local = self.origin.hostname == 'localhost' or ipaddress.ip_address(self.origin.hostname).is_loopback
            except ValueError:
                local = False
            if not local or config.get('allow_http_local') is not True:
                raise SourceError('AppWorks requires HTTPS; only an explicitly enabled loopback HTTP test is allowed.', 'source_configuration')
        self.opener = opener or urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        self.timeout = min(max(int(config.get('timeout_seconds', 20)), 1), 60)
        self.headers = {'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest'}
        auth = config.get('auth', {'header': 'SAMLart', 'env': 'APPWORKS_SAMLART'})
        if not re.fullmatch(r'[A-Za-z0-9_-]+', auth.get('header', '')) or not re.fullmatch(r'[A-Z][A-Z0-9_]*', auth.get('env', '')):
            raise SourceError('Authentication requires an approved header and environment variable name.', 'source_configuration')
        if auth['header'].lower() not in {'samlart', 'authorization', 'x-api-key'}:
            raise SourceError('Unsupported authentication header.', 'source_configuration')
        if not isinstance(auth.get('prefix', ''), str) or any(c in auth.get('prefix', '') for c in '\r\n'):
            raise SourceError('Authentication header prefix is invalid.', 'source_configuration')
        self.auth = auth
        self.configured = bool(os.getenv(auth['env']))
        if config.get('product_mode') != 'appworks_entity_rest' or not config.get('schema_map_version'):
            raise SourceError('Set product_mode and a versioned instance-specific schema mapping.', 'source_configuration')
        if not isinstance(config.get('property_map'), dict):
            raise SourceError('An instance-specific property_map is required.', 'source_configuration')
        if not all(key in config['property_map'] for key in {'id', 'title'}):
            raise SourceError('Map the observed case id and title fields.', 'source_configuration')
        if not config.get('case_ids') and not config.get('list_path'):
            raise SourceError('Configure case_ids or the observed list_path and items pointer.', 'source_configuration')
        if (config.get('case_ids') or not config.get('list_contains_items')) and not config.get('item_path_template'):
            raise SourceError('Configure the observed item_path_template.', 'source_configuration')
        if config.get('list_path') and ('list_items_pointer' not in config or not config.get('list_contains_items') and 'list_id_pointer' not in config):
            raise SourceError('Configure the observed list items and identity pointers.', 'source_configuration')
        if not isinstance(config.get('relations', {}), dict):
            raise SourceError('Relations must be a mapping.', 'source_configuration')
        if not isinstance(config.get('required_fields', []), list) or any(not isinstance(f, str) or f not in config['property_map'] for f in config.get('required_fields', [])):
            raise SourceError('required_fields must list mapped case fields.', 'source_configuration')
        for relation in config.get('relations', {}).values():
            if not isinstance(relation, dict) or not all(k in relation for k in {'path_template', 'items_pointer', 'field_map'}):
                raise SourceError('Each relation requires a path, items pointer and field map.', 'source_configuration')
            if not isinstance(relation['field_map'], dict) or not all(k in relation['field_map'] for k in {'id', 'title', 'text'}):
                raise SourceError('Each relation must map id, title and text fields.', 'source_configuration')
        self.read_urls = []

    def url(self, path, relative_to=None):
        url = urllib.parse.urljoin(relative_to or self.base + '/', path)
        p = urllib.parse.urlsplit(url)
        if (p.scheme, p.hostname, p.port) != (self.origin.scheme, self.origin.hostname, self.origin.port) or p.username or p.password or p.fragment:
            raise SourceError('Source links must remain on the configured exact origin.', 'source_scope')
        base_path = self.origin.path.rstrip('/')
        decoded = urllib.parse.unquote(p.path)
        if '/..' in decoded or (base_path and decoded != base_path and not decoded.startswith(base_path + '/')):
            raise SourceError('Source link left the configured API service path.', 'source_scope')
        forbidden = {'samlart', 'access_token', 'token', 'password', 'secret', 'apikey', 'api_key', 'authorization', 'ticket', 'otdsticket'}
        if any(key.lower() in forbidden for key, _ in urllib.parse.parse_qsl(p.query)):
            raise SourceError('Credential-bearing source URLs are not accepted.', 'source_scope')
        return url

    def get(self, path, relative_to=None):
        token = os.getenv(self.auth['env'], '')
        if not token or '\r' in token or '\n' in token:
            raise SourceError('AppWorks authentication is not configured or has expired.', 'source_authentication')
        url = self.url(path, relative_to)
        headers = dict(self.headers, **{self.auth['header']: self.auth.get('prefix', '') + token})
        request = urllib.request.Request(url, headers=headers, method='GET')
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                mime = response.headers.get('Content-Type', '').split(';')[0].lower()
                raw = response.read(MAX_SOURCE_BYTES + 1)
            if mime != 'application/json' and not mime.endswith('+json'):
                raise SourceError('AppWorks returned a non-JSON response; verify session and API route.', 'source_response')
            if len(raw) > MAX_SOURCE_BYTES:
                raise SourceError('Source response exceeded its bounded size.', 'source_limit')
            data = json.loads(raw)
            if not isinstance(data, (dict, list)):
                raise ValueError('not object/list')
            self.read_urls.append(url)
            return data, url
        except urllib.error.HTTPError as exc:
            code = 'source_authentication' if exc.code in {401, 403} else 'source_http_error'
            raise SourceError('AppWorks returned HTTP ' + str(exc.code) + '; no source data was substituted.', code) from exc
        except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
            raise SourceError('AppWorks is unavailable or returned invalid JSON; no fixture fallback was used.', 'source_unavailable') from exc

    def pages(self, path, items_pointer, next_pointer=None):
        result, seen = [], set()
        url = self.url(path)
        for _ in range(min(max(int(self.config.get('max_pages', 10)), 1), 50)):
            if url in seen:
                raise SourceError('AppWorks pagination contains a cycle.', 'source_pagination')
            seen.add(url)
            data, current = self.get(url)
            rows = pointer(data, items_pointer)
            if not isinstance(rows, list):
                raise SourceError('Mapped AppWorks list is not an array.', 'mapping_invalid')
            result.extend((row, current) for row in rows)
            if len(result) > 1000:
                raise SourceError('AppWorks records exceed the bounded demo limit.', 'source_limit')
            next_link = pointer(data, next_pointer) if next_pointer else None
            if not next_link:
                return result
            if not isinstance(next_link, str):
                raise SourceError('Mapped next link is not a URL string.', 'mapping_invalid')
            url = self.url(next_link, current)
        raise SourceError('AppWorks pagination remains incomplete at the page limit.', 'source_limit')

    def mapped(self, row, mapping):
        return {key: pointer(row, path) for key, path in mapping.items()}

    def template(self, template, ident):
        try:
            return template.format(id=urllib.parse.quote(str(ident), safe=''),
                                   namespace=urllib.parse.quote(self.config.get('entity_namespace', ''), safe=''),
                                   entity=urllib.parse.quote(self.config.get('entity_name', ''), safe=''))
        except (KeyError, ValueError) as exc:
            raise SourceError('Endpoint path template is invalid.', 'source_configuration') from exc

    def pull(self):
        cfg, cases = self.config, []
        requested_ids = None
        if cfg.get('case_ids'):
            ids = cfg['case_ids']
            if not isinstance(ids, list) or len(ids) > 100:
                raise SourceError('case_ids must contain at most 100 source IDs.', 'source_configuration')
            requested_ids = [str(ident) for ident in ids]
            rows = [self.get(self.template(cfg['item_path_template'], ident)) for ident in ids]
        else:
            rows = self.pages(cfg['list_path'], cfg['list_items_pointer'], cfg.get('next_link_pointer'))
            if len(rows) > 100:
                raise SourceError('AppWorks case inventory exceeds the 100-case demo bound.', 'source_limit')
            if cfg.get('list_contains_items', False) is not True:
                ids = [pointer(row, cfg['list_id_pointer']) for row, _ in rows]
                if any(ident is None for ident in ids):
                    raise SourceError('AppWorks case list lacks the mapped identity.', 'mapping_invalid')
                requested_ids = [str(ident) for ident in ids]
                rows = [self.get(self.template(cfg['item_path_template'], ident)) for ident in ids]
        fetched = now()
        for number, (row, uri) in enumerate(rows):
            case = self.mapped(row, cfg['property_map'])
            ident = scalar(case.get('id'), 'id', True, 500)
            if requested_ids is not None and ident != requested_ids[number]:
                raise SourceError('AppWorks returned a different case identity than requested.', 'source_scope')
            for field in cfg.get('required_fields', []):
                scalar(case.get(field), field, True)
            if cfg.get('status_map'):
                case['status'] = cfg['status_map'].get(str(case.get('status')), str(case.get('status') or 'Unknown'))
            if cfg.get('priority_map'):
                case['priority'] = cfg['priority_map'].get(str(case.get('priority')), str(case.get('priority') or 'Unspecified'))
            case.update(id=ident, source_system='AppWorks', synthetic=False, source_url=uri,
                        retrieved_at=fetched, schema_map_version=cfg['schema_map_version'])
            case['sources'] = [{'id': ident + ':record', 'title': str(case.get('title') or ident),
                                'kind': 'case', 'text': str(case.get('description') or case.get('title') or ident),
                                'updated_at': str(case.get('updated_at') or ''), 'case_id': ident,
                                'source_system': 'AppWorks', 'synthetic': False, 'source_url': uri,
                                'original_reference': uri, 'retrieved_at': fetched, 'record_sha256': digest(row),
                                'original_record': row, 'schema_map_version': cfg['schema_map_version']}]
            for name, relation in cfg.get('relations', {}).items():
                records = self.pages(self.template(relation['path_template'], ident), relation['items_pointer'], relation.get('next_link_pointer'))
                for record, record_uri in records:
                    source = self.mapped(record, relation['field_map'])
                    original_id = scalar(source.get('id'), 'source id', True, 500)
                    source['id'] = ident + ':' + name + ':' + original_id
                    mapped_case = source.get('case_id')
                    if mapped_case is not None and str(mapped_case) != ident:
                        raise SourceError('AppWorks relation returned a record for another case.', 'source_scope')
                    source.update(case_id=ident, kind=relation.get('kind', name), source_system='AppWorks', synthetic=False,
                                  source_url=record_uri, original_reference=record_uri + '#' + urllib.parse.quote(original_id, safe=''),
                                  retrieved_at=fetched, record_sha256=digest(record), original_record=record,
                                  schema_map_version=cfg['schema_map_version'])
                    case['sources'].append(source)
            cases.append(case)
        return validate_cases(cases)

    def public(self):
        cfg = self.config
        return {'mode': self.mode, 'label': self.label, 'configured': self.configured, 'read_only': True,
                'instance_verified': False,
                'mapping': {'schema_map_version': cfg['schema_map_version'], 'product_mode': cfg['product_mode'],
                            'property_map': cfg['property_map'], 'relations': sorted(cfg.get('relations', {})),
                            'pagination_configured': bool(cfg.get('next_link_pointer'))},
                'requirements': ['Validate this entity mapping and credential against the actual AppWorks instance.',
                                 'This demo does not implement production repository ACL synchronization or write-back.',
                                 'Source deletions disappear from the active manifest after a complete pull; historical KD records are retained.']}


def source_from_env():
    mode = os.getenv('CASE_SIGNAL_SOURCE', 'fixture')
    if mode == 'fixture':
        return FixtureSource()
    if mode != 'appworks':
        raise SourceError('CASE_SIGNAL_SOURCE must be fixture or appworks.', 'source_configuration')
    config_path = os.getenv('APPWORKS_CONFIG', '')
    if not config_path:
        raise SourceError('APPWORKS_CONFIG must name a mapping JSON file.', 'source_configuration')
    try:
        return AppWorksSource(json.loads(Path(config_path).read_text(encoding='utf-8')))
    except (OSError, ValueError, KeyError) as exc:
        raise SourceError('AppWorks mapping configuration could not be loaded.', 'source_configuration') from exc
