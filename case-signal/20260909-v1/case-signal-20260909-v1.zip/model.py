"""Content records with exact payload verification and case-specific source manifests."""
import base64
import json
import re
import xml.etree.ElementTree as ET

from kd_client import DATABASE, KDError
from sources import canonical, digest

MANIFEST = 'case-signal://active-manifest'


def reference(kind, case_id, source_id=''):
    return 'case-signal://' + kind + '/' + digest([case_id, source_id])


def record(ref, payload, text):
    return {'reference': ref, 'payload': payload, 'text': text.strip(), 'sha256': digest(payload)}


def make_records(cases, source_mode):
    rows = []
    for original in cases:
        case = {k: v for k, v in original.items() if k != 'sources'}
        source_refs = []
        for source in original['sources']:
            item = dict(source, case_id=case['id'], record_type='source')
            ref = reference('source', case['id'], item['id'])
            source_refs.append({'reference': ref, 'sha256': digest(item), 'id': item['id']})
            rows.append(record(ref, item, item['text']))
        case.update(record_type='case', source_refs=source_refs)
        rows.append(record(reference('case', case['id']), case, case['title'] + '\n' + case['description']))
    manifest = {'record_type': 'manifest', 'source_mode': source_mode,
                'cases': [{'id': c['id'], 'reference': reference('case', c['id'])} for c in cases]}
    rows.append(record(MANIFEST, manifest, 'Case Signal active source manifest'))
    return rows


def idx_bytes(records):
    docs = []
    for r in records:
        text = r['text']
        title = r['payload'].get('title', 'Case Signal manifest')
        if any(c in title for c in '\r\n\0') or '\0' in text or re.search(r'^\s*#DRE', text, re.I | re.M):
            raise ValueError('Text cannot contain IDX directives or embedded nulls.')
        encoded = base64.b64encode(canonical(r['payload'])).decode()
        fields = {'CS_PAYLOAD_B64': encoded, 'CS_RECORD_SHA256': r['sha256'], 'CS_TEXT_SHA256': digest(text.encode())}
        lines = ['#DREREFERENCE ' + r['reference'], '#DRETITLE ' + title]
        lines.extend('#DREFIELD ' + key + '="' + value + '"' for key, value in fields.items())
        docs.append('\n'.join(lines + ['#DRECONTENT', text, '#DREENDDOC']))
    return ('\n'.join(docs) + '\n#DREENDDATAREFERENCE\r\n\r\n').encode('utf-8')


def xml_bytes(records):
    envelope = ET.Element('DOCUMENTS')
    for r in records:
        doc = ET.SubElement(envelope, 'DOCUMENT')
        values = {'DREREFERENCE': r['reference'], 'DRETITLE': r['payload'].get('title', 'Case Signal manifest'),
                  'CS_PAYLOAD_B64': base64.b64encode(canonical(r['payload'])).decode(),
                  'CS_RECORD_SHA256': r['sha256'], 'CS_TEXT_SHA256': digest(r['text'].encode()), 'DRECONTENT': r['text']}
        for name, value in values.items():
            if any(ord(c) < 32 and c not in '\n\r\t' for c in value):
                raise ValueError('Source contains unsupported XML control characters.')
            ET.SubElement(doc, name).text = value
    return ET.tostring(envelope, encoding='utf-8') + b'\n#DREENDDATAREFERENCE\r\n\r\n'


def decode_hit(hit):
    if hit.get('database', '').casefold() != DATABASE.casefold():
        raise KDError('Retrieved evidence left the Case Signal database.', 'kd_scope_error')
    fields = hit['fields']
    try:
        raw = base64.b64decode(fields['cs_payload_b64'], validate=True)
        payload = json.loads(raw)
        if canonical(payload) != raw or digest(raw) != fields['cs_record_sha256'] or digest(hit['text'].encode()) != fields['cs_text_sha256']:
            raise ValueError('hash mismatch')
        kind = payload.get('record_type')
        expected = MANIFEST if kind == 'manifest' else reference(kind, payload.get('id') if kind == 'case' else payload.get('case_id'), '' if kind == 'case' else payload.get('id'))
        if kind not in {'manifest', 'case', 'source'} or hit['reference'] != expected:
            raise ValueError('reference mismatch')
        if kind == 'source' and payload['text'] != hit['text']:
            raise ValueError('source text mismatch')
    except (ValueError, KeyError, TypeError, UnicodeError) as exc:
        raise KDError('KD source payload or exact text failed integrity verification.', 'kd_provenance_error') from exc
    return dict(payload, kd_reference=hit['reference'], payload_sha256=digest(raw))


def read_cases(client):
    data = client.query('*', limit=10000)
    if data['total'] != len(data['hits']):
        raise KDError('Case evidence exceeds the complete retrieval bound.', 'kd_results_incomplete')
    records = {}
    for hit in data['hits']:
        if hit['reference'] in records:
            raise KDError('KD returned duplicate case source references.', 'kd_provenance_error')
        records[hit['reference']] = decode_hit(hit)
    if not records:
        return [], None
    manifest = records.get(MANIFEST)
    if manifest is None:
        raise KDError('The active source manifest is absent; sync has not verified.', 'kd_manifest_pending')
    cases, identities = [], set()
    for item in manifest['cases']:
        case = records.get(item['reference'])
        if case is None or case['record_type'] != 'case' or case['id'] != item['id'] or case['id'] in identities:
            raise KDError('The current case manifest has not verified in KD.', 'kd_manifest_pending')
        identities.add(case['id'])
        sources = []
        for src in case['source_refs']:
            found = records.get(src['reference'])
            if found is None or found.get('case_id') != case['id'] or found.get('id') != src['id'] or found['payload_sha256'] != src['sha256']:
                raise KDError('The exact case source revision has not verified in KD.', 'kd_manifest_pending')
            sources.append(found)
        case['sources'] = sorted(sources, key=lambda s: (s['updated_at'], s['id']))
        cases.append(case)
    return cases, manifest


def source_snapshot(case):
    sources = case['sources']
    return {'case_id': case['id'], 'case_sha256': case['payload_sha256'],
            'sources': sources, 'sha256': digest([case['payload_sha256'], [(s['id'], s['payload_sha256']) for s in sources]])}
