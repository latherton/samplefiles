"""Journal before every native index request; resume exact receipts without uncertain replay."""
import argparse
from contextlib import contextmanager
import json
import os
from pathlib import Path
import time
import uuid

from kd_client import KDClient, KDError, DATABASE
from model import decode_hit, xml_bytes, make_records, read_cases
from sources import digest, now, source_from_env
from store import Store


@contextmanager
def locked(directory):
    path = Path(directory) / 'index.lock'
    with path.open('a+b') as handle:
        if os.name == 'posix':
            import fcntl
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise KDError('An indexing operation already owns the journal.', 'sync_busy') from exc
        else:
            import msvcrt
            handle.seek(0)
            if not handle.read(1):
                handle.write(b'0')
                handle.flush()
            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as exc:
                raise KDError('An indexing operation already owns the journal.', 'sync_busy') from exc
        yield


def other_databases(client):
    result = {}
    for name in client.databases():
        if name.casefold() == DATABASE.casefold():
            continue
        data = client.query('*', database=name, limit=10000, print_fields=False)
        if data['total'] != len(data['hits']) or any(not h['reference'] for h in data['hits']):
            raise KDError('Other-database reference continuity cannot be established.', 'preservation_unverified')
        refs = sorted(h['reference'] for h in data['hits'])
        result[name] = {'count': len(refs), 'references_sha256': digest(refs)}
    return result


class Indexer:
    def __init__(self, client, store, source, timeout=150, poll=1):
        self.client, self.store, self.source = client, store, source
        self.timeout, self.poll = timeout, poll
        self.run = None

    def save(self, status=None, message=None):
        if status:
            self.run['status'] = status
        if message:
            self.run['message'] = message
        self.run['updated_at'] = now()
        self.store.save_run(self.run)

    def submit(self, action, records=None):
        records = records or []
        data = xml_bytes(records) if action == 'DREADDDATA' else b''
        job = {'action': action, 'records': len(records), 'body_sha256': digest(data), 'intent_at': now(),
               'index_id': None, 'complete': False, 'commit': None}
        self.run['jobs'].append(job)
        self.save('pending', 'Native index intent retained; awaiting its exact receipt.')
        job['index_id'] = self.client.index(action, data)
        self.save('pending', 'Original native index receipt retained.')
        self.wait(job)

    def wait(self, job):
        if job['index_id'] is None:
            raise KDError('Prior index intent has an uncertain outcome. Inspect it; no resubmission is permitted.', 'index_receipt_uncertain')
        deadline = time.monotonic() + self.timeout
        while True:
            state, count = self.client.index_status(job['index_id'])
            job.update(last_status=state, documents_processed=count)
            self.save('pending', 'Following the original native KD index job.')
            if state == -1:
                if job['action'] == 'DREADDDATA' and count != job['records']:
                    raise KDError('Completed native index job has a different record count.', 'index_count_mismatch')
                job['complete'] = True
                self.save()
                return
            if state == -34:
                if job['action'] == 'DREADDDATA' and count != job['records']:
                    raise KDError('Pending commit has an unexpected record count.', 'index_count_mismatch')
                if job['commit'] is None:
                    job['commit'] = {'intent_at': now(), 'index_id': None}
                    self.save('pending', 'Pending-cache commit intent retained.')
                    job['commit']['index_id'] = self.client.index('DRESYNC')
                    self.save('pending', 'Following the retained cache-commit receipt.')
                elif job['commit']['index_id'] is None:
                    raise KDError('Cache-commit receipt is uncertain; no automatic replay.', 'index_receipt_uncertain')
            elif state < 0 and state not in {-7, -8, -12, -13, -16, -17}:
                raise KDError('Native index job failed with status ' + str(state) + '.', 'index_failed')
            if time.monotonic() >= deadline:
                raise KDError('Index job remains pending. Resume this original receipt; do not resubmit.', 'index_pending')
            time.sleep(self.poll)

    def execute(self, resume=False):
        with locked(self.store.directory):
            identity = {'database': DATABASE, 'request_format': 'XML', 'document_delimiters': '*/DOCUMENT',
                        'connection_sha256': digest((self.client.aci_url + '\n' + str(self.client.index_url)).encode())}
            previous = next((r for r in self.store.runs() if r['status'] != 'verified' and r.get('jobs')), None)
            if previous:
                if not resume:
                    raise KDError('An incomplete native index operation exists. Resume its original receipt.', 'index_pending')
                if any(previous.get(k) != value for k, value in identity.items()):
                    raise KDError('Resume requires the same KD connection, database and XML request format.', 'resume_identity_mismatch')
                self.run = previous
            else:
                if resume:
                    raise KDError('No retained native index operation needs resume.', 'resume_unavailable')
                self.run = {'id': 'SYNC-' + uuid.uuid4().hex[:12].upper(), 'started_at': now(), 'updated_at': now(),
                            'status': 'pulling', 'message': 'Reading the configured case source.', 'jobs': [],
                            'source_mode': self.source.mode, 'source_label': self.source.label, **identity}
                self.save()
            try:
                if not self.run.get('records'):
                    cases = self.source.pull()
                    self.run['records'] = make_records(cases, self.source.mode)
                    self.run['source_case_count'] = len(cases)
                    self.run['source_record_count'] = sum(len(c['sources']) for c in cases)
                    self.run['other_databases_before'] = other_databases(self.client)
                    self.save('pending', 'Complete source snapshot retained before indexing.')
                for job in self.run['jobs']:
                    if not job['complete']:
                        self.wait(job)
                names = self.client.databases()
                if DATABASE not in names:
                    if any(j['action'] == 'DRECREATEDBASE' for j in self.run['jobs']):
                        raise KDError('A completed create request has no verifiable database; no replay.', 'index_verification_failed')
                    self.submit('DRECREATEDBASE')
                existing = self.client.query('*', limit=10000)
                if existing['total'] != len(existing['hits']):
                    raise KDError('Dedicated database inventory exceeds its bound.', 'kd_results_incomplete')
                by_ref = {h['reference']: decode_hit(h) for h in existing['hits']}
                changed = [r for r in self.run['records'] if by_ref.get(r['reference'], {}).get('payload_sha256') != r['sha256']]
                if changed:
                    if any(j['action'] == 'DREADDDATA' for j in self.run['jobs']):
                        raise KDError('Submitted source revisions did not verify; no automatic reindex.', 'index_verification_failed')
                    self.submit('DREADDDATA', changed)
                verified = self.client.query('*', limit=10000)
                actual = {h['reference']: decode_hit(h) for h in verified['hits']}
                if verified['total'] != len(verified['hits']) or any(actual.get(r['reference'], {}).get('payload_sha256') != r['sha256'] for r in self.run['records']):
                    raise KDError('Exact retained source records have not verified in KD.', 'index_verification_failed')
                current, manifest = read_cases(self.client)
                if len(current) != self.run['source_case_count'] or sum(len(c['sources']) for c in current) != self.run['source_record_count']:
                    raise KDError('KD active case/source inventory did not match the pulled snapshot.', 'index_verification_failed')
                after = other_databases(self.client)
                self.run['other_databases_after'] = after
                if after != self.run['other_databases_before']:
                    raise KDError('Other-database reference/count continuity changed during this operation.', 'preservation_changed')
                self.run.update(completed_at=now(), error=None, preservation_verified=True, verified_records=len(self.run['records']))
                self.save('verified', 'Source records, exact KD text and other-database reference continuity verified.')
                return self.run
            except Exception as exc:
                code = getattr(exc, 'code', 'sync_failed')
                message = str(exc) if isinstance(exc, (KDError, ValueError)) or hasattr(exc, 'code') else 'Sync failed; inspect the local service log and retained receipt.'
                self.run['error'] = {'code': code, 'message': message}
                self.save('pending' if code == 'index_pending' else 'error', message)
                raise


def public_run(run):
    return {k: v for k, v in run.items() if k in {'id', 'started_at', 'updated_at', 'completed_at', 'status', 'message',
            'source_mode', 'source_label', 'source_case_count', 'source_record_count', 'verified_records', 'preservation_verified', 'error'}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state-dir', default=os.getenv('CASE_SIGNAL_STATE_DIR', '/var/lib/case-signal'))
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--timeout', type=int, default=150)
    args = parser.parse_args()
    report = Indexer(KDClient(), Store(args.state_dir), source_from_env(), timeout=args.timeout).execute(args.resume)
    print(json.dumps(public_run(report), indent=2))


if __name__ == '__main__':
    main()
