"""Small bounded Content 26.1 ACI client; never performs local search fallback."""
import ipaddress
import json
import math
import os
import re
import subprocess
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

DATABASE = 'CASE_SIGNAL_DEMO'
BACKEND = 'OpenText Knowledge Discovery Content'
MAX_RESPONSE = 24 * 1024 * 1024


class KDError(RuntimeError):
    def __init__(self, message, code='kd_unavailable'):
        super().__init__(message)
        self.code = code


def local(tag):
    return tag.rsplit('}', 1)[-1].lower()


def children(node, name):
    return [n for n in node if local(n.tag) == name.lower()]


def value(node, name, default=''):
    rows = children(node, name)
    return (rows[0].text or '').strip() if len(rows) == 1 else default


def parse_xml(raw):
    if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():
        raise KDError('KD returned an unsupported XML response.', 'kd_response_invalid')
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as exc:
        raise KDError('KD returned malformed XML.', 'kd_response_invalid') from exc
    if local(root.tag) != 'autnresponse' or value(root, 'response').upper() != 'SUCCESS':
        # Native error IDs are useful; never expose raw query text or tokens.
        ids = [n.text or '' for n in root.iter() if local(n.tag) == 'errorid']
        code = ids[0] if len(ids) == 1 and re.fullmatch(r'[A-Za-z0-9_.-]{1,100}', ids[0]) else 'kd_native_error'
        raise KDError('KD could not complete this request. Check the service or indexing receipt.', code)
    return root


def parse_hits(raw):
    root = parse_xml(raw)
    data = children(root, 'responsedata')
    if len(data) != 1:
        raise KDError('KD response has no result data.', 'kd_response_invalid')
    hits = []
    for hit in children(data[0], 'hit'):
        content = children(hit, 'content')
        fields = {}
        for section in content:
            for node in section.iter():
                key = local(node.tag)
                if key.startswith('cs_') or key in {'drecontent', 'content'} and not list(node):
                    text = ''.join(node.itertext()).strip()
                    if text:
                        if key in fields and fields[key] != text:
                            raise KDError('KD returned ambiguous record metadata.', 'kd_response_invalid')
                        fields[key] = text
        try:
            score = float(value(hit, 'weight', '0'))
        except ValueError:
            score = 0.0
        hits.append({'reference': value(hit, 'reference'), 'database': value(hit, 'database'),
                     'score': score if math.isfinite(score) else 0.0, 'title': value(hit, 'title'),
                     'summary': value(hit, 'summary'), 'text': fields.get('drecontent', fields.get('content', '')),
                     'fields': fields})
    total = value(data[0], 'totalhits')
    if not total.isdigit():
        raise KDError('KD did not return a verifiable total result count.', 'kd_response_invalid')
    return {'hits': hits, 'total': int(total)}


def validate_url(url):
    p = urllib.parse.urlsplit(url)
    if p.scheme != 'http' or not p.hostname or p.username or p.password or p.path not in ('', '/') or p.query or p.fragment:
        raise ValueError('Use an explicit internal http://host:port KD endpoint without credentials or a path.')
    if p.port is None:
        raise ValueError('KD endpoint must specify its port.')
    return url.rstrip('/')


def discover_urls():
    aci, index = os.getenv('KD_CONTENT_URL'), os.getenv('KD_INDEX_URL')
    if aci:
        aci = validate_url(aci)
        return aci, validate_url(index) if index else None
    try:
        ids = subprocess.run(['docker', 'ps', '--filter', 'label=com.docker.compose.project=basic-idol',
                              '--filter', 'label=com.docker.compose.service=idol-content', '--quiet', '--no-trunc'],
                             capture_output=True, timeout=10, check=True).stdout.decode().split()
        if len(ids) != 1 or not re.fullmatch('[0-9a-f]{64}', ids[0]):
            raise ValueError('one running Content required')
        result = subprocess.run(['docker', 'inspect', ids[0]], capture_output=True, timeout=10, check=True)
        if len(result.stdout) > 1024 * 1024:
            raise ValueError('inspection too large')
        container = json.loads(result.stdout)[0]
        networks = container['NetworkSettings']['Networks']
        addresses = {v['IPAddress'] for v in networks.values() if v.get('IPAddress')}
        if len(addresses) != 1 or not container['State']['Running']:
            raise ValueError('unambiguous running endpoint required')
        host = str(ipaddress.IPv4Address(addresses.pop()))
        return f'http://{host}:9100', f'http://{host}:9101'
    except (OSError, subprocess.SubprocessError, ValueError, KeyError, IndexError) as exc:
        raise KDError('Cannot locate Content. Set KD_CONTENT_URL and KD_INDEX_URL or run on its Docker host.') from exc


class KDClient:
    def __init__(self, aci_url=None, index_url=None, timeout=15):
        if aci_url is None:
            aci_url, discovered_index = discover_urls()
            index_url = index_url or discovered_index
        self.aci_url = validate_url(aci_url)
        self.index_url = validate_url(index_url) if index_url else None
        self.timeout = timeout
        # Internal evidence must not leave via an ambient outbound proxy.
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def request(self, url, data=None, content_type='application/x-www-form-urlencoded'):
        request = urllib.request.Request(url, data=data, headers={'Content-Type': content_type})
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                raw = response.read(MAX_RESPONSE + 1)
            if len(raw) > MAX_RESPONSE:
                raise KDError('KD response exceeded the bounded demo limit.', 'kd_response_too_large')
            return raw
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise KDError('KD is unavailable or timed out. Evidence search has not used a local fallback.') from exc

    def aci(self, action, **params):
        data = urllib.parse.urlencode({'Action': action, **params}).encode()
        return self.request(self.aci_url + '/', data)

    def query(self, text='*', database=DATABASE, limit=1000, print_fields=True):
        if not 1 <= limit <= 10000:
            raise ValueError('Invalid bounded query limit.')
        raw = self.aci('Query', Text=text or '*', DatabaseMatch=database, MaxResults=limit,
                       TotalResults='True', Print='All' if print_fields else 'None',
                       Summary='Context' if print_fields else 'None', Characters=500,
                       Combine='Simple', AnyLanguage='True', MinScore=0)
        result = parse_hits(raw)
        if any(hit['database'].casefold() != database.casefold() for hit in result['hits']):
            raise KDError('KD returned a record outside the requested database.', 'kd_scope_error')
        return result

    def databases(self):
        root = parse_xml(self.aci('GetStatus'))
        names = []
        for node in root.iter():
            if local(node.tag) == 'database':
                name = value(node, 'name')
                if name:
                    names.append(name)
        if not names or len(names) != len(set(names)):
            raise KDError('Cannot verify the Content database inventory.', 'kd_response_invalid')
        return sorted(names)

    def index(self, action, data=b''):
        if not self.index_url:
            raise KDError('KD_INDEX_URL is required for explicitly requested indexing.')
        if action == 'DRECREATEDBASE':
            params = {'DREDbName': DATABASE}
        elif action == 'DREADDDATA':
            params = {'DREDbName': DATABASE, 'KillDuplicates': 'REFERENCE',
                      'KillDuplicatesMatchTargetDB': 'True', 'KillDuplicatesMatchDBs': DATABASE,
                      'LanguageType': 'EnglishUTF8', 'DocumentFormat': 'XML', 'DocumentDelimiters': '*/DOCUMENT'}
        elif action == 'DRESYNC':
            params = {}
        else:
            raise ValueError('Only dedicated demo create/index or pending-cache commit is permitted.')
        raw = self.request(self.index_url + '/' + action + '?' + urllib.parse.urlencode(params),
                           data, 'application/xml' if action == 'DREADDDATA' else 'application/octet-stream')
        match = re.fullmatch(rb'\s*INDEXID=(\d+)\s*', raw)
        if not match:
            raise KDError('Index receipt not recognized; inspect the retained intent before resubmitting.', 'index_receipt_uncertain')
        return int(match.group(1))

    def index_status(self, index_id):
        root = parse_xml(self.aci('IndexerGetStatus', Index=index_id, MaxResults=1))
        items = [n for n in root.iter() if local(n.tag) == 'item']
        if len(items) != 1 or value(items[0], 'id') != str(index_id):
            raise KDError('The exact original index job cannot be verified.', 'index_status_unknown')
        state = value(items[0], 'status')
        processed = value(items[0], 'documents_processed')
        if not re.fullmatch('-?[0-9]+', state):
            raise KDError('Index status has an unexpected shape.', 'index_status_unknown')
        return int(state), int(processed) if processed.isdigit() else None
