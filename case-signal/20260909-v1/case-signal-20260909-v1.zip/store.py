"""Durable sync receipts and immutable summary/source snapshots in SQLite."""
import json
from pathlib import Path
import sqlite3
from contextlib import contextmanager


class Store:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / 'case-signal.sqlite3'
        with self.db() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, updated_at TEXT NOT NULL, payload TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS summaries(id TEXT PRIMARY KEY, case_id TEXT NOT NULL,
              snapshot_sha256 TEXT NOT NULL, created_at TEXT NOT NULL, payload TEXT NOT NULL, snapshot TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS summaries_case ON summaries(case_id, created_at);
            ''')

    @contextmanager
    def db(self):
        db = sqlite3.connect(self.path, timeout=20)
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('PRAGMA synchronous=FULL')
        try:
            yield db
            db.commit()
        finally:
            db.close()

    def save_run(self, run):
        with self.db() as db:
            db.execute('INSERT OR REPLACE INTO runs VALUES(?,?,?)', (run['id'], run['updated_at'], json.dumps(run)))

    def runs(self):
        with self.db() as db:
            return [json.loads(row[0]) for row in db.execute('SELECT payload FROM runs ORDER BY updated_at DESC')]

    def save_summary(self, summary, snapshot):
        with self.db() as db:
            db.execute('INSERT INTO summaries VALUES(?,?,?,?,?,?)',
                       (summary['id'], snapshot['case_id'], snapshot['sha256'], summary['created_at'], json.dumps(summary), json.dumps(snapshot)))

    def latest_summary(self, case_id, snapshot_sha256):
        with self.db() as db:
            row = db.execute('SELECT payload FROM summaries WHERE case_id=? AND snapshot_sha256=? ORDER BY created_at DESC LIMIT 1',
                             (case_id, snapshot_sha256)).fetchone()
            return json.loads(row[0]) if row else None

    def summary_snapshot(self, summary_id):
        with self.db() as db:
            row = db.execute('SELECT snapshot FROM summaries WHERE id=?', (summary_id,)).fetchone()
            return json.loads(row[0]) if row else None
