#!/usr/bin/env python3
"""Normalize one sensor snapshot; explicitly apply only to its dedicated KD DB.

Dry-run emits a canonical JSON receipt, review IDX and exact XML request body.
XML is submitted so embedded JSON quotation marks have unambiguous escaping.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys
import time
import urllib.parse
import xml.etree.ElementTree as ET

from index_corpus import locked, save
from kd_client import KDClient, KDError
from sensor_kd import (SCHEMA, SensorKD, canonical, load_json, payload_hash,
                       reference_for, sensor_database, utc_timestamp, validate_snapshot)

XML_DOCUMENT_DELIMITERS = '/DOCUMENT'


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def fields_for(payload):
    payload = validate_snapshot(payload)
    return {'FE_SENSOR_SCHEMA': SCHEMA, 'FE_SENSOR_SOURCE_ID': payload['source_id'],
            'FE_SENSOR_ASSET_ID': payload['asset_id'],
            'FE_SENSOR_SYNTHETIC': str(payload['synthetic']).lower(),
            'FE_SENSOR_SHA256': payload_hash(payload), 'FE_SENSOR_PAYLOAD': canonical(payload)}


def idx_bytes(payload):
    """Human-inspectable IDX companion; XML is the actual submission artifact.

    The payload is placed on one line and cannot contain IDX directives. We do
    not claim an installed-engine round trip for embedded JSON quotes in IDX.
    """
    fields = fields_for(payload)
    title = 'Sensor snapshot ' + payload['source_id'] + ' ' + payload['asset_id']
    lines = ['#DREREFERENCE ' + reference_for(payload['source_id'], payload['asset_id']), '#DRETITLE ' + title]
    lines.extend('#DREFIELD ' + key + '="' + value + '"' for key, value in fields.items())
    lines.extend(['#DRECONTENT', title, '#DREENDDOC', '#DREENDDATAREFERENCE'])
    return ('\n'.join(lines) + '\r\n\r\n').encode('utf-8')


def xml_bytes(payload):
    fields = fields_for(payload)
    doc = ET.Element('DOCUMENT')
    ET.SubElement(doc, 'DREREFERENCE').text = reference_for(payload['source_id'], payload['asset_id'])
    title = 'Sensor snapshot ' + payload['source_id'] + ' ' + payload['asset_id']
    ET.SubElement(doc, 'DRETITLE').text = title
    for name, value in fields.items():
        ET.SubElement(doc, name).text = value
    ET.SubElement(doc, 'DRECONTENT').text = title + ' · ' + ('synthetic' if payload['synthetic'] else 'source-reported measurements')
    return ET.tostring(doc, encoding='utf-8') + b'\n#DREENDDATAREFERENCE\r\n\r\n'


def submit_native(client, database, action, body=b''):
    database = sensor_database(database)
    if not client.index_url:
        raise KDError('KD_INDEX_URL is required for explicit sensor indexing.', 'sensor_index_unconfigured')
    if action == 'DRECREATEDBASE':
        params = {'DREDbName': database}
    elif action == 'DREADDDATA':
        params = {'DREDbName': database, 'KillDuplicates': 'REFERENCE',
                  'KillDuplicatesMatchTargetDB': 'True', 'KillDuplicatesMatchDBs': database,
                  'LanguageType': 'EnglishUTF8', 'DocumentFormat': 'XML',
                  'DocumentDelimiters': XML_DOCUMENT_DELIMITERS}
    elif action == 'DRESYNC':
        params = {}
    else:
        raise ValueError('Only dedicated sensor create/add and explicitly allowed pending-cache sync are supported.')
    raw = client.request(client.index_url + '/' + action + '?' + urllib.parse.urlencode(params),
                         body, 'application/xml' if action == 'DREADDDATA' else 'application/octet-stream')
    match = re.fullmatch(rb'\s*INDEXID=(\d+)\s*', raw)
    if not match:
        raise KDError('Sensor index receipt is uncertain; inspect the retained request intent before any new operation.', 'index_receipt_uncertain')
    return int(match.group(1))


class SensorIndexer:
    def __init__(self, client, payload, receipt, database=None, timeout=180, poll=1, allow_sync=False):
        self.client, self.payload = client, validate_snapshot(payload)
        self.database = sensor_database(database)
        self.receipt = Path(receipt)
        if not 1 <= timeout <= 900 or poll < 0:
            raise ValueError('Index timeout must be 1–900 seconds, with nonnegative polling interval.')
        self.timeout, self.poll, self.allow_sync = timeout, poll, allow_sync
        self.body = xml_bytes(self.payload)
        self.report = None

    def write(self, stage):
        self.report['stage'], self.report['updated_at'] = stage, now()
        save(self.receipt, self.report)

    def inspect(self):
        exists = any(name.casefold() == self.database.casefold() for name in self.client.databases())
        rows = SensorKD(self.client, self.database).records() if exists else []
        selected = [row for row in rows if row['payload']['source_id'] == self.payload['source_id']
                    and row['payload']['asset_id'] == self.payload['asset_id']]
        current = SensorKD.latest(selected)['payload'] if selected else None
        if current is not None and canonical(current) != canonical(self.payload):
            if utc_timestamp(current['samples'][-1]['timestamp']) >= utc_timestamp(self.payload['samples'][-1]['timestamp']):
                raise KDError('Incoming snapshot is older than, or conflicts at the timestamp of, the stored snapshot.', 'sensor_stale_update')
        return {'exists': exists, 'records': len(rows), 'needs_update': current is None or canonical(current) != canonical(self.payload)}

    def wait(self, job):
        if type(job.get('index_id')) is not int:
            raise KDError('A retained sensor write has an uncertain outcome; it must not be automatically resubmitted.', 'index_receipt_uncertain')
        deadline = time.monotonic() + self.timeout
        while time.monotonic() < deadline:
            status, count = self.client.index_status(job['index_id'])
            job['last_status'], job['documents_processed'] = status, count
            self.write('waiting-for-original-index-id')
            if status == -1:
                if job['action'] == 'DREADDDATA' and count != 1:
                    raise KDError('Sensor index job processed an unexpected number of records.', 'sensor_index_count_mismatch')
                job['complete'] = True
                self.write('original-index-job-complete')
                return
            if status == -34:
                if job['action'] == 'DREADDDATA' and count != 1:
                    raise KDError('Pending sensor index job has an unexpected record count.', 'sensor_index_count_mismatch')
                if not self.allow_sync:
                    raise KDError('Sensor job awaits cache commit. DRESYNC flushes all Content pending data. Wait and --resume, or explicitly --resume --allow-sync.', 'sensor_pending_sync')
                if job['commit'] is None:
                    job['commit'] = {'intent_at': now(), 'index_id': None}
                    self.write('content-wide-sync-intent')
                    job['commit']['index_id'] = submit_native(self.client, self.database, 'DRESYNC')
                    self.write('content-wide-sync-receipt-retained')
                elif job['commit'].get('index_id') is None:
                    raise KDError('The prior Content cache-sync outcome is uncertain; no automatic retry is allowed.', 'index_receipt_uncertain')
            elif status < 0 and status not in {-7, -8, -12, -13, -16, -17}:
                raise KDError('Sensor index job failed with status ' + str(status) + '.', 'sensor_index_failed')
            if self.poll:
                time.sleep(self.poll)
        raise KDError('Sensor index job remains pending. Resume this exact receipt; do not submit the input again.', 'index_pending')

    def submit(self, action):
        body = self.body if action == 'DREADDDATA' else b''
        job = {'action': action, 'index_id': None, 'body_sha256': sha(body), 'intent_at': now(), 'complete': False, 'commit': None}
        self.report['jobs'].append(job)
        self.write('sensor-request-intent')
        job['index_id'] = submit_native(self.client, self.database, action, body)
        self.write('sensor-index-receipt-retained')
        self.wait(job)

    def run(self, resume=False):
        identity = {'database': self.database, 'reference': reference_for(self.payload['source_id'], self.payload['asset_id']),
                    'payload_sha256': payload_hash(self.payload), 'request_sha256': sha(self.body),
                    'document_delimiters': XML_DOCUMENT_DELIMITERS,
                    'connection_sha256': sha((self.client.aci_url + '\n' + str(self.client.index_url)).encode())}
        if resume:
            self.report = load_json(self.receipt.read_bytes())
            if (not isinstance(self.report, dict) or any(self.report.get(key) != value for key, value in identity.items())
                    or self.report.get('complete') is True or self.report.get('dry_run') is True
                    or not isinstance(self.report.get('jobs'), list)):
                raise ValueError('Resume requires the incomplete receipt for this exact snapshot, XML document delimiter, database and KD connection.')
            if self.allow_sync:
                self.report['allow_content_wide_sync'] = True
                self.write('resume-with-explicit-content-wide-sync-permission')
            for job in self.report['jobs']:
                if job.get('action') not in {'DRECREATEDBASE', 'DREADDDATA'}:
                    raise ValueError('Receipt contains an unsupported operation.')
                if not job.get('complete'):
                    self.wait(job)
        else:
            if self.receipt.exists():
                prior = load_json(self.receipt.read_bytes())
                if prior.get('complete') is not True and prior.get('dry_run') is not True:
                    raise ValueError('An incomplete sensor receipt exists. Use --resume; do not replay its writes.')
                archive = self.receipt.with_name(self.receipt.stem + '-' + sha(self.receipt.read_bytes())[:16] + '.json')
                if not archive.exists():
                    with archive.open('xb') as out:
                        out.write(self.receipt.read_bytes())
            self.report = {**identity, 'schema': SCHEMA, 'started_at': now(), 'complete': False,
                           'dry_run': False, 'request_format': 'XML', 'jobs': [],
                           'synthetic': self.payload['synthetic'], 'sample_count': len(self.payload['samples']),
                           'allow_content_wide_sync': self.allow_sync}
            self.write('sensor-operation-started')
        plan = self.inspect()
        self.report['plan'] = plan
        self.write('sensor-inventory-checked')
        if not plan['exists']:
            if any(job['action'] == 'DRECREATEDBASE' for job in self.report['jobs']):
                raise KDError('Completed sensor database creation is not visible; no automatic replay.', 'sensor_readback_mismatch')
            self.submit('DRECREATEDBASE')
        if plan['needs_update']:
            if any(job['action'] == 'DREADDDATA' for job in self.report['jobs']):
                raise KDError('Completed sensor write is not reflected in KD; no automatic reindex.', 'sensor_readback_mismatch')
            self.submit('DREADDDATA')
        actual = SensorKD(self.client, self.database).snapshot(self.payload['source_id'], self.payload['asset_id'])
        if canonical({key: actual[key] for key in self.payload}) != canonical(self.payload):
            raise KDError('Sensor source readback did not match the submitted snapshot.', 'sensor_readback_mismatch')
        self.report['verified_provenance'] = actual['provenance']
        self.report['complete'] = True
        self.write('sensor-snapshot-live-readback-verified')
        return self.report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True, help='One fleet.sensor.v1 JSON snapshot.')
    parser.add_argument('--receipt', type=Path, help='Default: INPUT.sensor-receipt.json. Preserve incomplete receipts.')
    parser.add_argument('--output', type=Path, help='IDX review artifact; exact XML request uses the same name with .xml suffix.')
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--dry-run', action='store_true', help='Default. Write local artifacts only; no KD connection.')
    mode.add_argument('--apply', action='store_true', help='Explicitly create/update the dedicated sensor database.')
    mode.add_argument('--resume', action='store_true', help='Poll a retained write; never automatically replay a submission.')
    parser.add_argument('--database', help='Dedicated sensor DB; defaults to KD_SENSOR_DATABASE or FLEET_SENSOR_DEMO.')
    parser.add_argument('--allow-sync', action='store_true', help='Explicitly permit one Content-wide pending-cache DRESYNC if needed.')
    parser.add_argument('--timeout', type=int, default=180)
    args = parser.parse_args()
    if args.input.stat().st_size > 128 * 1024:
        parser.error('Input exceeds the bounded 128 KiB snapshot limit.')
    payload = validate_snapshot(load_json(args.input.read_bytes()))
    database = sensor_database(args.database)
    receipt = args.receipt or args.input.with_suffix('.sensor-receipt.json')
    idx_path = args.output or args.input.with_suffix('.sensor.idx')
    xml_path = idx_path.with_suffix('.xml')
    paths = [args.input.resolve(), receipt.resolve(), idx_path.resolve(), xml_path.resolve()]
    if len(set(paths)) != 4:
        parser.error('Input, receipt, IDX and XML paths must be distinct.')
    with locked(receipt):
        if not args.apply and not args.resume:
            if receipt.exists():
                prior = load_json(receipt.read_bytes())
                if prior.get('dry_run') is not True:
                    raise ValueError('Dry-run cannot overwrite an indexing receipt. Choose a different --receipt.')
            for path, raw in ((idx_path, idx_bytes(payload)), (xml_path, xml_bytes(payload))):
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(raw)
            report = {'schema': SCHEMA, 'dry_run': True, 'complete': False, 'created_at': now(),
                      'database': database, 'reference': reference_for(payload['source_id'], payload['asset_id']),
                      'synthetic': payload['synthetic'], 'sample_count': len(payload['samples']),
                      'payload_sha256': payload_hash(payload), 'request_format': 'XML',
                      'document_delimiters': XML_DOCUMENT_DELIMITERS,
                      'request_sha256': sha(xml_bytes(payload)), 'idx_review_artifact': str(idx_path.resolve()),
                      'xml_submission_artifact': str(xml_path.resolve()), 'network_calls': 0}
            save(receipt, report)
        else:
            client = KDClient()
            report = SensorIndexer(client, payload, receipt, database, args.timeout, allow_sync=args.allow_sync).run(args.resume)
    print(json.dumps({'complete': report['complete'], 'dry_run': report['dry_run'], 'database': database,
                      'receipt': str(receipt.resolve()), 'request_format': 'XML'}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (KDError, ValueError, OSError) as exc:
        print(type(exc).__name__ + ': ' + str(exc), file=sys.stderr)
        sys.exit(1)
