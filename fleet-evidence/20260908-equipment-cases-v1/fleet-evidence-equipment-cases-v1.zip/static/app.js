/* FleetEvidence: live retrieval with explicitly authored demonstration metadata. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const paths = {
    activity:'M2 12h5l3-8 4 16 3-8h5',
    connection:'M7 8V4h10v4M7 16v4h10v-4M4 8h6v8H4zM14 8h6v8h-6zM10 12h4',
    workspace:'M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z',
    library:'M4 4v16M9 4v16M14 4v16M18 4l3 16M3 20h19',
    packet:'M6 3h9l4 4v14H6zM14 3v5h5M9 12h7M9 16h7',
    training:'m2 8 10-5 10 5-10 5zM6 10v6c4 3 8 3 12 0v-6M22 8v8',
    compass:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18m4 5-2 6-6 2 2-6z',
    info:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18M12 11v6M12 7v.1',
    equipment:'M4 9h4V6h8v12H8v-3H4zM16 8h5v10h-5M3 20h19M11 3v3M10 10h3M10 14h3',
    search:'M10.5 3a7.5 7.5 0 1 0 0 15 7.5 7.5 0 0 0 0-15M16 16l5 5',
    'arrow-right':'M4 12h16M14 6l6 6-6 6',
    'arrow-up-right':'M6 18 18 6M6 6h12v12',
    refresh:'M20 7a9 9 0 0 0-15-2L2 8m0-5v5h5M4 17a9 9 0 0 0 15 2l3-3m0 5v-5h-5',
    inspect:'M8 3h9l4 4v12H11M16 3v5h5M7 9a5 5 0 1 0 0 10 5 5 0 0 0 0-10M3 18l-2 3',
    shield:'m12 2 8 4v6c0 5-8 10-8 10S4 17 4 12V6zM8 12l3 3 5-6',
    edit:'m4 16 12-12 4 4L8 20H4zM14 6l4 4M3 22h18',
    download:'M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5',
    print:'M6 8V3h12v5M6 17H3V9h18v8h-3M6 14h12v7H6zM17 11h1',
    check:'m5 12 4 4L19 6', close:'m6 6 12 12M6 18 18 6',
    flask:'M9 3h6M10 3v6l-6 10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2L14 9V3M7 15h10',
    manual:'M3 4c4-1 7 0 9 2 2-2 5-3 9-2v15c-4-1-7 0-9 2-2-2-5-3-9-2zM12 6v15',
    work_order:'M5 4h4V2h6v2h4v18H5zM9 4v3h6V4M8 12h8M8 16h5',
    inspection:'M5 3h14v18H5zM8 8l2 2 4-4M8 15h8M8 18h5',
    bulletin:'M4 4h16v16H4zM8 8h8M8 12h8M8 16h4',
    turnover:'M4 5h12v14H4zM8 9h5M8 13h4M18 9l4 4-4 4M15 13h7',
    copy:'M8 8h13v13H8zM16 4V2H2v14h2',
    revision:'M3 12a9 9 0 1 0 3-7L3 8m0-5v5h5M12 7v5l3 2',
    identity:'M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8M4 21v-3c0-3 4-5 8-5 2 0 4 .5 5 1M20 16v2M20 21v.1',
    plus:'M12 5v14M5 12h14', link:'m10 14 4-4M8 16l-2 2a4 4 0 0 1-6-6l4-4a4 4 0 0 1 6 0M14 8l2-2a4 4 0 1 1 6 6l-4 4a4 4 0 0 1-6 0',
    file:'M5 3h10l4 4v14H5zM14 3v5h5M8 12h8M8 16h5',
    alert:'M12 3 2 21h20zM12 9v5M12 17v.1',
    empty:'M3 8h18v13H3zM3 8l4-5h10l4 5M3 13h5l2 3h4l2-3h5'
  };
  const icon = name => `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name] || paths.file}"/></svg>`;
  const hydrate = (root = document) => root.querySelectorAll('[data-icon]').forEach(el => { el.innerHTML = icon(el.dataset.icon); });
  const kindNames = {manual:'Guidance',work_order:'Work order',inspection:'Inspection',bulletin:'Bulletin',training:'Training',turnover:'Turnover'};
  const flagNames = {duplicate:'Duplicate copy',superseded:'Earlier revision',missing_identity:'Identity incomplete',conflicting_record:'Conflicting record'};
  const statusNames = {current:'Current',superseded:'Superseded',historical:'Historical',unresolved:'Needs review'};
  const storageKey = 'fleet-evidence.workspace.v1';
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(storageKey) || '{}'); } catch (_) { /* Private browsing can disable local storage. */ }
  if (!saved || typeof saved !== 'object' || Array.isArray(saved)) saved = {};
  const state = {
    view:'mission', assets:[], assetId:typeof saved.assetId === 'string' ? saved.assetId : 'A-17',
    records:new Map(), selected:new Set(Array.isArray(saved.ids) ? saved.ids.filter(id => typeof id === 'string').slice(0,100) : []),
    notes:typeof saved.notes === 'string' ? saved.notes.slice(0,12000) : '',
    condition:saved.condition && typeof saved.condition === 'object' && !Array.isArray(saved.condition) ? saved.condition : null,
    query:'', kind:'all', scope:'applicable', history:false, sort:'relevance', results:[], issues:[],
    loading:true, error:null, issuesLoading:true, issuesError:null, service:'checking', health:null, bootstrap:null,
    searchSerial:0, issueSerial:0, drawerSerial:0, drawer:null, drawerTab:'overview', drawerSection:'', exportBusy:false
  };
  let searchAbort, toastTimer, drawerReturnFocus;

  function persist() {
    try {
      localStorage.setItem(storageKey, JSON.stringify({ids:[...state.selected],notes:state.notes,assetId:state.assetId,condition:state.condition}));
      $('notesSaved').textContent = 'Saved on this device';
    } catch (_) { $('notesSaved').textContent = 'Kept for this session · browser storage unavailable'; }
  }
  function toast(message, error = false) {
    clearTimeout(toastTimer); $('toast').textContent = message;
    $('toast').classList.toggle('error', error); $('toast').hidden = false;
    toastTimer = setTimeout(() => { $('toast').hidden = true; }, 4000);
  }
  async function request(url, options = {}) {
    const {timeout = 25000, ...fetchOptions} = options;
    const controller = new AbortController();
    const outerSignal = fetchOptions.signal;
    const forwardAbort = () => controller.abort();
    if (outerSignal?.aborted) controller.abort();
    else outerSignal?.addEventListener('abort', forwardAbort, {once:true});
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const response = await fetch(url, {...fetchOptions,signal:controller.signal,credentials:'same-origin',cache:'no-store'});
      if (!response.ok) {
        let message = 'The evidence connection is unavailable. Please try again.';
        try { const body = await response.json(); if (body.message) message = body.message; } catch (_) { /* Keep a useful connection message for non-JSON errors. */ }
        throw new Error(message);
      }
      return response;
    } catch (error) {
      if (error.name === 'AbortError' && !outerSignal?.aborted) throw new Error('The evidence service took too long to respond. Please try again.');
      if (error instanceof TypeError) throw new Error('The evidence service could not be reached. Check the connection and try again.');
      throw error;
    } finally { clearTimeout(timer); outerSignal?.removeEventListener('abort', forwardAbort); }
  }
  async function json(url, options) { return (await request(url, options)).json(); }
  const asset = () => state.assets.find(item => item.id === state.assetId);
  function formatDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return 'Date not recorded';
    return new Intl.DateTimeFormat('en-US',{month:'short',day:'numeric',year:'numeric'}).format(new Date(value + 'T12:00:00'));
  }
  function sourceURL(record, section = '') {
    const safe = new URL(`/sources/${encodeURIComponent(record.id)}`, location.origin);
    if (section) safe.hash = section;
    return safe.href;
  }
  function mergeRecord(record) {
    if (record && typeof record.id === 'string') state.records.set(record.id, {...state.records.get(record.id),...record});
  }
  function connection(status) {
    state.service = status;
    $('connectionStatus').className = 'connection-pill ' + status;
    const label = {checking:'Connecting',available:'Live evidence',unavailable:'Connection unavailable'}[status];
    $('connectionStatus').innerHTML = '<span class="status-dot"></span><span>' + label + '</span>';
    $('aboutConnection').textContent = status === 'available' ? 'Connected · live retrieval' : status === 'checking' ? 'Checking' : 'Unavailable';
  }
  function context() {
    const item = asset();
    if (!item) return;
    $('heroAssetId').textContent = item.id;
    $('heroAssetName').textContent = item.name.replace(new RegExp('\\s+' + item.id.replace(/[.*+?^${}()|[\]\\]/g,'\\$&') + '$'), '');
    $('heroAssetMeta').innerHTML = `<span>Model ${esc(item.model)}</span><span class="configuration-tag">Configuration ${esc(item.configuration)}</span>`;
    $('heroDescription').textContent = item.description;
    $('packetContext').textContent = `Prepared for ${item.id} · model ${item.model} · configuration ${item.configuration}. Selection stays with you as you explore.`;
    renderPacket();
  }
  function view(name, updateHash = true) {
    if (!['mission','cases','condition','sources','workspace','evidence','packet','fleet','registry','imports','connections','model-evidence'].includes(name)) name = 'mission';
    state.view = name;
    const titles = {
      fleet:['Fleet overview','EQUIPMENT · DATA · REVIEW','Know what needs attention.','Prioritize registered equipment by observed condition, data gaps and open maintenance cases.'],
      registry:['Equipment & parts','ESTABLISH THE EQUIPMENT CONTEXT','Every component has a history.','Register equipment, link applicable manuals and keep installed components separate from spare stock.'],
      imports:['Import workspace','PREVIEW · MAP · VERIFY','Bring new evidence into the workspace.','Check incoming readings and documents, resolve rejected rows and follow delivery through KD readback.'],
      connections:['Source setup & health','SAVE THE MAPPING · WATCH THE DELIVERY','See where the data stops.','Keep source configuration, received observations and verified delivery visible together.'],
      'model-evidence':['Model evidence','MEASURE BEFORE RELYING ON A MODEL','Make the limitations measurable.','Compare frozen rules with independent histories, false alarms and the warning time before an event.'],
      mission:['Mission control','THE MAINTENANCE EPISODE','See the signal. Keep the whole story.','Follow two fictional assets from arriving measurements to evidence, review and a recorded outcome.'],
      cases:['Maintenance cases','OBSERVE · REVIEW · FOLLOW THROUGH','Every decision keeps its context.','Preserve the condition, review the evidence and record what happened next.'],
      condition:['Equipment condition','FROM SIGNAL TO REVIEW','See the change. Follow the evidence.','Explore equipment readings, understand the trend and bring the right sources into review.'],
      sources:['Data sources','CONNECT THROUGH KNOWLEDGE DISCOVERY','One workspace. Your equipment data.','Start with simulated readings, then connect mapped sensor records through Knowledge Discovery.'],
      workspace:['Overview','MAINTENANCE EVIDENCE','Start with the right evidence.','Find applicable guidance. Examine the history. Build a traceable review.'],
      evidence:['Evidence library','FOLLOW THE SOURCE','Every record has a context.','Compare the details, preserve the distinctions and go straight to the original.'],
      packet:['Review packet','PREPARE THE REVIEW','A clear brief. A visible source trail.','Bring selected evidence and your observations together for the next conversation.']
    }[name];
    ['breadcrumbCurrent','pageEyebrow','pageTitle','pageSubtitle'].forEach((id, i) => { $(id).textContent = titles[i]; });
    ['mission','cases','condition','sources','workspace','evidence','packet','fleet','registry','imports','connections','model-evidence'].forEach(key => { $(key + 'View').hidden = name !== key; });
    document.body.dataset.fleetView = name;
    $('assetSelect').closest('.asset-switch').hidden = ['mission','cases','fleet','registry','imports','connections','model-evidence'].includes(name);
    $('workspaceHero').hidden = name !== 'workspace'; $('retrievalArea').hidden = !['workspace','evidence'].includes(name);
    document.querySelectorAll('.primary-nav [data-view]').forEach(button => {
      button.classList.toggle('active', button.dataset.view === name);
      if (button.dataset.view === name) button.setAttribute('aria-current','page'); else button.removeAttribute('aria-current');
    });
    if (updateHash && location.hash !== '#' + name) history.replaceState(null,'','#' + name);
    closeDrawer(); updateSelection();
    if (name === 'packet') renderPacket();
    window.dispatchEvent(new CustomEvent('fleet-view-changed',{detail:{view:name}}));
  }
  function updateFilters() {
    document.querySelectorAll('.kind-tabs button').forEach(button => {
      const active = button.dataset.kind === state.kind;
      button.classList.toggle('active',active); button.setAttribute('aria-pressed', String(active));
    });
    $('additionalKind').value = ['bulletin','turnover'].includes(state.kind) ? state.kind : '';
    $('scopeSelect').value = state.scope; $('historyToggle').checked = state.history;
    $('queryInput').value = state.query;
    document.querySelectorAll('.sort-select').forEach(select => { select.value = state.sort; });
    $('trainingNav').classList.toggle('active', state.kind === 'training' && state.view !== 'packet');
  }
  function tagHTML(record, detail = false) {
    const tags = [];
    if (record.status) tags.push(`<span class="tag ${esc(record.status)}">${esc(statusNames[record.status] || record.status)}</span>`);
    if (record.configuration && !['all','unknown'].includes(record.configuration)) tags.push(`<span class="tag">Config ${esc(record.configuration)}</span>`);
    const flags = [...new Set(record.issue_flags || [])];
    flags.forEach(flag => { if (flag !== 'superseded') tags.push(`<span class="tag review">${esc(flagNames[flag] || flag.replaceAll('_',' '))}</span>`); });
    if (record.applicability?.applies === false) tags.push('<span class="tag mismatch">Other equipment context</span>');
    return (detail ? tags : tags.slice(0,3)).join('');
  }
  function selectionButton(id, expanded = false) {
    const selected = state.selected.has(id);
    return `<button class="add-button${selected ? ' selected' : ''}" data-action="toggle-record" data-id="${esc(id)}" aria-pressed="${selected}" aria-label="${selected ? 'Remove' : 'Add'} ${esc(id)} ${selected ? 'from' : 'to'} review packet">${icon(selected ? 'check' : 'plus')}<span class="add-label">${selected ? 'Added' : expanded ? 'Add to packet' : 'Add'}</span></button>`;
  }
  function card(record) {
    return `<article class="record-card${state.selected.has(record.id) ? ' selected' : ''}"><div class="record-topline"><span class="kind-label">${icon(record.kind)}${esc(kindNames[record.kind] || 'Source')}</span><span class="record-id">${esc(record.id)}</span></div><button class="record-open" data-action="open-record" data-id="${esc(record.id)}">${esc(record.title)}</button><p class="record-excerpt">${esc(record.excerpt || record.retrieval?.text || 'Open the source to inspect its details.')}</p><div class="record-tags">${tagHTML(record)}</div><div class="record-card-footer"><button class="source-link" data-action="open-source" data-id="${esc(record.id)}">View source ${icon('arrow-up-right')}</button>${selectionButton(record.id)}</div></article>`;
  }
  function row(record) {
    return `<article class="evidence-row${state.selected.has(record.id) ? ' selected' : ''}"><div class="row-type-icon">${icon(record.kind)}</div><div class="row-main"><div class="row-meta"><span>${esc(kindNames[record.kind] || 'Source')}</span><span class="record-id">${esc(record.id)}</span><span>${esc(formatDate(record.effective_date))}</span></div><button class="record-open" data-action="open-record" data-id="${esc(record.id)}">${esc(record.title)}</button><p class="record-excerpt">${esc(record.excerpt || record.retrieval?.text || 'Open the source to inspect its details.')}</p><div class="row-bottom"><div class="record-tags">${tagHTML(record,true)}</div><button class="source-link" data-action="open-source" data-id="${esc(record.id)}">Source ${icon('arrow-up-right')}</button></div></div><div class="row-add">${selectionButton(record.id)}</div></article>`;
  }
  function empty(title, message, action = '') { return `<div class="empty-state">${icon('empty')}<h3>${esc(title)}</h3><p>${esc(message)}</p>${action}</div>`; }
  function errorState(message, action = 'retry') { return `<div class="error-state">${icon('alert')}<h3>We couldn’t retrieve the evidence.</h3><p>${esc(message)}</p><button class="button secondary" data-action="${action}">${icon('refresh')}Try again</button></div>`; }
  function renderResults() {
    const loading = state.loading;
    ['workspaceResultCount','evidenceResultCount'].forEach(id => { $(id).textContent = loading || state.error ? '—' : state.results.length; });
    const selectedAsset = asset();
    const caption = loading ? 'Retrieving source records…' : state.error ? 'Search is unavailable. No substitute results are shown.' : `Live retrieval · ${state.query ? '“' + state.query + '”' : 'All source records'} · ${state.scope === 'all' ? 'all configurations' : (selectedAsset?.id || state.assetId) + ' equipment context'}${state.history ? ' · includes history' : ''}`;
    $('workspaceCaption').textContent = caption; $('evidenceCaption').textContent = caption;
    $('searchButton').disabled = loading; $('searchForm').setAttribute('aria-busy',String(loading));
    if (loading) {
      $('workspaceResults').innerHTML = '<div class="skeleton-card"></div>'.repeat(3);
      $('evidenceResults').innerHTML = '<div class="loading-state"><span class="spinner"></span><p>Following the evidence trail…</p></div>';
      return;
    }
    if (state.error) { $('workspaceResults').innerHTML = $('evidenceResults').innerHTML = errorState(state.error); return; }
    const results = [...state.results];
    if (state.sort === 'newest') results.sort((a,b) => (b.effective_date || '').localeCompare(a.effective_date || ''));
    if (state.sort === 'title') results.sort((a,b) => a.title.localeCompare(b.title));
    if (!results.length) {
      $('workspaceResults').innerHTML = $('evidenceResults').innerHTML = empty('No matching evidence in this scope.','Try a broader phrase, another source type, or include earlier revisions.', '<button class="button secondary" data-action="reset-search">Browse applicable evidence</button>');
      return;
    }
    $('workspaceResults').innerHTML = results.slice(0,6).map(card).join('') + (results.length > 6 ? `<div class="result-limit-note"><span>Showing 6 of ${results.length} retrieved sources</span><button class="text-button" data-view="evidence">Explore all evidence ${icon('arrow-right')}</button></div>` : '');
    $('evidenceResults').innerHTML = results.map(row).join('');
  }
  async function search() {
    if (!asset()) return;
    searchAbort?.abort(); searchAbort = new AbortController();
    const serial = ++state.searchSerial;
    const params = new URLSearchParams({q:state.query,asset:state.assetId,kind:state.kind,scope:state.scope});
    if (state.history) params.set('history','1');
    state.loading = true; state.error = null; state.results = []; updateFilters(); renderResults();
    try {
      const result = await json('/api/search?' + params, {signal:searchAbort.signal});
      if (serial !== state.searchSerial) return;
      if (result.live !== true || !Array.isArray(result.records)) throw new Error('Live evidence could not be verified. Please check the connection.');
      state.results = result.records.filter(record => record && typeof record.id === 'string');
      state.results.forEach(mergeRecord); connection('available');
    } catch (error) {
      if (serial !== state.searchSerial || error.name === 'AbortError') return;
      state.error = error.message; state.results = []; connection('unavailable');
    } finally { if (serial === state.searchSerial) { state.loading = false; renderResults(); } }
  }
  function issueCategory(issue) {
    if (/duplicat/i.test(issue.type)) return ['copy','Duplicate copies'];
    if (/supersed|revision/i.test(issue.type)) return ['revision','Revision context'];
    if (/identity|missing/i.test(issue.type)) return ['identity','Equipment identity'];
    return ['inspect','Records to compare'];
  }
  function renderIssues() {
    if (state.issuesLoading) { $('workspaceIssues').innerHTML = '<div class="no-issues">Checking the retrieved records for review findings…</div>'; $('evidenceIssues').innerHTML = '<p>Checking findings…</p>'; return; }
    if (state.issuesError) {
      const content = `<div class="no-issues"><p>Review findings are unavailable.</p><p>${esc(state.issuesError)}</p><button class="text-button" data-action="retry-issues">Check again ${icon('refresh')}</button></div>`;
      $('workspaceIssues').innerHTML = $('evidenceIssues').innerHTML = content; return;
    }
    if (!state.issues.length) { $('workspaceIssues').innerHTML = $('evidenceIssues').innerHTML = '<div class="no-issues">No review findings were returned for this equipment context. Check source applicability before use.</div>'; return; }
    const groups = new Map();
    for (const issue of state.issues) { const [key,label] = issueCategory(issue); if (!groups.has(key)) groups.set(key,{label,items:[]}); groups.get(key).items.push(issue); }
    $('workspaceIssues').innerHTML = [...groups].map(([key,group]) => `<button class="issue-summary" data-issue-group="${key}"><span class="issue-symbol">${icon(key)}</span><span><strong>${esc(group.label)}</strong><p>${group.items.length} ${group.items.length === 1 ? 'finding' : 'findings'} · ${esc(group.items[0].title)}</p></span><span class="issue-arrow">${icon('arrow-right')}</span></button>`).join('');
    $('evidenceIssues').innerHTML = state.issues.map(issue => `<button class="rail-issue" data-issue-id="${esc(issue.id)}"><span class="rail-issue-title">${icon(issueCategory(issue)[0])}${esc(issue.title)}</span><p>${esc(issue.description)}</p><span class="text-button">Compare sources ${icon('arrow-right')}</span></button>`).join('');
  }
  async function loadIssues() {
    if (!asset()) return;
    const serial = ++state.issueSerial;
    state.issuesLoading = true; state.issuesError = null; state.issues = []; renderIssues();
    try {
      const result = await json('/api/issues?' + new URLSearchParams({asset:state.assetId}));
      if (serial !== state.issueSerial) return;
      if (result.live !== true || !Array.isArray(result.issues)) throw new Error('Live review findings could not be verified.');
      state.issues = result.issues;
    } catch (error) { if (serial === state.issueSerial) state.issuesError = error.message; }
    finally { if (serial === state.issueSerial) { state.issuesLoading = false; renderIssues(); } }
  }
  function showIssues(issues, title) {
    $('issueDialogContent').innerHTML = `<h2>${esc(title || issues[0]?.title || 'Review finding')}</h2><p class="dialog-intro">Compare the sources in their original context. Both records and their references are preserved.</p>` + issues.map(issue => `<section class="dialog-finding"><h3>${esc(issue.title)}</h3><p>${esc(issue.description)}</p>${(issue.record_ids || []).map(id => { const record = state.records.get(id); return `<button class="issue-record-link" data-action="open-record" data-id="${esc(id)}"><span>${icon(record?.kind || 'file')}</span><span><strong>${esc(record?.title || id)}</strong><small>${esc(id)}${record?.event_id ? ' · Event ' + esc(record.event_id) : ''}</small></span><span class="issue-arrow">${icon('arrow-up-right')}</span></button>`; }).join('')}</section>`).join('');
    $('issueDialog').showModal();
  }
  function updateSelection() {
    document.querySelectorAll('.packet-count').forEach(el => { el.textContent = state.selected.size; });
    $('selectionBar').hidden = state.selected.size === 0 || ['packet','fleet','registry','imports','connections','model-evidence'].includes(state.view);
    $('clearPacketButton').disabled = state.selected.size === 0 && !state.condition;
    ['downloadPacketButton','printPacketButton'].forEach(id => { $(id).disabled = state.selected.size === 0 || state.exportBusy; });
    if (state.drawer) {
      const target = $('drawerContent').querySelector('.drawer-actions .add-button');
      if (target) target.outerHTML = selectionButton(state.drawer.id,true);
    }
  }
  function toggleRecord(id) {
    if (!state.records.has(id)) { toast('Open this record before adding it to your packet.',true); return; }
    if (state.selected.has(id)) { state.selected.delete(id); toast('Source removed from your packet.'); }
    else { if (state.selected.size >= 100) { toast('A packet can hold up to 100 sources.',true); return; } state.selected.add(id); toast('Source added to your review packet.'); }
    persist(); updateSelection(); renderResults(); renderPacket();
  }
  function belongsToContext(record) {
    const current = asset();
    if (!current || !record) return true;
    return (!record.asset_id || ['all','unknown',current.id].includes(record.asset_id)) && (!record.configuration || ['all','unknown',current.configuration].includes(record.configuration));
  }
  function renderPacket() {
    let conditionCard = $('packetCondition');
    if (!conditionCard) {
      conditionCard = document.createElement('div'); conditionCard.id = 'packetCondition';
      $('packetRecords').before(conditionCard);
    }
    conditionCard.hidden = !state.condition;
    if (state.condition) {
      const condition = state.condition;
      const source = condition.mode === 'simulation' ? `Simulated readings · ${condition.scenario || 'replay'} · minute ${condition.step ?? '—'}` : `Source through KD · ${condition.source_id || 'source identity unavailable'}`;
      conditionCard.innerHTML = `<article class="packet-condition-card"><div><strong>Equipment condition snapshot · ${esc(condition.asset_id)}</strong><p>${esc(source)}</p><small>The server verifies this snapshot and includes its condition, forecast availability and provenance when you export.${condition.asset_id !== state.assetId ? ' This snapshot belongs to a different equipment context.' : ''}</small></div><button class="icon-button" data-action="remove-condition" aria-label="Remove equipment condition from packet">${icon('close')}</button></article>`;
    }
    const records = [...state.selected].map(id => state.records.get(id) || {id,title:'Source details are not available yet',issue_flags:[]});
    $('packetRecords').innerHTML = records.length ? records.map((record,index) => `<article class="packet-row"><span class="packet-number">${String(index+1).padStart(2,'0')}</span><div class="row-main"><div class="row-meta"><span>${esc(kindNames[record.kind] || 'Source')}</span><span class="record-id">${esc(record.id)}</span></div><button class="record-open" data-action="open-record" data-id="${esc(record.id)}">${esc(record.title)}</button><div class="record-tags">${tagHTML(record,true)}</div></div><button class="icon-button packet-remove" data-action="remove-record" data-id="${esc(record.id)}" aria-label="Remove ${esc(record.id)} from packet">${icon('close')}</button></article>`).join('') : empty('Your review starts with a source.','Add guidance, history or inspection records as you explore. Your selection stays with you across the workspace.', '<button class="button secondary" data-view="workspace">Find evidence ' + icon('arrow-right') + '</button>');
    if (document.activeElement !== $('packetNotes')) $('packetNotes').value = state.notes;
    $('notesCount').textContent = state.notes.length.toLocaleString() + ' / 12,000';
    $('packetFlagCount').textContent = records.filter(record => record.issue_flags?.length || record.status === 'unresolved' || !belongsToContext(record)).length;
    const other = records.filter(record => !belongsToContext(record));
    $('packetScopeWarning').hidden = !other.length;
    $('packetScopeWarning').textContent = `${other.length} selected ${other.length === 1 ? 'source belongs' : 'sources belong'} to another equipment context. Keep this distinction in your observations.`;
    updateSelection();
  }
  async function openRecord(id, tab = 'overview', section = '') {
    if ($('issueDialog').open) $('issueDialog').close();
    const serial = ++state.drawerSerial;
    if ($('recordDrawer').hidden) drawerReturnFocus = document.activeElement;
    $('drawerBackdrop').hidden = false; $('recordDrawer').hidden = false;
    document.body.classList.add('drawer-open');
    state.drawerTab = tab; state.drawerSection = section; state.drawer = null;
    $('drawerContent').innerHTML = '<div class="loading-state"><span class="spinner"></span><h2 id="drawerTitle">Opening the source…</h2></div>';
    $('closeDrawer').focus();
    try {
      const record = await json('/api/record/' + encodeURIComponent(id));
      if (serial !== state.drawerSerial) return;
      if (!record || record.id !== id || !Array.isArray(record.sections)) throw new Error('The requested source details could not be verified.');
      // Preserve separately identified retrieval evidence when refreshing authored metadata.
      mergeRecord(record); state.drawer = state.records.get(id); renderDrawer();
    } catch (error) { if (serial === state.drawerSerial) $('drawerContent').innerHTML = `<div class="error-state">${icon('alert')}<h2 id="drawerTitle">Source unavailable</h2><p>${esc(error.message)}</p><button class="button secondary" data-action="open-record" data-id="${esc(id)}">Try again</button></div>`; }
  }
  function closeDrawer() {
    if ($('recordDrawer').hidden) return;
    ++state.drawerSerial; state.drawer = null;
    $('recordDrawer').hidden = true; $('drawerBackdrop').hidden = true; document.body.classList.remove('drawer-open');
    $('drawerContent').innerHTML = '';
    if (drawerReturnFocus?.isConnected) drawerReturnFocus.focus();
  }
  function renderDrawer() {
    const record = state.drawer; if (!record) return;
    const sections = record.sections || [];
    const detail = [['Equipment', record.asset_id === 'all' ? 'All listed equipment' : record.asset_id === 'unknown' ? 'Identity not confirmed' : record.asset_id],['Model / configuration',[record.equipment_model,record.configuration].filter(Boolean).join(' / ')],['Effective date',formatDate(record.effective_date)],['Revision',record.revision || 'Not recorded'],['Publication',record.publication_id || 'Not recorded'],['Event identity',record.event_id || 'Not recorded'],['Supersedes',record.supersedes || 'No linked predecessor'],['Duplicate group',record.duplicate_group || 'No listed duplicate group']];
    const tabs = `<div class="drawer-tabs" role="tablist" aria-label="Source view"><button role="tab" aria-selected="${state.drawerTab === 'overview'}" class="${state.drawerTab === 'overview' ? 'active' : ''}" data-drawer-tab="overview">Overview & sections</button><button role="tab" aria-selected="${state.drawerTab === 'source'}" class="${state.drawerTab === 'source' ? 'active' : ''}" data-drawer-tab="source">Original source ${icon('arrow-up-right')}</button></div>`;
    let body;
    if (state.drawerTab === 'source') {
      const selectedSection = sections.some(section => section.id === state.drawerSection) ? state.drawerSection : '';
      body = `<div class="source-preview"><div class="source-preview-toolbar"><select id="sourceSectionSelect" aria-label="Source section"><option value="">Document beginning</option>${sections.map(section => `<option value="${esc(section.id)}" ${selectedSection === section.id ? 'selected' : ''}>${esc(section.title)}</option>`).join('')}</select><a href="${esc(sourceURL(record,selectedSection))}" target="_blank" rel="noopener">Open original ${icon('arrow-up-right')}</a></div><iframe id="sourceFrame" title="Original synthetic source: ${esc(record.title)}" src="${esc(sourceURL(record,selectedSection))}" sandbox="allow-same-origin"></iframe></div>`;
    } else {
      const flags = record.issue_flags || [];
      body = `<div class="drawer-overview"><p class="drawer-summary">${esc(record.summary)}</p>${flags.length || record.applicability?.review_required ? `<div class="issue-callout">${icon('inspect')}<div><strong>Keep this context in the review</strong><p>${esc(flags.map(flag => flagNames[flag] || flag).join(' · ') || record.applicability.reason)}</p></div></div>` : ''}<dl class="detail-grid">${detail.map(([key,value]) => `<div><dt>${esc(key)}</dt><dd>${esc(value || 'Not recorded')}</dd></div>`).join('')}</dl><div class="section-source-heading"><h3>Anchored source sections</h3><small>${sections.length} sections</small></div>${sections.map((section,index) => `<article class="source-section"><h4><span>${String(index+1).padStart(2,'0')}</span>${esc(section.title)}</h4><p>${esc(section.text)}</p><button class="section-link" data-action="source-section" data-section="${esc(section.id)}">View this section in the source ${icon('arrow-up-right')}</button></article>`).join('')}<p class="drawer-technical-note">Equipment identifiers, status and section text are authored synthetic source metadata. ${record.retrieval ? 'This record also has live retrieval evidence from Knowledge Discovery.' : 'Live search supplies retrieval results separately.'} Review labels do not determine maintenance authority.</p></div>`;
    }
    $('drawerContent').innerHTML = `<div class="drawer-heading"><div class="record-topline"><span class="kind-label">${icon(record.kind)}${esc(kindNames[record.kind] || 'Source')}</span><span class="record-id">${esc(record.id)}</span></div><h2 id="drawerTitle">${esc(record.title)}</h2><div class="record-tags">${tagHTML(record,true)}</div><p class="drawer-reference">${esc(record.reference)}</p></div>${tabs}${body}<div class="drawer-actions"><small>Synthetic source · original retained</small>${selectionButton(record.id,true)}</div>`;
  }
  async function exportPacket(print = false) {
    if (!state.selected.size || state.exportBusy) return;
    const printWindow = print ? window.open('about:blank','_blank') : null;
    if (print && !printWindow) { toast('Allow a new tab to print, or download the review brief.',true); return; }
    if (printWindow) { printWindow.document.title = 'Preparing review brief'; printWindow.document.body.textContent = 'Preparing your synthetic review brief…'; }
    state.exportBusy = true; updateSelection(); $('exportStatus').textContent = 'Verifying selected sources and preparing your brief…';
    try {
      const response = await request('/api/packet',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids:[...state.selected],notes:state.notes,asset_id:state.assetId,condition:state.condition}),timeout:35000});
      if (!response.headers.get('content-type')?.includes('text/html')) throw new Error('The review brief was not returned in the expected format.');
      const html = await response.text();
      if (printWindow) {
        if (printWindow.closed) throw new Error('The print tab was closed. Your packet is still available.');
        printWindow.document.open(); printWindow.document.write(html); printWindow.document.close();
        printWindow.focus(); setTimeout(() => { if (!printWindow.closed) printWindow.print(); }, 350);
        $('exportStatus').textContent = 'Print view opened. Choose Save as PDF in your print dialog.';
      } else {
        const url = URL.createObjectURL(new Blob([html],{type:'text/html;charset=utf-8'}));
        const anchor = document.createElement('a'); anchor.href = url;
        anchor.download = `FleetEvidence-${state.assetId}-${new Date().toISOString().slice(0,10)}.html`;
        document.body.append(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(url),60000);
        $('exportStatus').textContent = 'Review brief downloaded. The sources and notes remain in your workspace.';
      }
    } catch (error) {
      if (printWindow && !printWindow.closed) printWindow.close();
      $('exportStatus').textContent = error.message; toast('The brief could not be created. Your selection and notes are retained.',true);
    } finally { state.exportBusy = false; updateSelection(); }
  }
  async function checkHealth() {
    try {
      const result = await json('/api/health'); state.health = result;
      $('aboutIndexed').textContent = Number.isFinite(result.indexed_records) ? result.indexed_records.toLocaleString() + ' verified by search service' : 'Unavailable';
      if (!state.loading) connection(result.ok ? 'available' : 'unavailable');
    } catch (_) { $('aboutIndexed').textContent = 'Connection unavailable'; }
  }
  async function bootstrap() {
    $('retryConnectionButton').disabled = true; $('assetSelect').disabled = true;
    connection('checking'); state.loading = true; state.error = null; renderResults();
    try {
      const data = await json('/api/bootstrap');
      if (!Array.isArray(data.assets) || !data.assets.length || !Array.isArray(data.records)) throw new Error('The demonstration collection is not available yet.');
      state.bootstrap = data; state.assets = data.assets; data.records.forEach(mergeRecord);
      if (!state.assets.some(item => item.id === state.assetId)) state.assetId = state.assets[0].id;
      $('assetSelect').innerHTML = state.assets.map(item => `<option value="${esc(item.id)}">${esc(item.id)} · ${esc(item.model)} · Config ${esc(item.configuration)}</option>`).join('');
      $('assetSelect').value = state.assetId; $('assetSelect').disabled = false;
      [['libraryCount','records'],['collectionRecords','records'],['collectionDuplicates','duplicate_groups'],['collectionUnresolved','unresolved']].forEach(([id,key]) => { $(id).textContent = Number.isFinite(data.counts?.[key]) ? data.counts[key] : '—'; });
      $('aboutCollection').textContent = `${data.counts.records} authored synthetic sources`;
      connection(data.service?.available ? 'available' : 'unavailable');
      context(); persist();
      await Promise.allSettled([search(),loadIssues(),checkHealth()]);
    } catch (error) {
      state.loading = false; state.error = error.message; state.issuesLoading = false; state.issuesError = error.message;
      connection('unavailable'); renderResults(); renderIssues();
    } finally { $('retryConnectionButton').disabled = false; }
  }

  document.addEventListener('click', event => {
    const button = event.target.closest('button, a.brand'); if (!button) return;
    if (button.matches('a.brand')) { event.preventDefault(); view('mission'); window.scrollTo({top:0,behavior:'instant'}); return; }
    if (button.dataset.view) { view(button.dataset.view); window.scrollTo({top:0,behavior:'instant'}); return; }
    if (button.dataset.query !== undefined) {
      state.query = button.dataset.query; state.kind = button.dataset.kind || 'all';
      if (state.view === 'packet') view('workspace'); search(); return;
    }
    if (button.dataset.kind) { state.kind = button.dataset.kind; search(); return; }
    if (button.dataset.closeDialog) { $(button.dataset.closeDialog).close(); return; }
    if (button.dataset.issueId) { const issue = state.issues.find(item => item.id === button.dataset.issueId); if (issue) showIssues([issue]); return; }
    if (button.dataset.issueGroup) { const group = state.issues.filter(issue => issueCategory(issue)[0] === button.dataset.issueGroup); showIssues(group,issueCategory(group[0])[1]); return; }
    if (button.dataset.drawerTab) { state.drawerTab = button.dataset.drawerTab; renderDrawer(); return; }
    const id = button.dataset.id;
    switch (button.dataset.action) {
      case 'open-record': openRecord(id); break;
      case 'remove-condition': state.condition = null; persist(); renderPacket(); toast('Equipment condition removed from the packet.'); break;
      case 'open-source': openRecord(id,'source'); break;
      case 'toggle-record': case 'remove-record': toggleRecord(id); break;
      case 'source-section': state.drawerTab = 'source'; state.drawerSection = button.dataset.section; renderDrawer(); break;
      case 'retry': state.bootstrap ? Promise.allSettled([search(),loadIssues(),checkHealth()]) : bootstrap(); break;
      case 'retry-issues': loadIssues(); break;
      case 'reset-search': state.query = ''; state.kind = 'all'; state.scope = 'applicable'; state.history = false; search(); break;
    }
  });
  $('searchForm').addEventListener('submit', event => { event.preventDefault(); state.query = $('queryInput').value.trim(); search(); });
  $('queryInput').maxLength = 500;
  $('assetSelect').addEventListener('change', () => { state.assetId = $('assetSelect').value; persist(); context(); search(); loadIssues(); window.dispatchEvent(new CustomEvent('fleet-asset-changed',{detail:{asset_id:state.assetId}})); });
  $('scopeSelect').addEventListener('change', () => { state.scope = $('scopeSelect').value; search(); });
  $('historyToggle').addEventListener('change', () => { state.history = $('historyToggle').checked; search(); });
  $('additionalKind').addEventListener('change', () => { state.kind = $('additionalKind').value || 'all'; search(); });
  document.querySelectorAll('.sort-select').forEach(select => select.addEventListener('change', () => { state.sort = select.value; updateFilters(); renderResults(); }));
  $('trainingNav').addEventListener('click', () => { state.query = 'training'; state.kind = 'training'; view('evidence'); search(); });
  $('refreshButton').addEventListener('click', () => { search(); loadIssues(); checkHealth(); });
  $('allFindingsButton').addEventListener('click', () => { view('evidence'); document.querySelector('.review-rail').scrollIntoView({behavior:'smooth',block:'nearest'}); });
  $('clearPacketButton').addEventListener('click', () => { state.selected.clear(); state.condition = null; persist(); renderPacket(); renderResults(); toast('Selection cleared. Your observations are retained.'); });
  $('packetNotes').addEventListener('input', () => { state.notes = $('packetNotes').value; $('notesCount').textContent = state.notes.length.toLocaleString() + ' / 12,000'; persist(); });
  $('downloadPacketButton').addEventListener('click', () => exportPacket(false));
  $('printPacketButton').addEventListener('click', () => exportPacket(true));
  $('closeDrawer').addEventListener('click', closeDrawer); $('drawerBackdrop').addEventListener('click', closeDrawer);
  $('drawerContent').addEventListener('change', event => { if (event.target.id === 'sourceSectionSelect' && state.drawer) { state.drawerSection = event.target.value; $('sourceFrame').src = sourceURL(state.drawer,state.drawerSection); $('drawerContent').querySelector('.source-preview-toolbar a').href = sourceURL(state.drawer,state.drawerSection); } });
  $('aboutButton').addEventListener('click', () => { $('aboutDialog').showModal(); checkHealth(); });
  $('retryConnectionButton').addEventListener('click', bootstrap);
  document.addEventListener('keydown', event => {
    if ($('recordDrawer').hidden) return;
    if (event.key === 'Escape') { event.preventDefault(); closeDrawer(); return; }
    if (event.key !== 'Tab') return;
    const focusable = [...$('recordDrawer').querySelectorAll('button, a, select, iframe, [tabindex="0"]')].filter(el => !el.disabled && !el.hidden);
    const first = focusable[0], last = focusable[focusable.length-1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
  });
  document.querySelectorAll('dialog').forEach(dialog => dialog.addEventListener('click', event => { if (event.target === dialog) { const rect = dialog.getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close(); } }));
  window.addEventListener('hashchange', () => view(location.hash.slice(1),false));
  window.addEventListener('fleet-condition-selected', event => {
    const condition = event.detail;
    if (!condition || !['simulation','kd'].includes(condition.mode) || !condition.asset_id) return;
    state.condition = {...condition}; persist(); renderPacket();
    toast(state.selected.size ? 'Equipment condition added to your review packet.' : 'Condition added. Add evidence sources to export your review packet.');
  });
  window.FleetEvidence = {
    getAssetId: () => state.assetId,
    getView: () => state.view,
    getSelection: () => ({ids:[...state.selected],notes:state.notes,condition:state.condition ? {...state.condition} : null,records:[...state.selected].map(id => state.records.get(id)).filter(Boolean)}),
    openRecord,
    selectAsset(assetId) {
      if (!state.assets.some(item => item.id === assetId)) return false;
      state.assetId = assetId; $('assetSelect').value = assetId; context(); persist(); loadIssues();
      window.dispatchEvent(new CustomEvent('fleet-asset-changed',{detail:{assetId}}));
      return true;
    },
    showView(name, updateHash = true) {
      view(name, updateHash); window.scrollTo({top:0,behavior:'instant'});
    },
    toast,
    searchEvidence(query, assetId) {
      if (state.assets.some(item => item.id === assetId)) {
        state.assetId = assetId; $('assetSelect').value = assetId; context(); persist(); loadIssues();
      }
      state.query = String(query || '').slice(0,500); state.kind = 'all'; state.scope = 'applicable';
      state.history = false; view('evidence'); window.scrollTo({top:0,behavior:'instant'}); search();
    }
  };
  hydrate(); view(location.hash.slice(1),false); updateFilters(); renderPacket(); renderResults(); renderIssues(); bootstrap();
})();
