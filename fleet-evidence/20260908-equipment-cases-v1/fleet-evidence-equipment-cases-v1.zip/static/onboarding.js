/* Application-owned equipment registry and data onboarding. No browser-generated health. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id), fleet = window.FleetEvidence;
  const views = ['fleet','registry','imports','connections','model-evidence'];
  const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const count = value => typeof value === 'number' && Number.isFinite(value) ? value.toLocaleString('en-US',{maximumFractionDigits:1}) : '—';
  const percent = value => typeof value === 'number' && Number.isFinite(value) ? `${Math.round(value*100)}%` : '—';
  const date = value => { const parsed = new Date(value); return value && Number.isFinite(parsed.getTime()) ? parsed.toLocaleString('en-US',{year:'numeric',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:false,timeZone:'UTC'}) + ' UTC' : 'Not recorded'; };
  const human = value => String(value || 'unknown').replace(/_/g,' ').replace(/^./,ch => ch.toUpperCase());
  const tones = {verified:'good',normal:'good',healthy:'good',current:'good',observed:'good',watch:'warn',review:'warn',stale:'warn',missing:'warn',missing_data:'warn',no_data:'warn',indexing:'warn',not_connected:'warn',connection_problem:'bad',interrupted:'bad',delivery_problem:'bad',error:'bad',rejected:'bad',uncertain:'bad'};
  const chip = (value,label) => `<span class="ob-chip ${tones[value] || ''}">${esc(label || human(value))}</span>`;
  const empty = (title,detail) => `<div class="ob-empty"><h3>${esc(title)}</h3><p>${esc(detail)}</p></div>`;
  const list = (data,key) => Array.isArray(data) ? data : data?.[key] || [];
  const stat = (label,value,detail='',attention=false) => `<div class="ob-stat ${attention ? 'attention' : ''}"><span>${esc(label)}</span><strong>${esc(count(value))}</strong><small>${esc(detail)}</small></div>`;
  const field = (name,label,value='',options={}) => `<label class="${options.wide ? 'wide' : ''}">${esc(label)}<input name="${name}" value="${esc(value)}" ${options.required ? 'required' : ''} ${options.type ? `type="${options.type}"` : ''} ${options.min !== undefined ? `min="${options.min}"` : ''} maxlength="${options.max || 240}">${options.help ? `<span class="ob-help">${esc(options.help)}</span>` : ''}</label>`;
  const select = (name,label,options,value='',wide=false) => `<label class="${wide ? 'wide' : ''}">${esc(label)}<select name="${name}">${options.map(([id,text]) => `<option value="${esc(id)}" ${String(value)===String(id) ? 'selected' : ''}>${esc(text)}</option>`).join('')}</select></label>`;
  const textarea = (name,label,value='',help='') => `<label class="wide">${esc(label)}<textarea name="${name}" rows="3" maxlength="4000">${esc(value)}</textarea>${help ? `<span class="ob-help">${esc(help)}</span>` : ''}</label>`;
  const state = {equipment:[],parts:[],sources:[],imports:[],selected:null,detail:null,tab:'components',filter:'',file:null,preview:null,receipt:null,sourceId:'',importKind:'csv',serial:0};
  const mappingFields = [['asset_id','Equipment ID'],['timestamp','Timestamp (UTC)'],['quality','Quality'],['vibration_mm_s','Vibration · mm/s RMS'],['temperature_c','Temperature · °C'],['pressure_bar','Pressure · bar'],['rpm','Speed · rev/min'],['load_pct','Load · %']];
  const units = {vibration_mm_s:'mm/s RMS',temperature_c:'degC',pressure_bar:'bar',rpm:'rev/min',load_pct:'%'};
  let receiptTimer, sourceTimer;
  async function api(path,payload) {
    const controller = new AbortController(), timeout = setTimeout(() => controller.abort(),45000);
    try {
      const response = await fetch(path,{method:payload === undefined ? 'GET' : 'POST',cache:'no-store',credentials:'same-origin',signal:controller.signal,...(payload === undefined ? {} : {headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})});
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || data.error || `Request failed (${response.status}).`);
      return data;
    } catch (error) {
      if (error.name === 'AbortError') throw new Error('The request timed out. Refresh the saved server state before submitting again.');
      if (error instanceof TypeError) throw new Error('The application could not be reached. Refresh when the connection is available.');
      throw error;
    } finally { clearTimeout(timeout); }
  }
  function message(text,error=false,view=fleet.getView()) { const node=$(`obMessage-${view}`); if(node) { node.textContent=text;node.hidden=!text;node.classList.toggle('error',error); } }
  function shell(view,html) { $(view+'View').innerHTML=`<div id="obMessage-${view}" class="ob-message" role="status" hidden></div>${html}`; }
  function table(headers,rows) { return `<div class="ob-table-wrap"><table class="ob-table"><thead><tr>${headers.map(text=>`<th scope="col">${esc(text)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`; }
  function dialog(title,copy,form,submit) {
    const node=$('obDialog'); node.innerHTML=`<div class="dialog-heading"><span class="ob-kicker">EQUIPMENT & DATA WORKSPACE</span><button type="button" class="icon-button" data-ob="close-dialog" aria-label="Close dialog">×</button></div><h2>${esc(title)}</h2><p>${esc(copy)}</p><form id="obDialogForm" class="ob-form">${form}<p class="ob-field-error wide" role="alert"></p><div class="ob-actions wide"><button type="submit" class="button primary">${esc(submit.label || 'Save')}</button><button type="button" class="button secondary" data-ob="close-dialog">Cancel</button></div></form>`;
    $('obDialogForm').addEventListener('submit',async event => {
      event.preventDefault(); const formNode=event.target; if(!formNode.reportValidity()) return;
      const button=formNode.querySelector('[type=submit]');button.disabled=true;formNode.querySelector('[role=alert]').textContent='';
      try { await submit.action(Object.fromEntries(new FormData(formNode))); node.close(); }
      catch(error) { formNode.querySelector('[role=alert]').textContent=error.message; }
      finally { button.disabled=false; }
    });
    node.showModal();
  }
  async function registryData() {
    const results=await Promise.allSettled([api('/api/registry/equipment'),api('/api/registry/parts')]);
    for(const result of results) if(result.status==='rejected') throw result.reason;
    state.equipment=list(results[0].value,'equipment');state.parts=list(results[1].value,'parts');
  }
  async function registry() {
    shell('registry',`<div class="ob-toolbar"><p>Equipment identity, component fitment and retained maintenance history.</p><div class="ob-actions"><button class="button secondary" data-ob="add-part">Add catalog part</button><button class="button primary" data-ob="add-equipment">Add equipment</button></div></div><div class="ob-layout"><aside class="ob-browser"><div class="ob-browser-head"><h2>Equipment <span id="obEquipmentCount" class="ob-count">—</span></h2><input class="ob-search" id="obEquipmentSearch" type="search" placeholder="Find equipment…" aria-label="Find registered equipment" value="${esc(state.filter)}"></div><div id="obEquipmentList" class="ob-equipment-list"></div></aside><div id="obEquipmentDetail">${empty('Reading the registry','Loading saved equipment and component records.')}</div></div>`);
    $('obEquipmentSearch').addEventListener('input',event=>{state.filter=event.target.value;renderEquipmentList();});
    await registryData();renderEquipmentList();
    if(!state.equipment.some(item=>item.id===state.selected)) state.selected=state.equipment[0]?.id;
    if(state.selected) await equipmentDetail(state.selected);
    else $('obEquipmentDetail').innerHTML=empty('Register the first equipment item','Add its identity and configuration before linking components, manuals or measurements.');
  }
  function renderEquipmentList() {
    if(!$('obEquipmentList')) return;
    $('obEquipmentCount').textContent=state.equipment.length;
    const query=state.filter.toLowerCase(), items=state.equipment.filter(item=>[item.id,item.name,item.model,item.location].join(' ').toLowerCase().includes(query));
    $('obEquipmentList').innerHTML=items.map(item=>`<button class="ob-equipment-row ${item.id===state.selected ? 'active' : ''}" data-ob-equipment="${esc(item.id)}" aria-pressed="${item.id===state.selected}"><strong>${esc(item.id)} · ${esc(item.name)}</strong><span>${esc(item.model)} · ${esc(item.configuration)}</span><small>${esc(item.location || 'Location not recorded')}</small></button>`).join('') || empty('No matching equipment','Try another name, model or equipment ID.');
  }
  async function equipmentDetail(id) {
    const serial=++state.serial; state.selected=id;renderEquipmentList();
    const data=await api('/api/registry/equipment/'+encodeURIComponent(id));
    if(serial!==state.serial) return;state.detail=data.equipment || data;renderEquipmentDetail();
  }
  function renderEquipmentDetail() {
    const data=state.detail,node=$('obEquipmentDetail');if(!node || !data) return;
    const installed=data.installed_components || (data.components || []).filter(item=>!item.removed_at);
    node.innerHTML=`<div class="ob-detail-header"><div class="ob-card-head"><div><span class="ob-kicker">${esc(data.id)} · REGISTERED EQUIPMENT</span><h2>${esc(data.name)}</h2></div>${data.synthetic_demo ? chip('','Fictional demo equipment') : chip('','User registered')}</div><div class="ob-meta"><span>Model ${esc(data.model)}</span><span>Configuration ${esc(data.configuration)}</span><span>${esc(data.location || 'Location not recorded')}</span></div>${data.description ? `<p>${esc(data.description)}</p>` : ''}<div class="ob-actions" style="margin-top:18px"><button class="button primary" data-equipment-case-create="${esc(data.id)}">Open maintenance case</button><button class="button secondary" data-equipment-case-list="${esc(data.id)}">View maintenance cases</button></div></div><div class="ob-tabs" role="group" aria-label="Equipment detail sections">${[['components','Installed components'],['catalog','Catalog & spares'],['manuals','Manuals'],['history','History']].map(([id,label])=>`<button data-ob-tab="${id}" class="${state.tab===id ? 'active' : ''}" aria-pressed="${state.tab===id}">${label}</button>`).join('')}</div><div id="obEquipmentTab"></div>`;
    const target=$('obEquipmentTab');
    if(state.tab==='components') target.innerHTML=`<div class="ob-toolbar"><p>${installed.length} installed component${installed.length===1 ? '' : 's'} on ${esc(data.id)}</p><button class="button primary" data-ob="install">Install component</button></div>${installed.length ? table(['Component / serial','Position','Installed',''],installed.map(item=>`<tr><td><strong>${esc(item.part_snapshot?.name || item.part_id)}</strong><small>${esc(item.part_id)} · Serial ${esc(item.serial || 'not recorded')}</small></td><td>${esc(item.position || 'Not specified')}${item.parent_component_id ? `<small>Within ${esc(item.parent_component_id)}</small>` : ''}</td><td>${esc(date(item.installed_at))}</td><td><button class="button secondary" data-ob-replace="${esc(item.id)}">Replace</button></td></tr>`)) : empty('No installed components recorded','Choose an applicable catalog part and record the actual installed item.')}<div class="ob-note">An installed component is a specific item on this equipment. Recording an installation or replacement retains its history; spare quantities are recorded separately.</div>`;
    else if(state.tab==='catalog') target.innerHTML=`<div class="ob-toolbar"><p>Shared part definitions and separately recorded stock locations.</p><button class="button secondary" data-ob="add-part">Add catalog part</button></div>${state.parts.length ? table(['Catalog part','Declared applicability','Installed items','Spare stock'],state.parts.map(part=>`<tr><td><strong>${esc(part.name)}</strong><small>${esc(part.id)} · ${esc(part.manufacturer)} ${esc(part.part_number)}</small>${part.nsn ? `<small>NSN ${esc(part.nsn)}</small>` : ''}</td><td>${(part.applicability || []).map(fit=>`${esc(fit.model)} / ${esc(fit.configuration)}`).join('<br>') || 'Not declared'}</td><td>${count(part.installed_quantity)}</td><td>${(part.spare_stock || []).map(stock=>`<strong>${count(stock.quantity)} <small>${esc(stock.location)}</small></strong>`).join('') || '<small>No stock recorded</small>'}<div class="ob-link-row"><button class="ob-link" data-ob-stock="${esc(part.id)}">Record stock</button></div></td></tr>`)) : empty('Create the part catalog','Define part identity and exact model/configuration applicability before installation.')}<div class="ob-note">Catalog identity, installed-item counts and spare quantities represent different records. Matching names alone do not establish compatibility.</div>`;
    else if(state.tab==='manuals') target.innerHTML=`<div class="ob-toolbar"><p>Manual references explicitly associated with ${esc(data.id)}.</p><div class="ob-actions"><button class="button secondary" data-ob="upload-document">Upload document</button><button class="button primary" data-ob="attach-manual">Attach reference</button></div></div>${data.manuals?.length ? table(['Manual','Revision / applicability','Reference'],data.manuals.map(manual=>`<tr><td><strong>${esc(manual.title)}</strong>${chip(manual.status || '',human(manual.status || 'reference attached'))}</td><td>${esc(manual.revision)}<small>${esc(manual.model)} / ${esc(manual.configuration)}</small>${manual.applies_to_current_identity===false ? chip('error','Applicability changed') : ''}</td><td><span class="ob-inline-code">${esc(manual.reference)}</span>${/^\/sources\/[A-Za-z0-9_.-]+$/.test(manual.source_url || '') ? `<div class="ob-link-row"><a href="${esc(manual.source_url)}" target="_blank" rel="noopener">Open source</a></div>` : ''}</td></tr>`)) : empty('Attach the applicable guidance','Record a manual reference and revision, or use Import workspace to upload and retain a document.')}<div class="ob-section-head"><h3>Uploaded documents</h3><span class="ob-help">Originals retained</span></div>${data.documents?.length ? table(['Document','Revision','Indexing',''],data.documents.map(doc=>`<tr><td><strong>${esc(doc.title)}</strong><small>${esc(doc.filename)}</small>${Array.isArray(doc.applicable_asset_ids) && !doc.applicable_asset_ids.includes(data.id) ? chip("error","Applicability needs review") : ""}</td><td>${esc(doc.revision)}</td><td>${chip(doc.indexing_status)}</td><td><button class="ob-link" data-ob-document="${esc(doc.document_id)}">Preview & original</button>${doc.document_type==='manual' && !(data.manuals || []).some(manual=>manual.reference===doc.document_id) ? `<div class="ob-link-row"><button class="ob-link" data-ob-attach-document="${esc(doc.document_id)}">Attach as manual</button></div>` : ''}</td></tr>`)) : empty('No uploaded documents','Upload a supported document and select this equipment to retain its original and indexing receipt.')}<div class="ob-note">A reference attachment records declared applicability. It does not establish document authority or verified indexing. Import receipts show actual document delivery.</div>`;
    else target.innerHTML=`<div class="ob-toolbar"><p>Installation and replacement events remain attached to this equipment.</p><button class="button secondary" data-ob="refresh-detail">Refresh history</button></div><section class="ob-card">${data.history?.length ? `<ol class="ob-history">${[...data.history].reverse().map(event=>`<li><strong>${esc(human(event.type))}</strong><p>${historyDetail(event)}</p><small>${esc(date(event.at || event.recorded_at))}${event.component_id ? ` · ${esc(event.component_id)}` : ''}</small></li>`).join('')}</ol>` : empty('No history recorded','New component and manual events will appear here.')}</section>`;
  }
  function historyDetail(event) {
    const detail=event.detail || {},previous=(state.detail?.components || []).find(item=>item.id===event.previous_component_id);
    const description=typeof detail==='string' ? esc(detail) : Object.entries(detail).filter(([,value])=>value!==null && value!=='' && typeof value!=='object').map(([key,value])=>`${esc(human(key))}: ${esc(value)}`).join(' · ');
    return [description,event.serial ? `Installed serial: ${esc(event.serial)}` : '',previous ? `Previous serial: ${esc(previous.serial || 'not recorded')} · Installed ${esc(date(previous.installed_at))} · Removed ${esc(date(previous.removed_at))}` : '',event.reference ? `Reference: ${esc(event.reference)}` : ''].filter(Boolean).join('<br>') || 'Retained registry event';
  }
  function addEquipment() {
    dialog('Register equipment','Keep the equipment identity and its installed configuration together.',field('id','Equipment ID','',{required:true,help:'Unique ID, for example A-19.'})+field('name','Equipment name','',{required:true})+field('model','Model','',{required:true})+field('configuration','Configuration','',{required:true})+field('kind','Equipment type','Pump',{required:true})+field('location','Location','')+textarea('description','Description')+'<label class="ob-check wide"><input type="checkbox" name="synthetic_demo" checked>Fictional demonstration equipment</label>',{label:'Register equipment',action:async values=>{const data=await api('/api/registry/equipment',{...values,synthetic_demo:values.synthetic_demo==='on'});state.selected=data.equipment?.id || data.id || values.id;await registry();message('Equipment registered. Add applicable parts and data next.');}});
  }
  function addPart() {
    dialog('Add a catalog part','Declare the exact equipment model and configuration this part can be used with.',field('id','Catalog part ID','',{required:true})+field('name','Part name','',{required:true})+field('manufacturer','Manufacturer','',{required:true})+field('part_number','Manufacturer part number','',{required:true})+field('nsn','NSN (optional)')+field('model','Applicable model',state.detail?.model || '',{required:true})+field('configuration','Applicable configuration',state.detail?.configuration || '',{required:true}),{label:'Save catalog part',action:async values=>{const {model,configuration,...part}=values;await api('/api/registry/parts',{...part,applicability:[{model,configuration}]});await registryData();state.tab='catalog';renderEquipmentDetail();message('Catalog part saved with explicit applicability.');}});
  }
  function installComponent(componentId) {
    const data=state.detail, current=(data?.components || []).find(item=>item.id===componentId);
    const parts=state.parts.filter(part=>part.applicability?.some(fit=>fit.model===data.model && fit.configuration===data.configuration));
    if(!parts.length) {message('Add a catalog part with this exact model and configuration before installing a component.',true);return;}
    const fields=select('part_id','Applicable catalog part',parts.map(part=>[part.id,`${part.name} · ${part.part_number}`]),current?.part_id)+field('serial','Installed serial number')+(current ? '' : field('position','Position / component role')+select('parent_component_id','Parent component',[['','Directly on equipment'],...(data.installed_components || []).map(item=>[item.id,`${item.position || item.part_id} · ${item.serial || item.id}`])]))+field('installed_at',current ? 'Replacement date (optional)' : 'Installation date (optional)','',{type:'date'})+textarea('notes','Maintenance observations','','A subsequent condition change is an observation, not proof of repair effectiveness.');
    dialog(current ? 'Record a replacement' : 'Install a component',current ? 'The earlier installed item and its removal remain in the equipment history.' : 'Record the actual item installed on this equipment. Spare stock remains a separate record.',fields,{label:current ? 'Record replacement' : 'Record installation',action:async values=>{const payload={...values,...(current ? {component_id:current.id} : {equipment_id:data.id})};Object.keys(payload).forEach(key=>{if(payload[key]==='') delete payload[key];});await api(current ? '/api/registry/replace' : '/api/registry/install',payload);await registryData();await equipmentDetail(data.id);message(current ? 'Replacement recorded. The previous installation remains in history.' : 'Installed component recorded.');}});
  }
  function stock(partId) { const part=state.parts.find(item=>item.id===partId);dialog('Record spare stock',`${part?.name || partId} · This records the quantity at a stock location.`,field('location','Stock location','',{required:true})+field('quantity','Spare quantity','0',{type:'number',min:0,required:true}),{label:'Save spare quantity',action:async values=>{await api('/api/registry/stock',{part_id:partId,location:values.location,quantity:Number(values.quantity)});await registryData();renderEquipmentDetail();message('Spare stock recorded separately from installed components.');}}); }
  function attachManual() {const data=state.detail;dialog('Attach a manual reference','Use the retained document reference and exact equipment applicability.',field('title','Manual title','',{required:true,wide:true})+field('reference','Reference ID or URN','',{required:true,wide:true,help:'A registered document reference, not a web address.'})+field('revision','Revision','',{required:true})+field('model','Applicable model',data.model,{required:true})+field('configuration','Applicable configuration',data.configuration,{required:true}),{label:'Attach reference',action:async values=>{await api('/api/registry/manuals',{...values,equipment_id:data.id});await equipmentDetail(data.id);message('Manual reference attached with declared applicability.');}});}
  async function fleetOverview() {
    shell('fleet',empty('Reading the fleet','Loading registered equipment, actual delivery state and open maintenance cases.'));
    const data=await api('/api/fleet'), equipment=list(data,'equipment'),summary=data.summary || {};
    shell('fleet',`<div class="ob-toolbar"><p>Registered equipment ordered by the server's current review priorities.</p><div class="ob-actions"><button class="button secondary" data-ob="refresh">Refresh fleet</button><button class="button primary" data-view="registry">Open registry</button></div></div><div class="ob-stats">${stat('Registered equipment',summary.equipment ?? equipment.length,'Across the equipment registry')}${stat('Needs attention',summary.needs_attention,'Condition, delivery or open review',true)}${stat('Missing or stale data',summary.missing_data,'No current verified condition',true)}${stat('Open maintenance cases',summary.open_cases,'Retained maintenance episodes')}</div><div class="ob-card-head"><div><span class="ob-kicker">PRIORITIZED EQUIPMENT</span><h2>What needs a closer look?</h2></div><label class="ob-field"><span class="sr-only">Filter fleet</span><select id="obFleetFilter"><option value="all">All equipment</option><option value="attention">Needs attention</option><option value="missing">Missing / stale data</option><option value="cases">Open cases</option></select></label></div><div id="obFleetTable"></div><div class="ob-note">Condition is shown only when a supported observation is available. An equipment record without readings remains unassessed. This list is a planning view, not an operational readiness rating.</div><p class="ob-refresh-note">Server state retrieved ${esc(date(new Date().toISOString()))}.</p>`);
    function paint() {
      const filter=$('obFleetFilter').value, rows=equipment.filter(item=>filter==='all' || (filter==='attention' && item.priority_reasons?.length) || (filter==='missing' && (['missing','missing_data','no_data','stale','never_received'].includes(item.data_status) || item.condition?.stale===true)) || (filter==='cases' && item.open_cases>0));
      $('obFleetTable').innerHTML=rows.length ? table(['Equipment / location','Observed condition','Data / delivery','Open cases','Review priority'],rows.map(item=>`<tr><td><button class="ob-link" data-ob-equipment="${esc(item.id)}"><strong>${esc(item.id)} · ${esc(item.name)}</strong></button><small>${esc(item.model)} / ${esc(item.configuration)}</small><small>${esc(item.location || 'Location not recorded')}</small></td><td>${chip(item.condition?.status || 'unknown',item.condition?.label || 'Not assessed')}</td><td>${chip(item.data_status || 'unknown')}<small>Received: ${esc(date(item.last_received_at))}</small><small>KD verified: ${esc(date(item.last_verified_at))}</small></td><td>${item.open_cases ? `<button class="ob-link" data-view="cases">${count(item.open_cases)} open</button>` : count(item.open_cases)}</td><td>${item.priority_reasons?.length ? `<ul class="ob-priority-reasons">${item.priority_reasons.map(reason=>`<li>${esc(reason)}</li>`).join('')}</ul>` : '<small>No current priority reason recorded</small>'}</td></tr>`)) : empty('No equipment in this filter','Change the filter to review the rest of the registered equipment.');
    }
    $('obFleetFilter').addEventListener('change',paint);paint();
  }
  async function sourceData() {state.sources=list(await api('/api/source-configs'),'sources');}
  function sourceOptions() {return state.sources.map(source=>[source.source_id,`${source.label || source.source_id} · ${source.source_id}`]);}
  async function importsView() {
    clearTimeout(receiptTimer);
    shell('imports',empty('Opening the import workspace','Reading saved sources and retained import receipts.'));
    const results=await Promise.allSettled([registryData(),sourceData(),api('/api/imports')]);
    for(const result of results) if(result.status==='rejected') throw result.reason;
    state.imports=list(results[2].value,'imports');
    if(!state.sources.some(item=>item.source_id===state.sourceId)) state.sourceId=state.sources.find(item=>item.kind==='csv')?.source_id || state.sources[0]?.source_id || '';
    shell('imports',`<div class="ob-toolbar"><p>Original uploads and validation receipts are retained on the server after import.</p><div class="ob-actions"><button class="button secondary" data-ob="add-source">Set up a source</button><button class="button secondary" data-ob="refresh-imports">Refresh receipts</button></div></div><div class="ob-tabs" role="group" aria-label="Import type"><button data-ob-kind="csv" class="${state.importKind==='csv' ? 'active' : ''}">CSV readings</button><button data-ob-kind="document" class="${state.importKind==='document' ? 'active' : ''}">Documents</button></div><ol class="ob-import-steps" aria-label="Import steps"><li class="active"><span>01</span>Choose file</li><li id="obStepPreview"><span>02</span>Preview & map</li><li id="obStepReceipt"><span>03</span>Import & verify</li></ol><section class="ob-card" id="obImportSetup"></section><div id="obImportPreview"></div><div id="obImportReceipt"></div><div class="ob-section-head"><h3>Recent import receipts</h3><span class="ob-help">Saved on the server</span></div><div id="obImportHistory"></div>`);
    renderImportSetup();renderImportHistory();if(state.receipt) {renderReceipt();scheduleReceipt();}
  }
  function renderImportSetup() {
    const documentMode=state.importKind==='document', node=$('obImportSetup');
    node.innerHTML=`<div class="ob-card-head"><div><span class="ob-kicker">${documentMode ? 'MANUALS & DOCUMENTS' : 'NORMALIZED MEASUREMENTS'}</span><h2>${documentMode ? 'Keep the document and its context.' : 'Start with a file you can inspect.'}</h2></div>${chip('',documentMode ? 'Text · HTML · Markdown' : 'UTF-8 CSV')}</div>${documentMode ? `<div class="ob-form" id="obDocumentMetadata">${field('title','Document title','',{required:true,wide:true})}${field('revision','Revision','',{required:true})}${select('asset_id','Applicable equipment',state.equipment.map(item=>[item.id,`${item.id} · ${item.name}`]),state.selected || '')}${select('document_type','Document type',[['manual','Manual'],['inspection','Inspection'],['work_order','Work order'],['other','Other']])}</div><div class="ob-note">The selected equipment identity establishes declared applicability. Retaining or indexing a document does not establish its authority.</div>` : `<div class="ob-form"><label class="wide">Saved source<select id="obImportSource">${state.sources.length ? sourceOptions().map(([id,label])=>`<option value="${esc(id)}" ${id===state.sourceId ? 'selected' : ''}>${esc(label)}</option>`).join('') : '<option value="">Set up a source first</option>'}</select><span class="ob-help">Mapping defaults come from the saved source. Measurements must use the normalized units shown in the field labels.</span></label></div>`}<label class="ob-upload" style="margin-top:18px"><strong>${documentMode ? 'Choose a document' : 'Choose a readings file'}</strong><p>${documentMode ? 'Text, Markdown and HTML are supported. Preview is displayed as plain text.' : 'Review the column mapping and row-level validation before importing.'}</p><input id="obImportFile" type="file" accept="${documentMode ? '.txt,.md,.html,.htm,text/plain,text/markdown,text/html' : '.csv,text/csv'}" aria-label="${documentMode ? 'Choose document file' : 'Choose CSV readings file'}"></label><p id="obFileMeta" class="ob-file-meta"></p><div class="ob-actions"><button class="button primary" id="obPreviewButton" data-ob="preview" disabled>${documentMode ? 'Review document' : 'Preview & validate'}</button>${documentMode ? '' : '<button class="button secondary" data-ob="add-source">Add source</button>'}</div>`;
    $('obImportFile').addEventListener('change',async event=>{
      const file=event.target.files[0];state.file=null;state.preview=null;state.receipt=null;clearTimeout(receiptTimer);$('obImportPreview').innerHTML='';$('obImportReceipt').innerHTML='';$('obStepPreview').classList.remove('active');$('obStepReceipt').classList.remove('active');$('obPreviewButton').disabled=true;
      if(!file) return;
      if(file.size>2*1024*1024) {message('Choose a file no larger than 2 MB for this demonstration import.',true);return;}
      try {state.file={filename:file.name,content:new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(await file.arrayBuffer())};$('obFileMeta').textContent=`${file.name} · ${(file.size/1024).toFixed(1)} KB · Ready to preview`; $('obPreviewButton').disabled=false;
        if(documentMode) {const title=$('obDocumentMetadata').querySelector('[name=title]');if(!title.value) title.value=file.name.replace(/\.[^.]+$/,'');}
      } catch(error) {message(error.message,true);}
    });
    $('obImportSource')?.addEventListener('change',event=>{state.sourceId=event.target.value;state.preview=null;$('obImportPreview').innerHTML='';});
    $('obDocumentMetadata')?.addEventListener('input',()=>{state.preview=null;$('obImportPreview').innerHTML='';$('obStepPreview').classList.remove('active');});
    if(state.file) {$('obFileMeta').textContent=state.file.filename+' · Retained in this browser until import';$('obPreviewButton').disabled=false;}
  }
  function currentMapping() {return Object.fromEntries(mappingFields.map(([name])=>[name,$(`obMap-${name}`)?.value ?? state.sources.find(source=>source.source_id===state.sourceId)?.mapping?.[name] ?? name]));}
  async function previewImport() {
    if(!state.file) return;
    const button=$('obPreviewButton');button.disabled=true;message('');
    try {
      if(state.importKind==='document') {
        const inputs=[...$('obDocumentMetadata').querySelectorAll('input,select')];if(inputs.some(input=>!input.reportValidity())) return;
        state.preview={kind:'document',metadata:Object.fromEntries(inputs.map(input=>[input.name,input.value]))};
        $('obImportPreview').innerHTML=`<section class="ob-card" style="margin-top:18px"><div class="ob-card-head"><div><span class="ob-kicker">LOCAL DOCUMENT PREVIEW</span><h2>${esc(state.preview.metadata.title)}</h2></div>${chip('','Not yet imported')}</div><p class="ob-help">${esc(state.file.filename)} · Revision ${esc(state.preview.metadata.revision)} · Equipment ${esc(state.preview.metadata.asset_id)}</p><pre class="ob-preview-text">${esc(state.file.content.slice(0,16000))}</pre><p class="ob-help">${state.file.content.length>16000 ? 'Showing the first 16,000 characters. ' : ''}The server validates and retains the original on import. HTML is shown as text here.</p><div class="ob-actions" style="margin-top:17px"><button class="button primary" data-ob="commit">Import document</button></div></section>`;
      } else {
        if(!state.sourceId) throw new Error('Save a CSV source before previewing readings.');
        state.preview=await api('/api/imports/preview',{kind:'csv',source_id:state.sourceId,...state.file,mapping:currentMapping()});renderCSVPreview();
      }
      $('obStepPreview').classList.add('active');
    } catch(error) {message(error.message,true);}
    finally {button.disabled=false;}
  }
  function renderCSVPreview() {
    const data=state.preview, columns=data.columns || [];
    $('obImportPreview').innerHTML=`<section class="ob-card" style="margin-top:18px"><div class="ob-card-head"><div><span class="ob-kicker">FIELD MAPPING & VALIDATION</span><h2>Check what will be accepted.</h2></div>${chip('','Preview only')}</div><div class="ob-mapping">${mappingFields.map(([name,label])=>`<label class="ob-field">${esc(label)}<select id="obMap-${name}">${[['','Not mapped'],...columns.map(column=>[column,column])].map(([value,text])=>`<option value="${esc(value)}" ${(data.mapping?.[name] || '')===value ? 'selected' : ''}>${esc(text)}</option>`).join('')}</select></label>`).join('')}</div><div class="ob-actions"><button class="button secondary" data-ob="remap">Validate mapping</button><button class="button secondary" data-ob="save-mapping">Save mapping to source</button><span id="obMappingState" class="ob-help">${data.mapping_errors?.length ? esc(data.mapping_errors.join("; ")) : "Mapping validated below"}</span></div><div class="ob-stats" style="margin-top:20px">${stat('Accepted rows',data.accepted_count,'Eligible for import')}${stat('Rejected rows',data.rejected_count,'Validation problems',true)}${stat('Duplicate rows',data.duplicate_count,'Excluded from acceptance')}${stat('Columns found',columns.length,'Available for mapping')}</div>${acceptedTable(data.accepted_rows || [])}${rejectedTable(data)}<div class="ob-note">Only accepted, nonduplicate rows will be imported. Rejected rows remain in the receipt. A successful upload is separate from KD readback verification.</div><div class="ob-actions"><button class="button primary" id="obCommitCSV" data-ob="commit" ${!data.accepted_count ? 'disabled' : ''}>Import ${count(data.accepted_count)} accepted rows</button><span class="ob-help">${esc(state.file.filename)}</span></div></section>`;
    mappingFields.forEach(([name])=>$(`obMap-${name}`).addEventListener('change',()=>{$('obCommitCSV').disabled=true;$('obMappingState').textContent='Mapping changed — validate again before import';state.preview.mappingDirty=true;}));
  }
  function acceptedTable(rows) {
    if(!rows.length) return empty('No accepted rows','Check the mapping, registered equipment IDs, timestamps, units and required readings.');
    return `<h3 style="font-size:13px;margin:15px 0 10px">Accepted sample <span class="ob-count">First ${Math.min(rows.length,8)} rows</span></h3>${table(['Row','Equipment','Timestamp','Measurements'],rows.slice(0,8).map(row=>`<tr><td>${count(row.row_number)}</td><td>${esc(row.asset_id)}</td><td>${esc(row.sample?.timestamp || row.timestamp)}</td><td>${Object.entries(row.sample || {}).filter(([key])=>!['timestamp','quality'].includes(key)).map(([key,value])=>`${esc(key)}: ${esc(value)}`).join(' · ')}${row.sample?.quality ? `<small>Quality: ${esc(row.sample.quality)}</small>` : ''}</td></tr>`))}`;
  }
  function rejectedTable(data) {
    const rejected=data.rejected_rows || data.rows?.rejected_rows || [],duplicates=data.duplicate_rows || data.rows?.duplicate_rows || [];
    if(!rejected.length && !duplicates.length) return '';
    return `<details ${!data.accepted_count ? 'open' : ''}><summary>${count(data.rejected_count ?? rejected.length)} rejected · ${count(data.duplicate_count ?? duplicates.length)} duplicate rows</summary>${table(['Row','Outcome','Reason'],[...rejected.slice(0,50).map(row=>`<tr><td>${count(row.row_number)}</td><td>${chip('rejected')}</td><td>${esc((row.reasons || [row.reason || 'Validation failed']).join('; '))}</td></tr>`),...duplicates.slice(0,50).map(row=>`<tr><td>${count(row.row_number)}</td><td>${chip('','Duplicate')}</td><td>${esc(row.reason || 'Already retained')}</td></tr>`)])}<p class="ob-help">Up to 50 rows per outcome shown here. The server retains the complete validation receipt.</p></details>`;
  }
  async function commitImport(button) {
    if(!state.file || !state.preview || state.preview.mappingDirty) return;button.disabled=true;message('');
    try {
      let payload;
      if(state.importKind==='document') {const {asset_id,...metadata}=state.preview.metadata;payload={kind:'document',...state.file,metadata:{...metadata,asset_ids:[asset_id]}};}
      else payload={kind:'csv',source_id:state.sourceId,...state.file,mapping:state.preview.mapping};
      const data=await api('/api/imports/commit',payload);state.receipt=data.receipt || data;renderReceipt();$('obStepReceipt').classList.add('active');scheduleReceipt();await refreshImports();
      $('obImportReceipt').scrollIntoView({block:'start',behavior:'smooth'});
    } catch(error) {message(error.message,true);button.disabled=false;}
  }
  function receiptStatus(data) {return data.status || 'unknown';}
  function deliveryControls(data) {
    const terminal=['verified','rejected','duplicates_only'].includes(data.status);
    return `${!terminal && data.status!=='uncertain' && data.jobs?.some(job=>job.status==='queued') ? '<button class="button primary" data-ob="dispatch-receipt">Submit / resume indexing</button>' : ''}${!terminal ? '<button class="button secondary" data-ob="poll-receipt">Check KD delivery</button>' : ''}`;
  }
  async function advanceReceipt(command,button) {
    button.disabled=true;
    try {const data=await api('/api/imports/'+encodeURIComponent(state.receipt.import_id)+'/'+command,{});state.receipt=data.receipt || data;renderReceipt();scheduleReceipt();await refreshImports();}
    finally {button.disabled=false;}
  }
  function renderReceipt() {
    const data=state.receipt,node=$('obImportReceipt');if(!data || !node) return;
    const status=receiptStatus(data),problem=['uncertain','delivery_problem','rejected','error'].includes(status),step=status==='verified' ? 3 : ['submitted','pending','queued'].includes(status) ? 2 : 1;
    const copy={verified:'The submitted content passed KD readback verification.',queued:'Accepted content is queued. KD readback has not yet been verified.',indexing:'Accepted content is being indexed. KD readback has not yet verified every record.',submitted:'Content was submitted to KD. Waiting for commit and readback verification.',uncertain:'The delivery outcome is uncertain. The saved receipt must be reconciled before another submission.',delivery_problem:'Delivery needs attention. Accepted records remain retained with this receipt.',rejected:'No eligible records were submitted. Review the validation results.'}[status] || 'Read the saved job state below for actual delivery progress.';
    node.innerHTML=`<section class="ob-card ob-receipt"><div class="ob-card-head"><div><span class="ob-kicker">RETAINED IMPORT RECEIPT</span><h2>${esc(data.filename || data.kind || 'Import')}</h2></div>${chip(status)}</div><p>${esc(copy)}</p><div class="ob-progress" aria-label="${esc(human(status))}">${[1,2,3].map(index=>`<span class="${index<=step ? (problem ? 'problem' : 'done') : ''}"></span>`).join('')}</div><div class="ob-receipt-grid"><div><strong>${count(data.accepted_count ?? data.counts?.accepted)}</strong><span>Accepted</span></div><div><strong>${count(data.rejected_count ?? data.counts?.rejected)}</strong><span>Rejected</span></div><div><strong>${count(data.duplicate_count ?? data.counts?.duplicates)}</strong><span>Duplicate</span></div></div>${data.error || data.message ? `<div class="ob-note warning">${esc(data.error || data.message)}</div>` : ''}<p class="ob-help">Receipt ${esc(data.import_id || data.id)} · Updated ${esc(date(data.updated_at || data.created_at))}</p>${data.document_id ? `<p class="ob-help">Document reference: <span class="ob-inline-code">${esc(data.document_id)}</span></p>` : ''}${data.jobs?.length ? `<details><summary>${data.jobs.length} delivery job${data.jobs.length===1 ? '' : 's'}</summary>${table(['Equipment / reference','State','Detail'],data.jobs.map(job=>`<tr><td>${esc(job.asset_id || job.reference || job.document_id || job.job_id || job.id)}</td><td>${chip(job.status || job.state || 'unknown')}</td><td>${esc(job.error || job.message || job.detail || '')}${job.verified_at ? `<small>Verified ${esc(date(job.verified_at))}</small>` : ''}</td></tr>`))}</details>` : ''}${rejectedTable(data)}<div class="ob-actions" style="margin-top:17px"><button class="button secondary" data-ob="refresh-receipt">Refresh receipt</button>${deliveryControls(data)}<button class="button secondary" data-view="connections">Source health</button></div><p id="obReceiptRefresh" class="ob-refresh-note" role="status">${['queued','submitted','pending','indexing'].includes(status) ? 'Checking this saved receipt every five seconds while this workspace is open.' : 'This is the saved server delivery state.'}</p></section>`;
  }
  function scheduleReceipt() {clearTimeout(receiptTimer);if(fleet.getView()==='imports' && !document.hidden && ['queued','submitted','pending','indexing'].includes(state.receipt?.status)) receiptTimer=setTimeout(()=>refreshReceipt(),5000);}
  async function refreshReceipt() {
    if(!state.receipt) return;
    try {const data=await api('/api/imports/'+encodeURIComponent(state.receipt.import_id || state.receipt.id));state.receipt=data.receipt || data;renderReceipt();scheduleReceipt();}
    catch(error) {const node=$('obReceiptRefresh');if(node) node.textContent='Receipt refresh stopped: '+error.message;message(error.message,true);}
  }
  async function refreshImports() {state.imports=list(await api('/api/imports'),'imports');renderImportHistory();}
  function renderImportHistory() {const node=$('obImportHistory');if(!node) return;node.innerHTML=state.imports.length ? table(['File / receipt','Kind','Accepted / rejected','Delivery',''],state.imports.map(data=>`<tr><td><strong>${esc(data.filename || data.import_id)}</strong><small>${esc(date(data.created_at))}</small></td><td>${esc(human(data.kind))}</td><td>${count(data.accepted_count)} / ${count(data.rejected_count)}</td><td>${chip(data.status)}</td><td><button class="ob-link" data-ob-receipt="${esc(data.import_id || data.id)}">Open receipt</button></td></tr>`)) : empty('No imports recorded','Choose a file, review its content and import accepted records to create the first receipt.');}
  async function connections() {
    clearTimeout(sourceTimer);
    shell('connections',`<div class="ob-toolbar"><p>Saved configuration and actual acquisition or delivery state.</p><div class="ob-actions"><button class="button secondary" data-ob="refresh">Refresh health</button><button class="button primary" data-ob="add-source">Add source</button></div></div><div id="obSourceCards" class="ob-sources">${empty('Checking saved sources','Reading the server state and last observed timestamps.')}</div><div class="ob-note">Saving an API or historian connection records its configuration. Acquisition requires a source-specific adapter; a saved endpoint alone does not establish a connected feed. Real measurements remain observation-only.</div><p class="ob-refresh-note" id="obSourceRefresh" role="status"></p>`);
    await refreshSources();
  }
  async function refreshSources() {
    clearTimeout(sourceTimer);
    try {
      await sourceData();const node=$('obSourceCards');if(!node) return;
      node.innerHTML=state.sources.length ? state.sources.map(source=>{
        const health=source.health || {},status=health.state || health.status || 'unknown';
        return `<article class="ob-card ob-source"><div class="ob-card-head"><div><span class="ob-kicker">${esc(human(source.kind))} · ${source.synthetic ? 'SYNTHETIC' : 'OBSERVATION ONLY'}</span><h2>${esc(source.label || source.source_id)}</h2><p class="ob-inline-code" style="margin-top:7px">${esc(source.source_id)}</p></div>${chip(status)}</div><dl><div><dt>Expected interval</dt><dd>${count(source.expected_interval_seconds)} seconds</dd></div><div><dt>Acquisition</dt><dd>${esc(human(source.adapter_status || 'Not connected'))}</dd></div><div><dt>Last received</dt><dd>${esc(date(source.last_received_at))}</dd></div><div><dt>Last KD verified</dt><dd>${esc(date(source.last_verified_at))}</dd></div><div><dt>Latest reading time</dt><dd>${esc(date(source.latest_reading_at))}</dd></div><div><dt>Rejected records</dt><dd>${count(source.rejected_count ?? source.rejected_rows)}</dd></div></dl>${source.endpoint ? `<p class="ob-inline-code">${esc(source.endpoint)}</p>` : ''}${health.errors?.length ? `<div class="ob-note warning">${health.errors.map(error=>esc(error)).join('<br>')}</div>` : ''}${health.interrupted ? '<p class="ob-help">Expected delivery is interrupted. Check the producer and delivery path.</p>' : ''}${health.stale ? '<p class="ob-help">The latest observation is older than this source’s expected interval.</p>' : ''}<details><summary>Saved field mapping</summary>${table(['Normalized field','Source column'],Object.entries(source.mapping || {}).map(([field,column])=>`<tr><td>${esc(field)}</td><td>${esc(column)}</td></tr>`))}</details><div class="ob-actions"><button class="button secondary" data-ob-source="${esc(source.source_id)}">Edit configuration</button><button class="button secondary" data-ob-import-source="${esc(source.source_id)}">Import readings</button></div></article>`;
      }).join('') : empty('Set up the first source','Save a CSV mapping and its expected cadence, then import a file to observe actual health.');
      $('obSourceRefresh').textContent='Server health retrieved '+date(new Date().toISOString())+'. Refreshes every 15 seconds while this view is open.';
      if(fleet.getView()==='connections' && !document.hidden) sourceTimer=setTimeout(()=>refreshSources(),15000);
    } catch(error) {message(error.message,true,'connections');if($('obSourceRefresh')) $('obSourceRefresh').textContent='Automatic refresh stopped. Refresh health to try again.';}
  }
  function configureSource(sourceId) {
    const source=state.sources.find(item=>item.source_id===sourceId) || {},mapping=source.mapping || Object.fromEntries(mappingFields.map(([name])=>[name,name]));
    const fields=field('source_id','Source ID',source.source_id || '',{required:true,help:'Stable identifier used in reading provenance.'})+field('label','Source name',source.label || '',{required:true})+select('kind','Source type',[['csv','CSV upload'],['api','API configuration'],['historian','Historian configuration']],source.kind || 'csv')+field('expected_interval_seconds','Expected interval (seconds)',source.expected_interval_seconds || 300,{type:'number',min:1,required:true})+field('endpoint','Endpoint (optional)',source.endpoint || '',{wide:true,help:'HTTPS address without credentials or query parameters. API and historian adapters are not connected by saving this configuration.'})+'<label class="ob-check wide"><input type="checkbox" name="synthetic" '+(source.synthetic ? 'checked' : '')+'>This source contains synthetic demonstration readings</label><div class="wide"><span class="ob-kicker">SOURCE COLUMN MAPPING</span><p class="ob-help">Use exact column names. Units must already match the normalized measurement labels.</p></div>'+mappingFields.map(([name,label])=>field('map_'+name,label,mapping[name] || name,{required:true})).join('');
    dialog(sourceId ? 'Edit source configuration' : 'Set up a source','Save the connection identity, expected cadence and measurement mapping.',fields,{label:'Save source',action:async values=>{
      const payload={source_id:values.source_id,label:values.label,kind:values.kind,endpoint:values.endpoint,expected_interval_seconds:Number(values.expected_interval_seconds),synthetic:values.synthetic==='on',mapping:Object.fromEntries(mappingFields.map(([name])=>[name,values['map_'+name]])),units};
      await api('/api/source-configs',payload);state.sourceId=payload.source_id;await sourceData();
      if(fleet.getView()==='connections') await refreshSources();else if(fleet.getView()==='imports') {state.preview=null;$('obImportPreview').innerHTML='';$('obStepPreview').classList.remove('active');renderImportSetup();}message('Source configuration and mapping saved. Health reflects actual received data and delivery.');
    }});
    if(sourceId) $('obDialogForm').querySelector('[name=source_id]').readOnly=true;
  }
  async function saveMapping() {
    const source=state.sources.find(item=>item.source_id===state.sourceId);if(!source) return;
    if(state.preview?.mappingDirty || state.preview?.mapping_errors?.length) throw new Error('Validate the changed mapping before saving it.');
    const {source_id,label,kind,endpoint,expected_interval_seconds,synthetic}=source;
    await api('/api/source-configs',{source_id,label,kind,endpoint,expected_interval_seconds,synthetic,mapping:state.preview.mapping,units:source.units || units});await sourceData();message('Validated field mapping saved to the source.');
  }
  async function openDocument(id) {
    const data=await api('/api/documents/'+encodeURIComponent(id)),node=$('obDialog');
    node.innerHTML=`<div class="dialog-heading"><span class="ob-kicker">RETAINED DOCUMENT</span><button type="button" class="icon-button" data-ob="close-dialog" aria-label="Close document">×</button></div><h2>${esc(data.title)}</h2><p>Revision ${esc(data.revision)} · Equipment ${esc((data.asset_ids || []).join(', '))}</p>${chip(data.indexing_status)}<pre class="ob-preview-text">${esc(data.text)}</pre><p class="ob-help">Plain-text preview. The downloaded original contains the retained uploaded bytes.</p><p class="ob-inline-code">SHA-256: ${esc(data.original_sha256)}</p><div class="ob-actions" style="margin-top:18px"><a class="button primary" href="/api/documents/${encodeURIComponent(id)}/original" download>Download original</a><button class="button secondary" data-ob="close-dialog">Close</button></div>`;
    node.showModal();
  }
  async function attachUploadedDocument(id) {
    const doc=state.detail.documents.find(item=>item.document_id===id);if(!doc) return;
    await api('/api/registry/manuals',{equipment_id:state.detail.id,reference:id,title:doc.title,revision:doc.revision,model:state.detail.model,configuration:state.detail.configuration});
    await equipmentDetail(state.detail.id);message('Uploaded manual attached to the equipment. Its indexing status remains visible separately.');
  }
  async function modelEvidence() {
    shell('model-evidence',empty('Reading the evaluation','Loading the recorded benchmark and matching it to the current model.'));
    const data=await api('/api/model-evidence');
    if(data.available===false || !data.summary) {shell('model-evidence',`<div class="ob-note warning">The condition model remains illustrative. A usable evaluation report is not available.</div>${empty('Evaluation unavailable',data.message || 'Run the frozen-rule evaluation to record reproducible results.')}<button class="button secondary" style="margin-top:17px" data-ob="refresh">Check again</button>`);return;}
    const summary=data.summary,model=summary.model || {},baseline=summary.threshold_baseline || {},forecast=summary.forecast || {},current=data.model_matches===true && data.evaluation_matches===true;
    const pair=(label,a,b,denom,rate=false)=>`<tr><td><strong>${esc(label)}</strong></td><td>${rate ? percent(a) : count(a)}${denom ? `<small>${esc(denom)}</small>` : ''}</td><td>${rate ? percent(b) : count(b)}${denom ? `<small>${esc(denom)}</small>` : ''}</td></tr>`;
    shell('model-evidence',`<div class="ob-toolbar"><p>Recorded evaluation · ${esc(data.protocol_version || 'Frozen rule')}</p><div class="ob-actions">${chip('', 'Illustrative model')}<button class="button secondary" data-ob="refresh">Refresh evidence</button></div></div><div class="ob-note warning"><strong>${current ? 'Separately authored synthetic histories; no independent real-world validation.' : 'This report does not match the current model or evaluation code.'}</strong><br>${esc(data.definitions?.independence || '')} ${esc(data.external_histories?.message || 'External equipment histories and independently adjudicated outcomes are not available.')}</div><div class="ob-stats">${stat('Complete histories',summary.trajectories,'Whole trajectories are evaluation units')}${stat('Target crossings',summary.target_events,'Authored review-threshold crossings')}${stat('False-alert histories',model.false_alert_trajectories_without_event,`${count(summary.no_target_event_trajectories)} histories without a target crossing`,true)}${stat('Useful warnings',model.events_with_at_least_10_minutes_warning,`${count(summary.target_events)} events · at least 10 minutes`)}</div><section class="ob-card"><div class="ob-card-head"><div><span class="ob-kicker">FROZEN RULE VS. CURRENT-THRESHOLD BASELINE</span><h2>Earlier warnings come with more false alerts.</h2></div>${chip(current ? 'verified' : 'error',current ? 'Report matches code' : 'Report mismatch')}</div><p class="ob-help">Target: ${esc(data.target)}</p><div style="margin-top:18px">${table(['Measure','Illustrative model','Threshold baseline'],[pair('False-alert rate on non-event histories',model.false_alert_rate_among_no_event_trajectories,baseline.false_alert_rate_among_no_event_trajectories,`${count(summary.no_target_event_trajectories)} histories without a crossing`,true),pair('Missed events by crossing',model.missed_events_by_crossing,baseline.missed_events_by_crossing,`${count(summary.target_events)} target events`),pair('Events with at least 10 minutes of warning',model.events_with_at_least_10_minutes_warning,baseline.events_with_at_least_10_minutes_warning,`${count(summary.target_events)} target events`),pair('Median warning time (minutes)',model.median_lead_minutes_among_detected_events,baseline.median_lead_minutes_among_detected_events,'Among detected events only')])}</div><div class="ob-note">${esc(data.definitions?.false_alert_rate)} ${esc(data.definitions?.event_matching)}</div></section><div class="ob-grid" style="margin-top:18px"><section class="ob-card"><span class="ob-kicker">CROSSING-TIME FORECAST</span><h3>Point estimates still carry substantial error.</h3><div class="ob-receipt-grid" style="margin-top:19px"><div><strong>${count(forecast.first_matched_forecast_mean_absolute_error_minutes)}</strong><span>Minutes mean absolute error</span></div><div><strong>${count(forecast.events_with_a_matched_forecast)}</strong><span>Events with matched forecasts</span></div><div><strong>${percent(forecast.abstention_rate)}</strong><span>Forecast abstention rate</span></div></div><p class="ob-help" style="margin-top:18px">${esc(data.definitions?.forecast_error)}</p><p class="ob-help">${esc(data.definitions?.baseline_forecast)}</p></section><section class="ob-card"><span class="ob-kicker">INDEPENDENT HISTORIES</span><h3>${data.external_histories?.available ? 'External evaluation recorded.' : 'The next evidence gap is external data.'}</h3><p style="margin-top:13px">${esc(data.external_histories?.message || 'No independently sourced equipment histories or failure outcomes have been evaluated. The current report is a separately authored synthetic stress suite.')}</p><div class="ob-note">Separate complete histories, freeze model rules before evaluation, adjudicate event labels and compare false alarms and warning times against a simple baseline.</div></section></div><section class="ob-card" style="margin-top:18px"><div class="ob-card-head"><div><span class="ob-kicker">PER-SCENARIO RESULTS</span><h3>See which histories expose the weaknesses.</h3></div></div>${table(['History family','Target events','False-alert histories','Useful warnings','Median lead'],Object.entries(data.by_family || {}).map(([name,row])=>`<tr><td><strong>${esc(human(name))}</strong><small>${count(row.trajectories)} complete histories</small></td><td>${count(row.target_events)}</td><td>${count(row.model?.false_alert_trajectories_without_event)} / ${count(row.no_target_event_trajectories)} non-events</td><td>${count(row.model?.events_with_at_least_10_minutes_warning)} / ${count(row.target_events)} events</td><td>${count(row.model?.median_lead_minutes_among_detected_events)} min</td></tr>`))}<details><summary>Protocol definitions and limitations</summary><ul class="ob-limit-list">${(data.limitations || []).map(item=>`<li>${esc(item)}</li>`).join('')}</ul><p class="ob-help">${esc(data.definitions?.ground_truth)}</p><p class="ob-help">${esc(data.definitions?.forecast_abstention)}</p><p class="ob-inline-code">Model ${esc(data.model_version)} · ${esc(data.generator_version)}</p><p class="ob-inline-code">Model SHA-256: ${esc(data.model_source_sha256)}</p><p class="ob-inline-code">Evaluation SHA-256: ${esc(data.evaluation_source_sha256)}</p></details></section>`);
  }
  async function loadView(view=fleet.getView()) {
    clearTimeout(receiptTimer);clearTimeout(sourceTimer);
    if(!views.includes(view)) return;
    try {await ({fleet:fleetOverview,registry,imports:importsView,connections,'model-evidence':modelEvidence}[view])();}
    catch(error) {message(error.message,true,view);const viewNode=$(view+'View');if(viewNode && !viewNode.querySelector('button')) viewNode.insertAdjacentHTML('beforeend','<button class="button secondary" style="margin-top:17px" data-ob="refresh">Try again</button>');}
  }
  async function action(button) {
    const command=button.dataset.ob;
    if(command==='close-dialog') return $('obDialog').close();
    if(command==='refresh') return loadView();
    if(command==='add-equipment') return addEquipment();
    if(command==='add-part') return addPart();
    if(command==='install') return installComponent();
    if(command==='attach-manual') return attachManual();
    if(command==='upload-document') {state.importKind='document';state.file=null;state.preview=null;fleet.showView('imports');return;}
    if(command==='refresh-detail') return equipmentDetail(state.selected);
    if(command==='add-source') return configureSource();
    if(['preview','remap'].includes(command)) return previewImport();
    if(command==='save-mapping') return saveMapping();
    if(command==='commit') return commitImport(button);
    if(command==='refresh-receipt') return refreshReceipt();
    if(command==='dispatch-receipt') return advanceReceipt('dispatch',button);
    if(command==='poll-receipt') return advanceReceipt('poll',button);
    if(command==='refresh-imports') return refreshImports();
    if(button.dataset.obEquipment) {
      state.selected=button.dataset.obEquipment;
      if(fleet.getView()!=='registry') fleet.showView('registry');else await equipmentDetail(state.selected);return;
    }
    if(button.dataset.obTab) {state.tab=button.dataset.obTab;renderEquipmentDetail();return;}
    if(button.dataset.obReplace) return installComponent(button.dataset.obReplace);
    if(button.dataset.obDocument) return openDocument(button.dataset.obDocument);
    if(button.dataset.obAttachDocument) return attachUploadedDocument(button.dataset.obAttachDocument);
    if(button.dataset.obStock) return stock(button.dataset.obStock);
    if(button.dataset.obSource) return configureSource(button.dataset.obSource);
    if(button.dataset.obImportSource) {state.sourceId=button.dataset.obImportSource;state.importKind='csv';fleet.showView('imports');return;}
    if(button.dataset.obKind) {state.importKind=button.dataset.obKind;state.file=null;state.preview=null;await importsView();return;}
    if(button.dataset.obReceipt) {const data=await api('/api/imports/'+encodeURIComponent(button.dataset.obReceipt));state.receipt=data.receipt || data;renderReceipt();scheduleReceipt();$('obImportReceipt').scrollIntoView({block:'start',behavior:'smooth'});}
  }
  const modal=document.createElement('dialog');modal.id='obDialog';modal.className='ob-dialog';document.body.append(modal);
  window.FleetOnboarding = {
    openEquipment(id,tab='components') {state.selected=id;state.tab=tab;fleet.showView('registry');},
    openReadings(sourceId,assetId) {state.sourceId=sourceId || '';state.selected=assetId || state.selected;state.importKind='csv';state.file=null;state.preview=null;fleet.showView('imports');},
    openDocuments(assetId) {state.selected=assetId || state.selected;state.importKind='document';state.file=null;state.preview=null;fleet.showView('imports');}
  };
  document.addEventListener('click',event=>{
    const button=event.target.closest('[data-ob],[data-ob-equipment],[data-ob-tab],[data-ob-replace],[data-ob-stock],[data-ob-source],[data-ob-import-source],[data-ob-kind],[data-ob-receipt],[data-ob-document],[data-ob-attach-document]');
    if(!button || button.disabled) return;
    action(button).catch(error=>message(error.message,true));
  });
  window.addEventListener('fleet-view-changed',event=>loadView(event.detail.view));
  document.addEventListener('visibilitychange',()=>{if(document.hidden) {clearTimeout(receiptTimer);clearTimeout(sourceTimer);} else if(fleet.getView()==='imports') scheduleReceipt();else if(fleet.getView()==='connections') refreshSources();});
  if(views.includes(fleet.getView())) loadView();
})();
