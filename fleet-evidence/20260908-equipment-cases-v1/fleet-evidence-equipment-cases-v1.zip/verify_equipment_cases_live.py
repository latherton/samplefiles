#!/usr/bin/env python3
"""Installed equipment-case acceptance, read-only unless --exercise is supplied.

The explicit synthetic exercise retains a new fictional registry/import example,
captures a case with exact KD evidence, records review and replacement evidence,
imports later observations, closes the case, and retains a reproducible export.
--restart-demo-app additionally permits one app-service restart after closure;
it requires --exercise. Existing case rows, paused mission, KD references and
container lifecycles are preserved. Receipts and HTML exports are private local
acceptance artifacts, never deployment-package or public-repository contents.
"""
import argparse
from collections import Counter
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import sys
import time
import urllib.parse

import verify_onboarding_live as onboarding
from deploy_equipment_cases_update import (ORIGIN, SERVICE, UNIT, app_state_snapshot, canonical,
                                          command, container_snapshot, database_snapshot,
                                          digest, fresh_write, now, require)


def preserve_case_additions(before, after, new_case_ids=()):
    """Preserve every prior schema/value while allowing explicit synthetic rows."""
    new_case_ids = set(new_case_ids)
    require(set(before['databases']) == set(after['databases']), 'The durable database inventory changed.')
    for database, tables in before['table_rows'].items():
        require(before['databases'][database] == after['databases'].get(database), 'An existing database table inventory changed.')
        for table, value in tables.items():
            other = after['table_rows'][database].get(table)
            require(other is not None and other['schema_sha256'] == value['schema_sha256'], 'An existing SQLite table schema changed.')
            if new_case_ids and (database in {'registry.sqlite3', 'onboarding.sqlite3'} or database == 'cases.sqlite3' and table == 'cases'):
                require(not (Counter(value['row_sha256']) - Counter(other['row_sha256'])),
                        'An existing registry, import or case row changed or disappeared.')
                if database == 'cases.sqlite3':
                    require(other['count'] == value['count'] + len(new_case_ids), 'Unexpected extra maintenance cases appeared.')
            else:
                require(value == other, 'A retained mission or application table changed.')
    old_cases = {row['id']: row['body_sha256'] for row in before['case_rows']}
    new_cases = {row['id']: row['body_sha256'] for row in after['case_rows']}
    require(set(new_cases) == set(old_cases) | new_case_ids and all(new_cases[ident] == value for ident, value in old_cases.items()),
            'Existing case bodies changed or an unrecorded case appeared.')
    require(before['mission_states'] == after['mission_states'], 'The paused mission state changed.')
    return True


def retained_case(case):
    return {key: value for key, value in case.items() if key not in {'latest', 'latest_error', 'context'}}


class EquipmentCaseVerification(onboarding.Verification):
    def __init__(self, output, exercise=False, timeout=900, restart_demo_app=False):
        require(not restart_demo_app or exercise, '--restart-demo-app requires --exercise.')
        super().__init__(output, exercise, timeout)
        self.restart_demo_app = restart_demo_app
        self.export_path = self.path.with_suffix('.case.html')
        require(not self.export_path.exists(), 'Choose a fresh HTML export path; prior acceptance artifacts are retained.')
        self.r.update(scope='Registry equipment maintenance case, exact imported evidence, replacement/follow-up and reproducible export; no validated prediction or maintenance authorization.',
                      restart_authorized_by_cli=restart_demo_app, restart_count=0)
        self.save()

    def context(self, asset, source=None):
        parameters = {'asset': asset}
        if source:
            parameters['source_id'] = source
        return self.request('/api/equipment-case-context?' + urllib.parse.urlencode(parameters))

    @staticmethod
    def selected(context, source):
        snapshot = context.get('snapshot') or context.get('selected')
        if not isinstance(snapshot, dict) or 'snapshot_id' not in snapshot:
            match = next((row for row in context.get('sources', []) if row.get('source_id') == source), None)
            snapshot = match.get('snapshot') if match else None
        require(isinstance(snapshot, dict) and snapshot.get('snapshot_id'), 'The selected source has no eligible verified imported snapshot.')
        return snapshot

    def case_exports(self, inventory):
        require(len(inventory.get('cases', [])) <= 200, 'Case inventory exceeds the export-preservation bound.')
        return {case['id']: {'sha256': digest(self.request('/api/cases/' + case['id'] + '/export', binary=True))}
                for case in inventory['cases']}

    def readonly_checks(self):
        super().readonly_checks()
        equipment = self.r['api_snapshot']['registry']['equipment']
        chosen = next((row for row in equipment if row['id'].startswith('QA-')), equipment[0])
        context = self.context(chosen['id'])
        self.check('registered-equipment-case-context-is-available', context.get('equipment', {}).get('id') == chosen['id']
                   and isinstance(context.get('sources'), list) and isinstance(context.get('documents'), list)
                   and isinstance(context.get('replacement_events'), list))
        self.check('case-context-imports-have-stable-selection-identities', all(not source.get('snapshot') or
                   source['snapshot'].get('source', {}).get('mode') == 'import' and source['snapshot'].get('snapshot_id')
                   for source in context['sources']))
        self.r['equipment_case_context'] = context
        self.save()

    def case_workflow(self):
        ids = self.r['exercise_ids']
        asset, part, source = ids['equipment_id'], ids['part_id'], ids['source_id']
        document_id = self.r['document_receipt']['document_id']
        self.stage('capturing-a-case-from-exact-imported-evidence')
        context = self.context(asset, source)
        snapshot = self.selected(context, source)
        case = self.request('/api/cases', {'mode': 'import', 'asset_id': asset, 'source_id': source,
                            'snapshot_id': snapshot['snapshot_id'], 'document_ids': [document_id],
                            'title': 'Synthetic equipment maintenance acceptance ' + asset,
                            'notes': 'Fictional review of imported observations; no physical failure or repair outcome is established.'})
        ident = case['id']
        ids['case_id'] = ident
        self.r['case_opened'] = retained_case(case)
        self.save()
        captured_hash = digest(canonical(case['captured']))
        evidence_hash = digest(canonical(case['evidence']))
        self.check('arbitrary-equipment-case-captures-live-verified-observations', case.get('kind') == 'equipment_review'
                   and case.get('workflow') == 'equipment_imports' and case.get('asset_id') == asset
                   and case.get('captured', {}).get('snapshot_id') == snapshot['snapshot_id']
                   and case['captured']['source'].get('mode') == 'import'
                   and case['captured']['source'].get('provenance', {}).get('live_verified_at')
                   and case['captured'].get('analysis', {}).get('forecast', {}).get('available') is not True)
        self.check('case-freezes-equipment-identity-and-applicable-manual', bool(case.get('equipment_identity'))
                   and bool(case.get('evidence')) and document_id in canonical(case['evidence']).decode())
        fleet_open = next(row for row in self.request('/api/fleet')['equipment'] if row['id'] == asset)
        self.check('fleet-prioritizes-the-new-open-maintenance-case', fleet_open.get('open_cases') == 1)
        self.stage('recording-review-and-linking-a-later-replacement-event')
        case = self.request('/api/cases/' + ident + '/review', {'version': case['version'],
                            'reviewer_role': 'Synthetic acceptance reviewer',
                            'findings': 'The fictional readings and retained manual warrant inspection; no fault is confirmed.',
                            'action': 'Record an illustrative component replacement and compare later observations.',
                            'document_ids': [document_id], 'notes': 'Demonstration review only.'})
        self.check('review-retains-explicit-human-findings', case.get('status') == 'reviewed' and case.get('review'))
        equipment = self.request('/api/registry/equipment/' + asset)
        previous = equipment['installed_components'][0]
        event_at = (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat(timespec='seconds').replace('+00:00', 'Z')
        replacement = self.request('/api/registry/replace', {'component_id': previous['id'], 'part_id': part,
                                   'serial': 'TEST-CASE-' + asset, 'installed_at': event_at,
                                   'notes': 'Synthetic post-review replacement, retained as an event without proving effectiveness.'})
        context = self.context(asset, source)
        event = next((event for event in context['replacement_events']
                      if event.get('component_id') == replacement['id'] or event.get('installed_component', {}).get('id') == replacement['id']), None)
        require(event is not None and event.get('id'), 'The new replacement event was not available for this equipment case.')
        case = self.request('/api/cases/' + ident + '/maintenance-event', {'version': case['version'], 'event_id': event['id'],
                            'notes': 'Retained old/new serials and event time; later observations are not causal proof.'})
        self.check('case-retains-both-sides-of-the-replacement-event', bool(case.get('registry_events'))
                   and previous['id'] in canonical(case['registry_events']).decode()
                   and replacement['id'] in canonical(case['registry_events']).decode())
        self.check('original-captured-window-and-evidence-stay-immutable', digest(canonical(case['captured'])) == captured_hash
                   and digest(canonical(case['evidence'])) == evidence_hash)
        self.stage('importing-later-observations-and-attaching-follow-up')
        # The second import follows the replacement timestamp but is still in
        # the past. This avoids manufacturing future samples or waiting on a
        # physical process that does not exist in this synthetic demonstration.
        base_time = datetime.now(timezone.utc) - timedelta(seconds=20)
        stamps = [(base_time + timedelta(seconds=index)).isoformat(timespec='seconds').replace('+00:00', 'Z') for index in range(2)]
        require(stamps[0] > event_at, 'Follow-up source clock did not advance beyond the replacement event.')
        content = ('asset_id,timestamp,quality,vibration_mm_s,temperature_c,pressure_bar,rpm,load_pct\n'
                   + ','.join((asset, stamps[0], 'good', '2.0', '49', '3.2', '1780', '65')) + '\n'
                   + ','.join((asset, stamps[1], 'good', '1.9', '49', '3.2', '1781', '65')) + '\n')
        mapping = {name: name for name in ('asset_id', 'timestamp', 'quality', 'vibration_mm_s', 'temperature_c', 'pressure_bar', 'rpm', 'load_pct')}
        receipt = self.wait_receipt(self.request('/api/imports/commit', {'kind': 'csv', 'source_id': source,
                                    'filename': 'synthetic-case-followup-' + asset + '.csv', 'content': content, 'mapping': mapping}))
        self.r['follow_up_receipt'] = receipt
        self.save()
        records = self.exact_import_readback(receipt)
        later = self.selected(self.context(asset, source), source)
        require(later['snapshot_id'] != snapshot['snapshot_id'], 'The later import did not produce a distinct selectable snapshot.')
        case = self.request('/api/cases/' + ident + '/follow-up', {'version': case['version'], 'source_id': source,
                            'snapshot_id': later['snapshot_id'], 'notes': 'Later fictional measurements are lower; this does not establish repair causation.'})
        self.check('later-follow-up-is-distinct-and-after-replacement', len(case.get('follow_ups', [])) == 1
                   and case['follow_ups'][0]['condition']['snapshot_id'] == later['snapshot_id']
                   and case['follow_ups'][0]['condition']['observed_at'] > event_at)
        self.check('follow-up-does-not-rewrite-original-capture', digest(canonical(case['captured'])) == captured_hash)
        case = self.request('/api/cases/' + ident + '/close', {'version': case['version'], 'disposition': 'monitor',
                            'notes': 'Close this fictional acceptance review with continued monitoring. The model remains illustrative; observations alone do not prove repair effectiveness.'})
        self.check('case-closes-with-review-replacement-and-follow-up-retained', case.get('status') == 'closed'
                   and case.get('closure', {}).get('disposition') == 'monitor' and case.get('review')
                   and len(case.get('follow_ups', [])) == 1 and bool(case.get('registry_events')))
        self.stage('checking-persistent-case-and-reproducible-export')
        current = retained_case(self.request('/api/cases/' + ident))
        exported = self.request('/api/cases/' + ident + '/export', binary=True)
        second_export = self.request('/api/cases/' + ident + '/export', binary=True)
        self.check('closed-case-and-export-repeat-exactly', current == retained_case(case) and exported == second_export
                   and ident.encode() in exported and asset.encode() in exported)
        self.check('export-retains-manual-and-replacement-identities', document_id.encode() in exported
                   and previous['serial'].encode() in exported and replacement['serial'].encode() in exported)
        fresh_write(self.export_path, exported)
        self.r.update(closed_case=current, closed_case_sha256=digest(canonical(current)),
                      case_export={'path': str(self.export_path), 'sha256': digest(exported), 'bytes': len(exported)},
                      original_capture_sha256=captured_hash, original_evidence_sha256=evidence_hash)
        self.save()
        fleet_closed = next(row for row in self.request('/api/fleet')['equipment'] if row['id'] == asset)
        self.check('closed-case-leaves-the-open-review-count', fleet_closed.get('open_cases') == 0)
        return records

    def restart_proof(self):
        self.stage('capturing-closed-case-before-authorized-app-only-restart')
        before = self.capture()
        ident = self.r['exercise_ids']['case_id']
        case_before = retained_case(self.request('/api/cases/' + ident))
        export_before = self.request('/api/cases/' + ident + '/export', binary=True)
        old_exports = self.case_exports(before['cases'])
        pid_before = command(['systemctl', 'show', SERVICE, '--property=MainPID', '--value']).strip()
        require(pid_before.isdigit() and int(pid_before) > 1 and UNIT.read_bytes() == self.unit_raw,
                'The service process or retained unit changed before restart preparation.')
        self.r.update(restart_count=1, service_restarts=True, restart_intent_at=now(), before_restart=before)
        self.save()
        command(['systemctl', 'restart', SERVICE], timeout=60)
        health_deadline = min(self.deadline, time.monotonic() + 45)
        health = None
        while time.monotonic() < health_deadline:
            try:
                with self.opener.open(ORIGIN + '/api/health', timeout=min(5, max(.1, health_deadline - time.monotonic()))) as response:
                    raw = response.read(onboarding.MAX_BODY + 1)
                require(len(raw) <= onboarding.MAX_BODY, 'Restart health response exceeded its bound.')
                candidate = json.loads(raw)
                if candidate.get('ok') is True and candidate.get('indexed_records') == 48:
                    health = candidate
                    break
            except Exception:
                pass
            time.sleep(min(1, max(0, health_deadline - time.monotonic())))
        self.check('app-only-restart-restores-48-record-health', health is not None)
        pid_after = command(['systemctl', 'show', SERVICE, '--property=MainPID', '--value']).strip()
        self.check('app-process-restarted-once', pid_after.isdigit() and int(pid_after) > 1 and pid_after != pid_before,
                   before_pid=pid_before, after_pid=pid_after)
        after = self.capture()
        self.r['after_restart'] = after
        self.check('all-durable-rows-and-schemas-survive-app-restart', preserve_case_additions(before['state'], after['state']))
        self.check('closed-case-and-export-survive-app-restart', retained_case(self.request('/api/cases/' + ident)) == case_before
                   and self.request('/api/cases/' + ident + '/export', binary=True) == export_before)
        self.check('all-earlier-case-export-bytes-survive-app-restart', self.case_exports(after['cases']) == old_exports)
        self.check('restart-preserves-kd-inventory-container-lifecycles-and-paused-mission', before['databases'] == after['databases']
                   and before['containers'] == after['containers'] and before['mission'] == after['mission'] and before['cases'] == after['cases'])
        self.check('restart-retains-service-unit-and-active-release', UNIT.read_bytes() == self.unit_raw
                   and command(['systemctl', 'show', SERVICE, '--property=WorkingDirectory', '--value']).strip() == str(self.release))
        self.r['service_restart_test'] = True
        self.save()

    def run(self):
        self.prepare()
        before = self.capture()
        before_exports = self.case_exports(before['cases'])
        self.r.update(before=before, existing_case_exports_before=before_exports)
        self.save()
        self.stage('checking-read-only-equipment-case-surfaces')
        self.readonly_checks()
        additions = self.exercise_workflow() if self.exercise else {}
        if self.exercise:
            for record in self.case_workflow():
                additions.setdefault(record['database'], []).append(record['reference'])
        if self.restart_demo_app:
            self.restart_proof()
        self.stage('verifying-existing-state-and-only-explicit-synthetic-additions')
        after = self.capture()
        new_ids = [self.r['exercise_ids']['case_id']] if self.exercise else []
        after_exports = self.case_exports(after['cases'])
        self.r.update(after=after, existing_case_exports_after=after_exports)
        self.check('all-pre-existing-durable-values-and-schemas-preserved', preserve_case_additions(before['state'], after['state'], new_ids))
        self.check('kd-references-match-only-explicit-import-additions', onboarding.preserved_databases(before['databases'], after['databases'], additions),
                   explicit_additions=additions)
        self.check('container-identities-and-start-times-unchanged', before['containers'] == after['containers'])
        before_mission = {key: value for key, value in before['mission'].items() if key != 'case_counts'}
        after_mission = {key: value for key, value in after['mission'].items() if key != 'case_counts'}
        self.check('existing-paused-mission-and-acquired-history-unchanged', before_mission == after_mission)
        self.check('all-existing-case-export-bytes-unchanged', all(after_exports.get(ident) == value for ident, value in before_exports.items())
                   and set(after_exports) == set(before_exports) | set(new_ids))
        self.check('existing-service-unit-remains-unchanged', UNIT.read_bytes() == self.unit_raw)
        self.r.update(complete=True, passed=True, completed_at=now(), persistent_records_retained=True,
                      service_restart_test=self.restart_demo_app)
        self.stage('equipment-cases-' + ('synthetic-exercise' if self.exercise else 'read-only') + '-accepted')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True, help='Fresh private JSON acceptance receipt.')
    parser.add_argument('--exercise', action='store_true', help='Create and retain a unique fictional maintenance case and its registry/import evidence.')
    parser.add_argument('--restart-demo-app', action='store_true', help='With --exercise, restart only the application once after closure and verify all saved state/exports.')
    parser.add_argument('--timeout', type=int, default=900, help='Bounded total runtime, 60–1200 seconds.')
    args = parser.parse_args()
    require(sys.platform == 'linux' and os.geteuid() == 0, 'Run the installed verifier as Linux root for protected state inspection.')
    require(60 <= args.timeout <= 1200, 'Timeout must be 60–1200 seconds.')
    require(not args.restart_demo_app or args.exercise, '--restart-demo-app requires --exercise.')
    return EquipmentCaseVerification(args.output, args.exercise, args.timeout, args.restart_demo_app).execute()


if __name__ == '__main__':
    raise SystemExit(main())
