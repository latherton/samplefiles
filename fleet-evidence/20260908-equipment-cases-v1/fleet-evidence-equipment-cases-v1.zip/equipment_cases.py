"""Equipment reviews using immutable imported observations and retained evidence.

Context reads historic verification receipts; capture actions recheck the exact
KD payload. No condition predictor is applied, including to synthetic imports.
Case detail and export read only captured state and remain usable without KD.
"""
import base64
from datetime import datetime, timezone
import hashlib
import html
import json

from case_store import field, now
from kd_client import KDError
from onboarding import DOCUMENTS_DATABASE, canonical, payload_hash
from telemetry import analyze_samples


MAX_DOCUMENTS = 8
MAX_ORIGINAL_BYTES = 4 * 1024 * 1024
IDENTITY_KEYS = ('id', 'name', 'model', 'configuration', 'kind', 'location', 'description', 'synthetic_demo', 'version')


def _copy(value):
    return json.loads(json.dumps(value, allow_nan=False))


def _hash(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


class EquipmentCaseService:
    def __init__(self, cases, registry, onboarding, client=None, corpus=None):
        self.cases, self.registry, self.onboarding = cases, registry, onboarding
        self.client, self.corpus = client, corpus

    @staticmethod
    def _identity(equipment):
        return {key: equipment.get(key) for key in IDENTITY_KEYS}

    @staticmethod
    def _ids(values):
        if not isinstance(values, list) or len(values) > MAX_DOCUMENTS or any(not isinstance(v, str) or not v or len(v) > 100 for v in values):
            raise ValueError('Choose at most eight registered document IDs.')
        if len(set(values)) != len(values):
            raise ValueError('Document IDs must be unique.')
        return values

    def _case(self, ident, data=None):
        case = self.cases.get(ident)
        if case.get('workflow') != 'equipment_imports':
            raise ValueError('This action requires an imported-equipment case.')
        if data is not None:
            if case['status'] == 'closed':
                raise ValueError('This case is closed. Its captured history remains available.')
            self.cases._check_version(case, data.get('version'))
        return case

    def _receipt(self, import_id, reference):
        receipt = self.onboarding.receipt(import_id)
        jobs = [job for job in receipt['jobs'] if job['action'] == 'DREADDDATA' and job['reference'] == reference]
        if len(jobs) != 1 or jobs[0]['status'] != 'verified' or not jobs[0]['verified_at']:
            raise ValueError('The selected import must have one exactly verified KD payload receipt.')
        # The complete source rows remain in onboarding storage. The case holds
        # the selected immutable payload, counts and its exact native job receipt.
        retained = {key: receipt.get(key) for key in ('import_id', 'kind', 'source_id', 'filename', 'status',
                    'created_at', 'updated_at', 'accepted_count', 'rejected_count', 'duplicate_count', 'verified_count', 'original_sha256')}
        retained['jobs'] = _copy(jobs)
        retained['receipt_sha256'] = _hash(retained)
        return retained

    def _verify(self, receipt, payload):
        if self.client is None:
            raise KDError('A KD connection is required to verify newly captured evidence.', 'equipment_case_verification_required')
        job = dict(receipt['jobs'][0], import_id=receipt['import_id'], payload=canonical(payload))
        if not self.onboarding._readback(self.client, job):
            raise KDError('The selected import no longer matches exact KD readback. Refresh and reconcile its evidence before capture.', 'equipment_case_readback_mismatch')
        return now()

    def _snapshot(self, equipment, source_id, live=False):
        source = self.onboarding.source(source_id)
        window = self.onboarding.verified_snapshot(source_id, equipment['id'])
        payload = {key: window[key] for key in ('schema', 'source_id', 'asset_id', 'synthetic', 'samples')}
        if window['asset_id'] != equipment['id'] or window['source_id'] != source_id:
            raise ValueError('The verified reading window belongs to another equipment or source.')
        provenance = _copy(window['provenance'])
        if provenance['payload_sha256'] != payload_hash(payload):
            raise ValueError('The retained reading payload does not match its verification hash.')
        receipt = self._receipt(provenance['import_id'], provenance['reference'])
        if live:
            provenance.update(live=True, live_verified_at=self._verify(receipt, payload))
        identity = self._identity(equipment)
        observed = window['samples'][-1]['timestamp']
        age = max(0, (datetime.now(timezone.utc) - datetime.fromisoformat(observed.replace('Z', '+00:00'))).total_seconds())
        analysis = analyze_samples(window['samples'], synthetic=False)
        origin = 'Synthetic' if window['synthetic'] else 'Source-reported'
        if analysis['status'] == 'observed':
            analysis.update(title='Imported observations captured',
                            summary=origin + ' measurements are captured for a human maintenance review. No predictive equipment model is applied.')
        else:
            analysis['summary'] += ' ' + origin + ' observations are retained without a predictive equipment model.'
        analysis['forecast']['reason'] = 'No predictive model is applied to imported equipment observations.'
        snapshot = dict(asset_id=equipment['id'], equipment_identity=identity, synthetic=window['synthetic'],
                        observed_at=observed, samples=_copy(window['samples']), analysis=analysis,
                        source=dict(mode='import', label=source_id, display_label=source['label'],
                                    through_kd=True, synthetic=window['synthetic'], provenance=provenance,
                                    stale=age > source['expected_interval_seconds'] * 2,
                                    expected_interval_seconds=source['expected_interval_seconds']),
                        import_receipt=receipt, source_configuration={key: source.get(key) for key in
                            ('source_id', 'label', 'kind', 'endpoint', 'synthetic', 'mapping', 'units', 'expected_interval_seconds')},
                        evidence_boundary='Imported source origin is recorded separately from equipment identity. Retention, review and later improvement do not establish failure prediction, document authority or repair causality.')
        snapshot['snapshot_id'] = _hash(dict(payload=payload, equipment_identity={key: identity[key] for key in ('id', 'model', 'configuration')}))
        return snapshot

    def _replacement_events(self, equipment):
        components = {item['id']: item for item in equipment.get('components', [])}
        return [dict(event, previous_component=_copy(components.get(event.get('previous_component_id'))),
                     installed_component=_copy(components.get(event.get('component_id'))))
                for event in equipment.get('history', []) if event['type'] == 'component_replaced']

    def context(self, asset_id, source_id=None):
        equipment = self.registry.get_equipment(asset_id)
        source_ids = {row['source_id'] for row in self.onboarding.latest_readings(equipment['id'])}
        sources = []
        for source in self.onboarding.sources():
            if source['source_id'] not in source_ids:
                continue
            try:
                snapshot = self._snapshot(equipment, source['source_id'])
                error = None
            except (ValueError, KeyError) as exc:
                snapshot, error = None, str(exc)
            sources.append(dict(source, snapshot=snapshot, snapshot_error=error))
        documents = []
        for document in self.onboarding.documents(equipment['id']):
            applies = equipment['id'] in document.get('applicable_asset_ids', [])
            verified = document['indexing_status'] == 'verified'
            documents.append(dict(document, eligible=applies and verified,
                                  reason='Applicable retained revision with verified KD delivery.' if applies and verified else
                                  'Equipment identity differs from this retained revision.' if not applies else 'KD delivery is not yet verified.'))
        selected = next((row['snapshot'] for row in sources if row['source_id'] == source_id), None)
        return dict(equipment=equipment, sources=sources, snapshot=selected, documents=documents,
                    replacement_events=self._replacement_events(equipment),
                    boundary='Context shows retained verification. Capturing readings or new evidence rechecks exact KD payloads; the equipment model remains observation-only.')

    def _selected_snapshot(self, data, equipment):
        snapshot_id = data.get('snapshot_id')
        if not isinstance(snapshot_id, str) or len(snapshot_id) != 64:
            raise ValueError('Select a verified snapshot from the equipment context before capturing it.')
        snapshot = self._snapshot(equipment, data.get('source_id'), live=False)
        if snapshot['snapshot_id'] != snapshot_id:
            raise ValueError('The selected observation or equipment identity changed. Refresh before capturing it.')
        payload = dict(schema='fleet.sensor.v1', source_id=snapshot['source']['label'], asset_id=snapshot['asset_id'],
                       synthetic=snapshot['synthetic'], samples=snapshot['samples'])
        stamp = self._verify(snapshot['import_receipt'], payload)
        snapshot['source']['provenance'].update(live=True, live_verified_at=stamp)
        return snapshot

    def _evidence(self, document_ids, equipment):
        records, total = [], 0
        for document_id in self._ids(document_ids):
            document = self.onboarding.document(document_id)
            if equipment['id'] not in document.get('applicable_asset_ids', []):
                raise ValueError('Every selected document must match the current equipment model and configuration.')
            if document['indexing_status'] != 'verified':
                raise ValueError('Every selected document must have verified KD delivery.')
            original_receipt = self.onboarding.receipt(document['import_id'])
            metadata = original_receipt['metadata']
            reference = 'urn:fleet-import-document:' + document_id
            receipt = self._receipt(document['import_id'], reference)
            filename, original = self.onboarding.original(document_id)
            if hashlib.sha256(original).hexdigest() != document['original_sha256']:
                raise ValueError('The retained document original does not match its recorded hash.')
            total += len(original)
            if total > MAX_ORIGINAL_BYTES:
                raise ValueError('Selected evidence originals exceed the four MiB case capture limit.')
            payload = dict(schema='fleet.import.document.v1', document_id=document_id, metadata=metadata,
                           text=document['text'], original_sha256=document['original_sha256'])
            verified = self._verify(receipt, payload)
            records.append(dict(id=document_id, document_id=document_id, title=document['title'], revision=document['revision'],
                                kind=document['document_type'], status='unreviewed', asset_id=equipment['id'],
                                equipment_model=equipment['model'], configuration=equipment['configuration'], reference=reference,
                                summary=document['text'][:500], text=document['text'], metadata=_copy(metadata), receipt=receipt,
                                original_sha256=document['original_sha256'],
                                original=dict(filename=filename, encoding='base64', data=base64.b64encode(original).decode()),
                                provenance=dict(database=DOCUMENTS_DATABASE, reference=reference, payload_sha256=payload_hash(payload),
                                                verified_at=receipt['jobs'][0]['verified_at'], live_verified_at=verified,
                                                retained_verified_readback=True, live=True),
                                sections=[dict(id='retained-text', title='Retained source text', text=document['text'])]))
        return records

    def create(self, data):
        equipment = self.registry.get_equipment(data.get('asset_id'))
        snapshot = self._selected_snapshot(data, equipment)
        records = self._evidence(data.get('document_ids', []), equipment)
        # Repeated capture of this exact source/identity/window is idempotent.
        episode = 'equipment-import:' + equipment['id'] + ':' + snapshot['source']['label'] + ':' + snapshot['snapshot_id']
        return self.cases.capture(snapshot, records, data.get('notes', ''), data.get('title', ''), episode,
                                  equipment_identity=self._identity(equipment))

    def detail(self, ident):
        case = self._case(ident)
        try:
            equipment = self.registry.get_equipment(case['asset_id'])
            if any(equipment[key] != case['equipment_identity'][key] for key in ('id', 'model', 'configuration')):
                raise ValueError('Equipment identity changed; the captured case retains its original configuration.')
            latest, error = self._snapshot(equipment, case['source_id']), None
        except (ValueError, KeyError, KDError) as exc:
            latest, error = None, str(exc)
        return dict(case, latest=latest, latest_error=error)

    def action(self, ident, action, data):
        case = self._case(ident, data)
        version = data['version']
        if action == 'close':
            return self.cases.close(ident, data, expected_version=version)
        if action in {'maintenance-event', 'link-replacement'}:
            equipment = self.registry.get_equipment(case['asset_id'])
            selected = next((event for event in self._replacement_events(equipment) if event['id'] == data.get('event_id')), None)
            if selected is None:
                raise ValueError('Choose an existing replacement event for this equipment.')
            previous = selected.pop('previous_component')
            installed = selected.pop('installed_component')
            if previous is None or installed is None:
                raise ValueError('The replacement event must retain both installed-item records.')
            attachment = dict(id=selected['id'], event=selected, previous_component=previous, installed_component=installed,
                              notes=field(data.get('notes', ''), 'Maintenance event notes'), captured_at=now())
            return self.cases.capture_registry_event(ident, attachment, expected_version=version)
        equipment = self.registry.get_equipment(case['asset_id'])
        if any(equipment[key] != case['equipment_identity'][key] for key in ('id', 'model', 'configuration')):
            raise ValueError('Equipment identity changed. Start a new case for the new configuration.')
        if action == 'review':
            new_ids = self._ids(data.get('document_ids', []))
            if len({r['id'] for r in case['evidence']} | set(new_ids)) > MAX_DOCUMENTS:
                raise ValueError('A case can retain at most eight evidence documents.')
            records = self._evidence(new_ids, equipment)
            total = sum(len(base64.b64decode(r['original']['data'])) for r in case['evidence'])
            total += sum(len(base64.b64decode(r['original']['data'])) for r in records if r['id'] not in {e['id'] for e in case['evidence']})
            if total > MAX_ORIGINAL_BYTES:
                raise ValueError('Case evidence originals exceed the four MiB retention limit.')
            return self.cases.review(ident, data, records, expected_version=version)
        if action == 'follow-up':
            if data.get('source_id') != case['source_id']:
                raise ValueError('Follow-up must use the same equipment and source as this case.')
            snapshot = self._selected_snapshot(data, equipment)
            return self.cases.follow_up(ident, snapshot, data.get('notes', ''), expected_version=version)
        raise ValueError('Choose review, maintenance-event, follow-up or close.')

    def export(self, ident):
        case = self._case(ident)
        escape = lambda value: html.escape(str(value if value is not None else ''))
        def observations(snapshot, title):
            source = snapshot['source']
            provenance = source['provenance']
            body = '<section><h2>' + escape(title) + '</h2><p>Observation-only; source ' + escape(source['label'])
            body += ' · ' + ('Synthetic measurements' if snapshot['synthetic'] else 'Source-reported measurements') + '</p>'
            body += '<p>Observed through ' + escape(snapshot['observed_at']) + '; original import verified ' + escape(provenance['verified_at'])
            body += '; exact KD recheck at capture ' + escape(provenance.get('live_verified_at')) + '.</p>'
            body += '<p>Reference: ' + escape(provenance['reference']) + '<br>Payload SHA-256: ' + escape(provenance['payload_sha256'])
            body += '<br>Snapshot SHA-256: ' + escape(snapshot['snapshot_id']) + '</p><table><thead><tr>'
            fields = [('timestamp', 'UTC observation'), ('quality', 'Quality'), ('vibration_mm_s', 'Vibration mm/s'),
                      ('temperature_c', 'Temperature C'), ('pressure_bar', 'Pressure bar'), ('rpm', 'RPM'), ('load_pct', 'Load %')]
            body += ''.join('<th>' + label + '</th>' for _, label in fields) + '</tr></thead><tbody>'
            body += ''.join('<tr>' + ''.join('<td>' + escape(row[key]) + '</td>' for key, _ in fields) + '</tr>' for row in snapshot['samples'])
            return body + '</tbody></table></section>'
        equipment = case['equipment_identity']
        output = '<!doctype html><html lang="en"><meta charset="utf-8"><title>' + escape(case['title']) + '</title>'
        output += '<style>body{font:14px system-ui,sans-serif;max-width:1080px;margin:36px auto;color:#142b3a;padding:0 20px}h1,h2{color:#153c53}section{margin:28px 0;padding-top:16px;border-top:1px solid #ccd6dd}table{border-collapse:collapse;width:100%;font-size:12px}th,td{text-align:left;border:1px solid #ccd6dd;padding:6px}pre{white-space:pre-wrap;overflow-wrap:anywhere}p{overflow-wrap:anywhere}.note{background:#f1f5f7;padding:14px}@media print{body{margin:0}tr{break-inside:avoid}}</style><body>'
        output += '<h1>' + escape(case['title']) + '</h1><p>Equipment review ' + escape(case['id']) + ' · ' + escape(case['status']) + ' · revision ' + str(case['version']) + '</p>'
        output += '<p class="note">Retained observations and a human review. No predictive model, approved maintenance instruction, failure probability or proof of repair effectiveness is established. This export reflects captured state; it does not requery KD or assert current source availability.</p>'
        output += '<h2>Captured equipment identity</h2><p>' + escape(equipment['id']) + ' · ' + escape(equipment['name']) + '<br>Model ' + escape(equipment['model']) + ' · configuration ' + escape(equipment['configuration']) + '<br>' + escape(equipment.get('location')) + '</p>'
        output += '<p>' + ('Fictional demonstration equipment.' if equipment.get('synthetic_demo') else 'User-registered equipment identity; operational authority is not established.') + '</p><pre>' + escape(case['notes']) + '</pre>'
        output += observations(case['captured'], 'Opening observations')
        output += '<section><h2>Review and disposition</h2>'
        review = case.get('review')
        if review:
            output += '<h3>Human review</h3><p><strong>Reviewer role:</strong> ' + escape(review['reviewer_role']) + '<br><strong>Recorded:</strong> ' + escape(review['at']) + '</p>'
            for key, label in [('findings', 'Inspection findings'), ('action', 'Reviewed action'), ('notes', 'Review notes')]:
                if review.get(key):
                    output += '<h3>' + label + '</h3><pre>' + escape(review[key]) + '</pre>'
        else:
            output += '<p>A human review has not yet been recorded.</p>'
        closure = case.get('closure')
        if closure:
            output += '<h3>Disposition: ' + escape(closure['disposition'].capitalize()) + '</h3><p><strong>Recorded:</strong> ' + escape(closure['at']) + '</p><h3>Disposition rationale</h3><pre>' + escape(closure['notes']) + '</pre>'
        else:
            output += '<h3>Disposition</h3><p>This case remains open; no closing disposition has been recorded.</p>'
        output += '</section>'
        for record in case['evidence']:
            output += '<section><h2>' + escape(record['title']) + '</h2><p>Revision ' + escape(record['revision']) + ' · Authority unreviewed · ' + escape(record['equipment_model']) + ' / ' + escape(record['configuration']) + '</p>'
            output += '<p>Original SHA-256: ' + escape(record['original_sha256']) + '<br>Reference: ' + escape(record['reference']) + '<br>Exact KD recheck at capture: ' + escape(record['provenance']['live_verified_at']) + '</p><pre>' + escape(record['text']) + '</pre></section>'
        for attachment in case.get('registry_events', []):
            output += '<section><h2>Captured replacement event</h2><p>' + escape(attachment['event']['id']) + ' · event ' + escape(attachment['event']['at']) + ' · captured ' + escape(attachment['captured_at']) + '</p>'
            for component, label in [(attachment['previous_component'], 'Previous installed item'), (attachment['installed_component'], 'Replacement installed item')]:
                part = component['part_snapshot']
                output += '<h3>' + label + '</h3><p><strong>Catalog part:</strong> ' + escape(component['part_id']) + ' · ' + escape(part['name'])
                output += '<br><strong>Manufacturer / part number:</strong> ' + escape(part['manufacturer']) + ' / ' + escape(part['part_number'])
                output += '<br><strong>Component / serial:</strong> ' + escape(component['id']) + ' / ' + escape(component['serial'] or 'Not recorded')
                output += '<br><strong>Installed:</strong> ' + escape(component['installed_at']) + '<br><strong>Removed:</strong> ' + escape(component.get('removed_at') or 'No removal recorded at capture') + '</p>'
            if attachment['notes']:
                output += '<h3>Captured maintenance notes</h3><pre>' + escape(attachment['notes']) + '</pre>'
            output += '</section>'
        for followup in case['follow_ups']:
            output += observations(followup['condition'], 'Follow-up observations') + '<pre>' + escape(followup['notes']) + '</pre>'
        output += '<section><h2>Retained timeline</h2><ol>' + ''.join('<li><strong>' + escape(e['title']) + '</strong> · ' + escape(e['at']) + '<pre>' + escape(e['detail']) + '</pre></li>' for e in case['timeline']) + '</ol></section>'
        # Escaped JSON is inert even if an uploaded original contains HTML or
        # script text. It contains original bytes as base64 for durable recovery.
        output += '<details><summary>Captured record, receipts and original evidence bytes (JSON)</summary><pre>' + escape(json.dumps(case, ensure_ascii=False, sort_keys=True, indent=2)) + '</pre></details></body></html>'
        return output.encode('utf-8')
