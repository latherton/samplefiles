# Fleet Evidence: a maintenance review for newly registered equipment

This guide describes the imported-equipment case workflow. Consult the [dated build record](../../docs/equipment-case-workflow-build-2026-09-08.md) for actual acceptance and deployment status. All material below is fictional training content; the recorded measurements have no calibrated equipment condition model.

## Prepare the retained starting point

Use **Equipment & parts** to register a unique fictional pump, for example `CASE-19`, model `TRAIN-PUMP`, configuration `C`. Add an explicitly applicable catalog part, install serial `TRAIN-OLD` with installation date `2019-12-01`, and record three spare items separately. Installation and replacement do not automatically change spare quantities.

Save CSV source `case19-training` with **Synthetic readings** checked. Use the existing normalized mapping and units. Upload the first CSV below, inspect accepted/rejected/duplicate rows, and wait for the receipt to say **Verified**. Upload a short manual with type **Manual**, revision `TRAIN-R1`, and applicability to `CASE-19`; verify its receipt too. A suitable text is: “Fictional training reference for CASE-19, model TRAIN-PUMP configuration C. Record identity, inspection observations and uncertainty. This text provides no operational limits or approved repair procedure.”

These dates are deliberately historical. A recent upload and verified delivery must not make them appear current. Use a new equipment and source identity for repeated rehearsals rather than resetting retained records.

```csv
asset_id,timestamp,quality,vibration_mm_s,temperature_c,pressure_bar,rpm,load_pct
CASE-19,2020-01-01T00:00:00Z,good,4.1,56,4.1,1780,66
CASE-19,2020-01-01T00:01:00Z,good,4.2,57,4.1,1781,66
```

## Run the review

1. In the pump's registry detail, choose **Open maintenance case**. Select `case19-training`, inspect the retained opening window and select the eligible manual. Give the case a concrete review question, then save. The save rechecks the exact selected reading and document payloads through KD. Opening observations remain fixed after later imports.
2. In **Maintenance cases**, show the shared equipment filter and the new case. Show equipment identity, historical observation dates, original import verification and the separate capture recheck time. Open **Read captured source & original**. Its text, revision and original bytes belong to the saved case; later uploads do not replace that capture.
3. Record a demonstration reviewer role, a finding such as “The training readings warrant an inspection review; no failure conclusion is established,” and a reviewed action. Save the review. A role label is not authenticated identity or maintenance authority. A review requires at least one verified source document retained with the case.
4. Choose **Record a replacement in registry**. Replace `TRAIN-OLD` with `TRAIN-NEW`, using replacement date `2020-01-02` and an explicit fictional maintenance note. Return through **View maintenance cases**, open the case, select the recorded replacement and choose **Attach retained event**. Inspect both serials and their installation/removal dates. The maintenance event time and case attachment time are different facts. Update spare stock separately only if the demonstration records a stock change.
5. Choose **Import later readings** and upload the second CSV below under the same source. Use a separate file containing only observations after the opening window and replacement event. Complete KD verification, return to the case and select **Refresh latest import**. Record uncertainty and choose **Capture later verified observations**. Every row must be later than the previous captured window and any attached maintenance event.
6. Show the preserved opening observations beside the latest retained import and expand the saved follow-up. The lower fictional values are observations, not evidence that a repair caused improvement. Record **Continue monitoring** or another supported disposition with its basis, then **Record outcome & close**.
7. Use **Export case brief** and inspect the downloaded HTML. Reopen the case after a refresh. A controlled offline/restart acceptance run should separately verify retained case data, document text/original hash, replacement history, follow-up and export; do not claim those checks solely because the page refreshed.

```csv
asset_id,timestamp,quality,vibration_mm_s,temperature_c,pressure_bar,rpm,load_pct
CASE-19,2020-01-03T00:00:00Z,good,2.1,53,4.2,1780,65
CASE-19,2020-01-03T00:01:00Z,good,2.2,53,4.2,1781,65
```

## Explain the boundaries

Both imported-equipment and original pump cases use the same retained case store. The original A-17/A-18 Mission Control flow remains available; **Original pump scenario case** in the create dialog opens its existing path. Imported equipment gets an observation-only review, with no illustrative failure score, readiness score, remaining-life estimate or automatic maintenance instruction.

Candidate previews and saved details use retained verified readback. Capturing a reading window or newly selected document requires an exact live KD recheck; a current outage blocks that capture rather than substituting unverified data. Retained detail, captured source content, export and local case history remain readable offline. Registry-event attachment and closure operate on retained records. A later equipment model/configuration change does not redefine the original case; new observation/document captures require the matching identity.

The case detects stale versions and preserves a visible draft when background refresh notices another saved revision. Refresh the case before retrying a rejected save; do not treat a timeout as proof that nothing was saved. The UI timestamps include the year and UTC so historical readings cannot be mistaken for current observations.

This workflow does not establish document authority, user authentication, approved maintenance execution, repair causality or predictive accuracy. API/historian acquisition adapters and independent real-history prediction evidence remain separate unfinished product capabilities described in the onboarding guide.
