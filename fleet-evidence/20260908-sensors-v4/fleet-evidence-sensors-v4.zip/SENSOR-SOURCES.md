# Sensor source bridge

Prepared September 8, 2026. This source adapter is an application extension. The staged deployments reached the installed Content 26.1 index: database creation job 44 completed, but add jobs 45 and 46 each reported pending-cache status `-34` with `documents_processed=0` and ultimately completed with zero processed/deleted documents. Job 46 included an explicit `/DOCUMENT` delimiter, so that parameter alone did not resolve the issue. The count checks stopped both attempts before the application switch; no explicit cache commit was sent, and the original databases and container lifecycles were unchanged. Both receipts/jobs are retained for inspection. The current configuration-matched XML envelope is locally tested; its live indexing/readback and remote browser acceptance remain pending. No real device or NiFi acquisition feed has been connected.

`sensor_kd.py` reads normalized snapshots through the existing `KDClient` connection. The default database is `FLEET_SENSOR_DEMO`; `KD_SENSOR_DATABASE` can select another dedicated uppercase database name. `Default`, `Archive` and `FLEET_EVIDENCE_DEMO` are prohibited. The 48-record evidence corpus and its manifest/hash rules remain separate. No existing controller service, connector, registry connection, source manifest or remote configuration is changed.

## Contract and origin

[sensor-contract.json](sensor-contract.json) is our application contract, `fleet.sensor.v1`. Every document contains `FE_SENSOR_SCHEMA`, `FE_SENSOR_SOURCE_ID`, `FE_SENSOR_ASSET_ID`, `FE_SENSOR_SYNTHETIC` and `FE_SENSOR_PAYLOAD`. The optional `FE_SENSOR_SHA256` field is emitted by the CLI and checked when present. IDs, origin, reference and payload must agree. Canonical JSON uses sorted keys, compact separators, ASCII escaping and no non-finite constants.

Use stable reference `urn:fleet-sensor:<source_id>:<asset_id>`. A source ID has 1–64 lowercase letters, digits, underscores or hyphens and begins with a letter. Initially only A-17/A-18 are supported. Each complete snapshot holds 1–181 samples in strictly increasing UTC ISO 8601 event time, including seconds and ending in `Z`. There is no truncation, interpolation, inferred identity or unit conversion in the reader. Missing values remain `null`, never zero. Good quality requires all five metrics. Suspect/missing quality must remain visible downstream.

| Field | Fixed normalized unit / meaning |
| --- | --- |
| `vibration_mm_s` | Vibration velocity RMS, millimeters per second |
| `temperature_c` | Degrees Celsius |
| `pressure_bar` | Gauge pressure, bar |
| `rpm` | Shaft revolutions per minute |
| `load_pct` | Percent of a stated rated-load basis |

An upstream adapter must document the sensor location, vibration processing, gauge-pressure conversion and load basis. V1 does not encode those installation-specific definitions; incompatible measurements must not be presented as comparable. Runtime values must be finite JSON numbers or null; booleans are rejected. The contract defines transport and units, not equipment operating limits or validated predictive thresholds.

`synthetic:true` remains synthetic even after KD indexing. `synthetic:false` means the configured producer identifies the measurements as real; it is not independent sensor authentication or proof of customer authorization. The live label establishes a fresh KD retrieval, not that the samples are current or directly streamed. Event timestamps and retrieved-at timestamps are separate. Source readiness/staleness evaluation belongs to the telemetry layer.

`SensorKD(client).sources()` returns a bounded source inventory and connection label. `.snapshot(source_id, asset_id)` selects the latest complete snapshot by final sample time and adds provenance (database, exact reference, source/asset/origin, retrieved-at, last event time, sample count and payload hash). More than 1,000 returned documents, a mismatching total count, malformed records, wrong-database hits, mixed synthetic/real labels for one source, or conflicting latest timestamps fail visibly. There is no simulation fallback. `record_count` counts indexed snapshot documents; `sample_count` counts measurements.

## Local preparation and explicit indexing

```powershell
python sensor_ingest.py --input C:\path\snapshot.json --dry-run
```

Dry-run makes no KD connection. It emits a `.sensor.idx` companion for human inspection, an exact `.sensor.xml` request body, and `.sensor-receipt.json`. The JSON payload includes quotation marks, and official IDX guidance does not establish an embedded-quote escaping rule. The CLI therefore submits the documented XML form of DREADDDATA with `DocumentFormat=XML`; XML serialization preserves the JSON string without assuming IDX escaping. The IDX companion is not the submitted artifact and has not been validated for live indexing. The receipt identifies the exact XML format and SHA-256. Preserve it with the input.

The current XML artifact is `<DOCUMENTS><DOCUMENT>…</DOCUMENT></DOCUMENTS>`, containing exactly one document. Actual runtime configuration in `/content/cfg/original.content.cfg`, inherited by the active configuration, sets `DocumentDelimiterCSVs=*/DOCUMENT` and `XMLTopLevelExportField=DOCUMENTS`. The add request now uses `DocumentDelimiters=*/DOCUMENT`, agreeing with that configured non-root document boundary rather than relying on the unsuccessful root-level override. The export setting is consistent with the wrapper but does not itself validate import behavior. Metadata, JSON and hashes remain inside the single `DOCUMENT`; existing wildcard reference/index field rules still match their nested paths. This is a configuration-driven candidate awaiting native readback, not a confirmed diagnosis of the previous zero-document jobs. Both pending-cache and completed jobs must still report exactly one processed document.

New dry-run and apply receipts record `document_delimiters: */DOCUMENT`; resume identity checks require that exact field as well as the payload, XML body, database and connection identity. The wrapper changes the body hash. Old receipts without a delimiter, or with `/DOCUMENT`, are rejected without polling or mutation. The failed v2/v3 receipts must remain retained; this request must not be passed off as a resume of either incompatible job.

```powershell
python sensor_ingest.py --input C:\path\snapshot.json --apply
python sensor_ingest.py --input C:\path\snapshot.json --resume
```

`--apply` is the explicit write step and uses the existing `KD_CONTENT_URL` / `KD_INDEX_URL` resolution. It may create the configured sensor database, then replaces only the stable source/asset reference with `KillDuplicates=REFERENCE`, `KillDuplicatesMatchTargetDB=True` and `KillDuplicatesMatchDBs=<sensor database>`. No delete-database, truncation, replay of existing ingestion or device-control operation exists. Identical stored snapshots are no-ops. Older snapshots and different snapshots with equal final event times are rejected. Each request intent is saved before submission, followed by its exact native `INDEXID`; completion is checked against that original job and followed by full payload readback through the reader. The receipt binds to the snapshot, database and connection hash.

There is no automatic retry of a write whose outcome or receipt is uncertain. An incomplete receipt requires `--resume`; resuming polls its known jobs and does not replay the request. A completed index job whose readback differs fails rather than resubmitting. Use one writer per source/asset; receipt-file locks do not provide a distributed KD compare-and-swap guarantee. Independent writers can race, so a deployment must serialize updates upstream. The stable-reference contract retains the latest snapshot, not an audit/history time-series database.

If an original job reports pending-cache status `-34`, the default stops with its receipt intact. `DRESYNC` flushes all pending Content cache, including unrelated pending data; it is not database-scoped. If that effect is expressly wanted, use `--resume --allow-sync`. The CLI then journals one sync request and continues polling the original job. It never recreates services. This is opt-in because the sensor database's isolation does not isolate Content's pending cache.

## Proposed NiFi route

A source-specific producer obtains readings from an approved file/export, historian API or gateway. That producer normalizes event time and units, maps verified asset identity, preserves quality, builds a bounded rolling snapshot, and sets the origin flag. Its document mapping places the exact payload and metadata above into an IDOL document with the stable reference. A separately configured NiFi path can submit that document through `PutIDOL` to the dedicated sensor database. Check its batching, destination and duplicate-handling behavior against the installed processor build and verify the complete payload readback before claiming integration.

`PutIDOL` is the documented indexing processor. The source-specific acquisition and normalization, rolling-window assembly and identity mapping remain integration work. This repository does not implement Modbus, OPC UA, MQTT, shipboard network access, a historian connector or writes to equipment. NiFi documentation cached here is 26.3; compatibility of this proposed mapping with the observed 26.1 deployment remains unverified.

## Sources and verification

Native request behavior was checked against official Content 26.1 documentation: [DREADDDATA](https://www.microfocus.com/documentation/idol/knowledge-discovery-26.1/Content_26.1_Documentation/Help/Content/Index%20Actions/IndexData/_IX_DREADDDATA.htm), [DocumentFormat](https://www.microfocus.com/documentation/idol/knowledge-discovery-26.1/Content_26.1_Documentation/Help/Content/Index%20Actions/IndexData/Parameters/_IX_DocumentFormat.htm), [KillDuplicates](https://www.microfocus.com/documentation/idol/knowledge-discovery-26.1/Content_26.1_Documentation/Help/Content/Index%20Actions/IndexData/Parameters/_IX_KillDuplicates.htm), [KillDuplicatesMatchTargetDB](https://www.microfocus.com/documentation/idol/knowledge-discovery-26.1/Content_26.1_Documentation/Help/Content/Index%20Actions/IndexData/Parameters/_IX_KillDuplicatesMatchTarge.htm), and [KillDuplicatesMatchDBs](https://www.microfocus.com/documentation/idol/knowledge-discovery-26.1/Content_26.1_Documentation/Help/Content/Index%20Actions/IndexData/Parameters/_IX_KillDuplicatesMatchDBs.htm).

The correction was checked against the exact 26.1 [DocumentDelimiters action parameter](https://www.microfocus.com/documentation/idol/knowledge-discovery-26.1/Content_26.1_Documentation/Help/Content/Index%20Actions/IndexData/Parameters/_IX_DocumentDelimiters.htm) and [DocumentDelimiterCSVs configuration default](https://www.microfocus.com/documentation/idol/knowledge-discovery-26.1/Content_26.1_Documentation/Help/Content/Configuration/Server/_IX_DocumentDelimiterCSVs.htm), fetched September 8. The action parameter accepts `/FieldName` for root fields and `*/FieldName` for non-root fields; an unqualified action-parameter field name is expanded to `*/FieldName`. No `DocRoot` or `DocId` parameter is needed for this documented boundary selection.

The cached 26.3 [DRESYNC](../../.research/vendor-docs/Content/Help/Content/Index%20Actions/AdministerIndex/_IX_DRESYNC.htm), [IDX Format](../../.research/vendor-docs/Content/Help/Content/Appendixes/IDX/IDX_Format.htm), and [PutIDOL](../../.research/vendor-docs/NiFiIngest/Help/Content/Reference/Processors/PutIDOL.htm) pages were also consulted. Existing `index_corpus.py` supplies the proven receipt/lock pattern; this adapter does not call its evidence-database index method.

Run `python -m unittest discover -s tests -p test_sensor_kd.py -v` from this directory. These offline tests exercise real parsing and serialization plus controlled native index responses. They cannot establish installed-engine field preservation, remote write permission, real-feed delivery or sensor accuracy.
