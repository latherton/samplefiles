/* Equipment telemetry replay and the explicit KD source boundary. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const icon = (path) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${path}"/></svg>`;
  const arrow = icon('M4 12h16M14 6l6 6-6 6');
  const signal = icon('M2 12h5l3-8 4 16 3-8h5');
  const scenarios = {degradation:'Persistent change',normal:'Steady operation',load_change:'Load change',sensor_gap:'Missing readings'};
  const channels = {
    vibration_mm_s:{label:'Vibration',unit:'mm/s',color:'#208979',decimals:2},
    temperature_c:{label:'Temperature',unit:'°C',color:'#be8435',decimals:1},
    pressure_bar:{label:'Pressure',unit:'bar',color:'#547da5',decimals:2}
  };
  const storageKey = 'fleet-evidence.telemetry.v1';
  let stored = {};
  try { stored = JSON.parse(localStorage.getItem(storageKey) || '{}') || {}; } catch (_) { /* Session still works without storage. */ }
  const state = {
    mode:stored.mode === 'kd' ? 'kd' : 'simulation', sourceId:typeof stored.sourceId === 'string' ? stored.sourceId : '',
    scenario:'degradation',step:80,channel:'vibration_mm_s',playing:false,loading:false,error:'',data:null,
    serial:0,sourceSerial:0,sources:null,sourcesLoading:false,testing:false
  };
  let timer, sliderTimer, controller;
  const assetId = () => window.FleetEvidence.getAssetId();
  const descriptor = () => ({mode:state.mode,source_id:state.sourceId,scenario:state.data?.scenario || state.scenario,step:state.data?.step ?? state.step,asset_id:assetId(),snapshot_id:state.data?.snapshot_id});
  function save() { try { localStorage.setItem(storageKey,JSON.stringify({mode:state.mode,sourceId:state.sourceId,sourceDraft:$('kdSourceId')?.value || state.sourceId})); } catch (_) { /* No persistent storage. */ } }
  const number = (value,digits=1) => typeof value === 'number' && Number.isFinite(value) ? value.toLocaleString('en-US',{minimumFractionDigits:digits,maximumFractionDigits:digits}) : '—';
  function date(value,compact=false) {
    const parsed = new Date(value);
    if (!value || !Number.isFinite(parsed.getTime())) return 'Time unavailable';
    return new Intl.DateTimeFormat('en-US',compact ? {hour:'2-digit',minute:'2-digit',hour12:false,timeZone:'UTC'} : {month:'short',day:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false,timeZone:'UTC'}).format(parsed) + (compact ? '' : ' UTC');
  }
  async function api(url,signal) {
    const abort = new AbortController();
    const forward = () => abort.abort();
    signal?.addEventListener('abort',forward,{once:true});
    if (signal?.aborted) abort.abort();
    const timeout = setTimeout(() => abort.abort(),28000);
    try {
      const response = await fetch(url,{credentials:'same-origin',cache:'no-store',signal:abort.signal});
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || data.error || 'The sensor source could not be read.');
      return data;
    } catch(error) {
      if (error.name === 'AbortError' && !signal?.aborted) throw new Error('The sensor source took too long to respond. Try again.');
      if (error instanceof TypeError) throw new Error('The sensor service could not be reached. Check the connection and try again.');
      throw error;
    } finally { clearTimeout(timeout); signal?.removeEventListener('abort',forward); }
  }
  function endpoint(mode=state.mode,sourceId=state.sourceId) {
    const query = new URLSearchParams({asset:assetId(),mode});
    if (mode === 'simulation') { query.set('scenario',state.scenario); query.set('step',state.step); }
    else query.set('source',sourceId);
    return '/api/telemetry?' + query;
  }
  function validate(data,expectedAsset=assetId()) {
    if (!data || !Array.isArray(data.samples) || !data.analysis || data.asset_id !== expectedAsset) throw new Error('The response does not contain verified readings for the selected equipment.');
    return data;
  }
  function pause() { state.playing = false; clearTimeout(timer); renderControls(); }
  function schedule() {
    clearTimeout(timer);
    if (!state.playing || state.mode !== 'simulation') return;
    if (state.step >= 180) { pause(); return; }
    timer = setTimeout(() => { state.step = Math.min(180,state.step + 2); load(); },850);
  }
  async function load() {
    clearTimeout(sliderTimer);
    controller?.abort(); controller = new AbortController();
    const serial = ++state.serial;
    state.loading = true; state.error = ''; renderControls();
    if (!state.data || state.data.asset_id !== assetId() || state.data.source?.mode !== state.mode || (state.mode === 'simulation' && state.data.scenario !== state.scenario)) $('conditionContent').hidden = true;
    $('conditionLoading').hidden = false; $('conditionError').hidden = true;
    $('conditionContent').setAttribute('aria-busy','true');
    try {
      const data = validate(await api(endpoint(),controller.signal));
      if (serial !== state.serial) return;
      state.data = data; renderData();
    } catch (error) {
      if (serial !== state.serial || error.name === 'AbortError') return;
      state.error = error.message; state.data = null; pause(); renderError();
    } finally {
      if (serial === state.serial) {
        state.loading = false; $('conditionLoading').hidden = true;
        $('conditionContent').setAttribute('aria-busy','false'); renderControls(); schedule();
      }
    }
  }
  function renderControls() {
    const simulated = state.mode === 'simulation';
    $('replayControls').hidden = !simulated;
    $('conditionRefresh').hidden = simulated;
    $('conditionPlay').innerHTML = state.playing ? icon('M8 5v14M16 5v14') + 'Pause replay' : icon('m8 4 12 8-12 8z') + 'Play replay';
    $('conditionPlay').setAttribute('aria-pressed',String(state.playing));
    $('conditionPlay').disabled = Boolean(state.error);
    $('replayStep').value = state.step; $('replayStepLabel').textContent = `Minute ${state.step} / 180`;
    $('replayStep').setAttribute('aria-valuetext',`Minute ${state.step} of 180`);
    $('conditionScenario').value = state.scenario;
    $('conditionSourceName').textContent = simulated ? 'Simulated sensor replay' : (state.data?.source?.label || state.sourceId || 'KD sensor source');
    $('conditionSourceBadge').textContent = simulated ? 'SIMULATED READINGS' : state.data?.synthetic ? 'SYNTHETIC · VIA KD' : 'SOURCE VIA KD';
    $('conditionSourceBadge').classList.toggle('via-kd',!simulated);
    $('conditionFindEvidence').disabled = state.loading || !state.data || Boolean(state.error);
    $('conditionAddPacket').disabled = state.loading || !state.data || Boolean(state.error);
    $('conditionAssetLabel').textContent = assetId();
  }
  function renderError() {
    $('conditionContent').hidden = true; $('conditionError').hidden = false;
    $('conditionErrorMessage').textContent = state.error;
    $('conditionErrorContext').textContent = state.mode === 'kd' ? 'Your KD source selection is retained. Check Sources & health → Indexed KD windows for its A-17/A-18 mapping, then retry.' : 'The simulated replay is unavailable. Retry when the service is ready.';
  }
  function chart(samples) {
    const channel = channels[state.channel], key = state.channel;
    const usable = samples.filter(sample => sample.quality === 'good' && Number.isFinite(sample[key]));
    if (!usable.length) return '<div class="sensor-chart-empty">No valid readings in this window. Missing values are not drawn as zero.</div>';
    const width = 760,height = 238,left = 51,right = 20,top = 16,bottom = 36;
    const times = samples.map((sample,index) => { const time = Date.parse(sample.timestamp); return Number.isFinite(time) ? time : index; });
    let min = Math.min(...usable.map(sample => sample[key])), max = Math.max(...usable.map(sample => sample[key]));
    const pad = Math.max((max-min)*.24,Math.abs(max)*.025,.05); min -= pad; max += pad;
    const first = times[0], span = Math.max(times[times.length-1]-first,1);
    const x = index => left+(times[index]-first)/span*(width-left-right);
    const y = value => top+(max-value)/(max-min)*(height-top-bottom);
    let paths = [],points = [];
    samples.forEach((sample,index) => {
      if (sample.quality !== 'good' || !Number.isFinite(sample[key])) { if (points.length) paths.push(points); points = []; return; }
      points.push([x(index),y(sample[key])]);
    });
    if (points.length) paths.push(points);
    const grid = Array.from({length:5},(_,i) => { const value = min+(max-min)*i/4,yp=y(value); return `<line x1="${left}" x2="${width-right}" y1="${yp}" y2="${yp}" stroke="#e7edeb"/><text x="${left-10}" y="${yp+4}" text-anchor="end">${number(value,channel.decimals)}</text>`; }).join('');
    const line = paths.map(path => path.length === 1 ? `<circle cx="${path[0][0]}" cy="${path[0][1]}" r="3" fill="${channel.color}"/>` : `<polyline points="${path.map(point => point.join(',')).join(' ')}" fill="none" stroke="${channel.color}" stroke-width="2.7" stroke-linejoin="round"/>`).join('');
    const labels = [...new Set([0,Math.floor((samples.length-1)/2),samples.length-1])].map(index => `<text x="${x(index)}" y="${height-10}" text-anchor="${index === 0 ? 'start' : index === samples.length-1 ? 'end' : 'middle'}">${esc(date(samples[index].timestamp,true))}</text>`).join('');
    return `<svg class="sensor-chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="${esc(channel.label)} in ${esc(channel.unit)}. ${usable.length} valid observed readings. Latest valid value ${number(usable[usable.length-1][key],channel.decimals)}. Gaps indicate unavailable or suspect data.">${grid}${line}${labels}</svg>`;
  }
  function renderData() {
    const data = state.data, analysis = data.analysis;
    const latest = analysis.latest || data.samples[data.samples.length-1] || {};
    const latestCaption = data.source?.stale ? 'Stale observation' : latest.quality && latest.quality !== 'good' ? latest.quality + ' reading' : 'Latest observation';
    const status = ['normal','watch','review','insufficient','observed'].includes(analysis.status) ? analysis.status : 'observed';
    const statusLabel = {normal:'Steady condition',watch:'Watch the trend',review:'Review condition',insufficient:'Data needs attention',observed:'Readings available'}[status];
    $('conditionContent').hidden = false; $('conditionError').hidden = true;
    $('conditionSummary').className = `sensor-summary status-${status}`;
    $('conditionStatusText').textContent = statusLabel;
    $('conditionAnalysisTitle').textContent = analysis.title || statusLabel;
    $('conditionAnalysisSummary').textContent = analysis.summary || 'Review the available readings with their source context.';
    $('conditionObservedAt').textContent = date(data.observed_at || latest.timestamp);
    $('conditionMetrics').innerHTML = Object.entries(channels).map(([key,channel]) => `<button class="sensor-metric ${state.channel === key ? 'active' : ''}" data-sensor-channel="${key}" aria-pressed="${state.channel === key}"><span class="sensor-metric-label"><i style="background:${channel.color}"></i>${channel.label}</span><span class="sensor-metric-value">${number(latest[key],channel.decimals)}<small>${channel.unit}</small></span><span class="sensor-metric-caption">${esc(latestCaption)} ${arrow}</span></button>`).join('');
    $('conditionChart').innerHTML = chart(data.samples);
    $('conditionChartTitle').textContent = channels[state.channel].label + ' trend';
    $('conditionChartUnit').textContent = channels[state.channel].unit;
    $('conditionWindow').textContent = `${data.samples.length} readings · observed through ${date(data.observed_at || latest.timestamp,true)} UTC`;
    $('conditionOperatingContext').innerHTML = `<span>Speed <strong>${number(latest.rpm,0)} <small>rpm</small></strong></span><span>Load <strong>${number(latest.load_pct,0)}<small>%</small></strong></span><span>Sample quality <strong>${esc(latest.quality || 'Unavailable')}</strong></span>`;
    const forecast = analysis.forecast || {};
    const minutes = forecast.minutes_to_review;
    const available = data.synthetic && forecast.available && Number.isFinite(minutes) && minutes >= 0;
    $('conditionForecastValue').innerHTML = available ? `${minutes < 1 ? '<1' : number(minutes,0)}<small>minutes</small>` : '<span class="forecast-unavailable">Not estimated</span>';
    $('conditionForecast').querySelector('.section-kicker').textContent = data.synthetic ? 'ILLUSTRATIVE FORECAST' : 'FORECAST AVAILABILITY';
    $('conditionForecastCaption').textContent = data.synthetic ? 'Time to demo review threshold' : 'A validated target is required';
    $('conditionForecastReason').textContent = forecast.reason || (available ? 'An illustrative extrapolation of observations up to this point.' : 'No supported forecast is available for this window.');
    $('conditionForecast').classList.toggle('forecast-muted',!available);
    $('conditionForecastMethod').textContent = forecast.method ? `Method: ${forecast.method}` : 'Forecasting requires a supported model and a defined target.';
    $('conditionContributors').innerHTML = (analysis.contributors || []).map(item => `<li><span class="contributor-dot"></span><div><strong>${esc(item.label)}</strong><p>${esc(item.detail)}</p></div></li>`).join('') || '<li><p>No additional contributors are available for this window.</p></li>';
    const provenance = data.source?.provenance;
    $('conditionProvenance').textContent = typeof provenance === 'string' ? provenance : data.source?.through_kd ? 'Sensor-window records retrieved through Knowledge Discovery.' : 'Deterministic simulated readings generated for this demonstration.';
    $('conditionSourceDetail').hidden = !provenance || typeof provenance !== 'object';
    $('conditionSourceDetailBody').innerHTML = provenance && typeof provenance === 'object' ? [['Database',provenance.database],['Source record',provenance.reference],['Retrieved at',date(provenance.retrieved_at)],['Payload SHA256',provenance.payload_sha256]].filter(([,value]) => value).map(([label,value])=>`<dt>${esc(label)}</dt><dd>${esc(value)}</dd>`).join('') : '';
    $('conditionModelVersion').textContent = analysis.model_version || 'Version not supplied';
    $('conditionEvidenceQuery').textContent = analysis.evidence_query || 'Equipment inspection guidance';
    $('conditionQuality').textContent = `${data.samples.filter(item => item.quality === 'good').length} good · ${data.samples.filter(item => item.quality === 'missing').length} missing · ${data.samples.filter(item => item.quality === 'suspect').length} suspect`;
    $('conditionBoundary').textContent = data.synthetic ? 'Illustrative condition analysis. The threshold is a demonstration assumption; this estimate does not establish failure time or remaining useful life.' : 'Observed source readings. Engineering limits and a validated predictive model must be supplied before operational forecasts are available.';
    renderControls();
  }
  async function loadSources() {
    const serial = ++state.sourceSerial; state.sourcesLoading = true;
    $('sourceDiscoveryStatus').textContent = 'Checking indexed sensor sources…';
    $('sourceDiscoveryRefresh').disabled = true;
    try {
      const result = await api('/api/telemetry/sources');
      if (serial !== state.sourceSerial) return;
      state.sources = result;
      const sources = Array.isArray(result.sources) ? result.sources : [];
      $('sourceChoices').innerHTML = sources.map(source => `<option value="${esc(source.source_id)}">${esc(source.label || source.source_id)}</option>`).join('');
      $('sourceDiscoveryStatus').textContent = result.message || (sources.length ? `${sources.length} sensor sources available through KD.` : 'No indexed sensor sources are available yet.');
      $('sourceConnectionLabel').textContent = result.connection?.configured ? result.connection.endpoint_label || 'Server connection configured' : 'Server connection not configured';
      $('sourceDatabase').textContent = result.database || 'Configured by the server administrator';
      $('discoveredSources').innerHTML = sources.length ? sources.map(source => `<button class="discovered-source" data-select-source="${esc(source.source_id)}"><span><strong>${esc(source.label || source.source_id)}</strong><small>${esc(source.source_id)} · ${esc((source.asset_ids || []).join(', ') || 'Equipment mapping unavailable')}</small></span><span>${source.synthetic ? 'Synthetic source' : 'Indexed source'}<small>${number(source.record_count,0)} windows · ${esc(date(source.latest_timestamp))}</small></span>${arrow}</button>`).join('') : '<div class="source-empty">Once mapped sensor windows are indexed in KD, their source IDs appear here.</div>';
    } catch(error) {
      if (serial !== state.sourceSerial) return;
      $('sourceDiscoveryStatus').textContent = error.message;
      $('sourceConnectionLabel').textContent = 'Connection unavailable';
      $('discoveredSources').innerHTML = '<div class="source-empty">Source discovery is unavailable. Your selected source ID is retained.</div>';
    } finally { if (serial === state.sourceSerial) { state.sourcesLoading = false; $('sourceDiscoveryRefresh').disabled = false; } }
  }
  async function testSource(event) {
    event.preventDefault();
    if (state.testing) return;
    const sourceId = $('kdSourceId').value.trim();
    if (!sourceId) { $('kdSourceId').focus(); $('sourceTestStatus').textContent = 'Enter an indexed source ID for the selected A-17 or A-18 pump.'; return; }
    pause();
    save(); state.testing = true;
    const requestedAsset = assetId();
    $('testSourceButton').disabled = true; $('useSimulation').disabled = true; $('sourceTestStatus').className = 'source-test-status';
    $('sourceTestStatus').textContent = `Reading ${requestedAsset} sensor windows from ${sourceId} through KD…`;
    try {
      const data = validate(await api(endpoint('kd',sourceId)),requestedAsset);
      if (assetId() !== requestedAsset) throw new Error('Equipment context changed during the test. Test again for the current equipment.');
      if ($('kdSourceId').value.trim() !== sourceId) throw new Error('The selected source ID changed during the test. Test the new source to continue.');
      controller?.abort(); ++state.serial;
      state.mode = 'kd'; state.sourceId = sourceId; state.data = data; state.error = ''; state.loading = false; save();
      $('conditionLoading').hidden = true; $('conditionContent').setAttribute('aria-busy','false');
      $('sourceTestStatus').textContent = `${data.samples.length} readings retrieved for ${data.asset_id}. This indexed window is selected for Pump condition.`;
      renderData(); window.FleetEvidence.showView('condition');
      window.FleetEvidence.toast('Indexed KD window selected. Pump condition shows the retrieved readings.');
    } catch(error) {
      $('sourceTestStatus').className = 'source-test-status source-test-error';
      $('sourceTestStatus').textContent = error.message + ' The current mode has not been changed.';
    } finally { state.testing = false; $('testSourceButton').disabled = false; $('useSimulation').disabled = false; }
  }
  function mount() {
    $('conditionView').innerHTML = `
      <div class="sensor-source-strip"><div class="sensor-source-icon">${signal}</div><div><strong id="conditionSourceName">Simulated sensor replay</strong><span><b id="conditionAssetLabel">A-17</b> · Equipment measurements</span></div><span id="conditionSourceBadge" class="sensor-source-badge">SIMULATED READINGS</span><button class="text-button" data-view="sources">Indexed KD windows ${arrow}</button></div>
      <p class="sensor-boundary">Pump condition covers the A-17/A-18 demonstrator. For other registered equipment, open its maintenance case from Equipment &amp; parts.</p>
      <div id="replayControls" class="sensor-replay"><div class="replay-scenario"><label for="conditionScenario">DEMONSTRATION SCENARIO</label><select id="conditionScenario">${Object.entries(scenarios).map(([key,label])=>`<option value="${key}">${label}</option>`).join('')}</select></div><div class="replay-timeline"><div><label for="replayStep">Replay position</label><output id="replayStepLabel" for="replayStep">Minute 80 / 180</output></div><input id="replayStep" type="range" min="0" max="180" step="1" value="80" aria-label="Replay minute"></div><button id="conditionPlay" class="button secondary">Play replay</button><button id="conditionReset" class="icon-button" title="Reset replay to minute zero" aria-label="Reset replay to minute zero">${icon('M20 7a9 9 0 0 0-15-2L2 8m0-5v5h5M4 17a9 9 0 0 0 15 2')}</button></div>
      <div class="sensor-load-line"><span id="conditionLoading" role="status"><span class="sensor-loading-dot"></span>Reading equipment data…</span><button id="conditionRefresh" class="text-button" hidden>Refresh source ${icon('M20 7a9 9 0 0 0-15-2L2 8m0-5v5h5M4 17a9 9 0 0 0 15 2')}</button></div>
      <div id="conditionError" class="sensor-error" hidden><h2>Readings unavailable</h2><p id="conditionErrorMessage"></p><p id="conditionErrorContext"></p><div><button id="conditionRetry" class="button secondary">Retry source</button><button data-view="sources" class="text-button">Sources &amp; health ${arrow}</button></div></div>
      <div id="conditionContent" hidden><div id="conditionSummary" class="sensor-summary"><div class="sensor-summary-mark">${signal}</div><div><span class="condition-status" id="conditionStatusText" role="status"></span><h2 id="conditionAnalysisTitle"></h2><p id="conditionAnalysisSummary"></p></div><div class="sensor-observed"><span>OBSERVED AT</span><strong id="conditionObservedAt"></strong></div></div>
      <div class="sensor-layout"><div class="sensor-main"><div id="conditionMetrics" class="sensor-metrics" role="group" aria-label="Measurement to chart"></div>
      <section class="sensor-chart-card"><div class="sensor-card-heading"><div><h2 id="conditionChartTitle">Vibration trend</h2><p id="conditionWindow"></p></div><span id="conditionChartUnit" class="sensor-unit"></span></div><div id="conditionChart"></div><div class="sensor-chart-footer"><span><i></i>Observed readings</span><span>UTC · Missing or suspect readings create gaps</span></div><div id="conditionOperatingContext" class="sensor-operating-context"></div></section>
      <section class="sensor-evidence-card"><div class="sensor-evidence-icon">${icon('M5 3h10l4 4v14H5zM14 3v5h5M8 12h8M8 16h5')}</div><div><span class="section-kicker">CONNECT CONDITION TO CONTEXT</span><h3>Bring the evidence into the review.</h3><p>Retrieve applicable guidance, inspections and maintenance history for this equipment.</p><small>Search context: <span id="conditionEvidenceQuery"></span></small><div class="sensor-evidence-actions"><button id="conditionFindEvidence" class="button primary">Find supporting evidence ${arrow}</button><button id="conditionAddPacket" class="button secondary">Add condition to packet ${icon('M12 5v14M5 12h14')}</button></div></div></section></div>
      <aside class="sensor-analysis-rail"><section id="conditionForecast" class="sensor-forecast"><span class="section-kicker">ILLUSTRATIVE FORECAST</span><div id="conditionForecastValue" class="forecast-value"></div><h3 id="conditionForecastCaption">Time to demo review threshold</h3><p id="conditionForecastReason"></p><small id="conditionForecastMethod"></small></section><section class="sensor-contributors"><span class="section-kicker">WHY THIS CONDITION</span><ul id="conditionContributors"></ul></section><section class="sensor-quality"><span class="section-kicker">DATA & PROVENANCE</span><strong id="conditionQuality"></strong><p id="conditionProvenance"></p><details id="conditionSourceDetail" hidden><summary>Source provenance</summary><dl id="conditionSourceDetailBody"></dl></details><small>Analysis: <span id="conditionModelVersion"></span></small></section></aside></div><p id="conditionBoundary" class="sensor-boundary"></p></div>`;
    $('sourcesView').innerHTML = `
      <div class="source-intro"><div><span class="section-kicker">INDEXED KD WINDOWS</span><h2>Inspect an indexed pump window.</h2><p>Read existing KD windows for the A-17/A-18 demonstrator. Testing a source opens Pump condition with its recorded synthetic or source-reported origin.</p></div><button id="useSimulation" class="button secondary">Open pump replay ${arrow}</button></div>
      <div class="source-flow" aria-label="Indexed pump reading path"><div><span>01</span><strong>Equipment source</strong><small>Historian, gateway or export</small></div>${arrow}<div><span>02</span><strong>Map & index</strong><small>NiFi flow or source adapter</small></div>${arrow}<div><span>03</span><strong>Knowledge Discovery</strong><small>Indexed sensor windows</small></div>${arrow}<div><span>04</span><strong>FleetEvidence</strong><small>Pump condition &amp; evidence</small></div></div>
      <div class="sources-layout"><section class="source-connection-card"><div class="sensor-card-heading"><div><span class="section-kicker">KNOWLEDGE DISCOVERY SOURCE</span><h2>Read indexed pump readings</h2></div><span class="source-read-only">Read only</span></div><p class="source-description">Select or enter an existing KD source ID for the selected A-17 or A-18 pump. This read-only test retrieves its window for Pump condition.</p><form id="sourceConnectForm"><label for="kdSourceId">Indexed source ID</label><input id="kdSourceId" list="sourceChoices" maxlength="64" placeholder="e.g. auxiliary-pump-historian" autocomplete="off"><datalist id="sourceChoices"></datalist><p class="source-field-help">The pump demonstrator expects mapped windows for <strong id="sourceAssetContext"></strong>.</p><button id="testSourceButton" class="button primary" type="submit">Test &amp; open Pump condition ${arrow}</button><p id="sourceTestStatus" class="source-test-status" role="status"></p></form><div class="source-server-status"><div><span>KD connection</span><strong id="sourceConnectionLabel">Checking…</strong></div><div><span>Sensor database</span><strong id="sourceDatabase">Checking…</strong></div></div></section>
      <aside class="source-contract-card"><span class="section-kicker">CONNECTOR CONTRACT</span><h3>Give every reading its context.</h3><p>This contract describes A-17/A-18 pump windows. The producer maps equipment identity, UTC timestamps, units and quality before indexing.</p><ul><li>Stable asset and sensor identifiers</li><li>Measurement times and value units</li><li>Data quality and operating speed / load</li><li>Original source and window provenance</li></ul><a class="button secondary full-width" href="/api/telemetry/contract" download="fleet-evidence-sensor-contract.json">Download connector contract ${icon('M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5')}</a><p class="source-technical-note">The server administrator configures the KD endpoint. This tab reads indexed windows; use Saved connections for CSV mappings and import delivery health.</p></aside></div>
      <section class="source-discovery"><div class="sensor-card-heading"><div><h2>Sources with indexed windows</h2><p id="sourceDiscoveryStatus" role="status">Checking available sources…</p></div><button class="text-button" id="sourceDiscoveryRefresh">Refresh ${icon('M20 7a9 9 0 0 0-15-2L2 8m0-5v5h5M4 17a9 9 0 0 0 15 2')}</button></div><div id="discoveredSources"></div></section>`;
    $('kdSourceId').value = typeof stored.sourceDraft === 'string' ? stored.sourceDraft : state.sourceId; $('sourceAssetContext').textContent = assetId();
    $('conditionPlay').addEventListener('click',() => { if (state.playing) pause(); else { state.playing = true; if (state.step >= 180) state.step = 0; renderControls(); load(); } });
    $('conditionReset').addEventListener('click',() => { pause(); state.step = 0; load(); });
    $('conditionScenario').addEventListener('change',event => { state.scenario = event.target.value; state.step = 80; pause(); load(); });
    $('replayStep').addEventListener('input',event => {
      state.step = Number(event.target.value); state.loading = true;
      controller?.abort(); ++state.serial;
      pause(); clearTimeout(sliderTimer); sliderTimer = setTimeout(load,150);
    });
    $('conditionMetrics').addEventListener('click',event => { const target = event.target.closest('[data-sensor-channel]'); if (target && state.data) { state.channel = target.dataset.sensorChannel; renderData(); $('conditionMetrics').querySelector(`[data-sensor-channel="${state.channel}"]`).focus(); } });
    ['conditionRefresh','conditionRetry'].forEach(id => $(id).addEventListener('click',load));
    $('conditionFindEvidence').addEventListener('click',() => { if (!state.data || state.loading) return; pause(); window.FleetEvidence.searchEvidence(state.data.analysis.evidence_query,assetId()); });
    $('conditionAddPacket').addEventListener('click',() => { if (!state.data || state.loading) return; pause(); window.dispatchEvent(new CustomEvent('fleet-condition-selected',{detail:descriptor()})); });
    $('sourceConnectForm').addEventListener('submit',testSource);
    $('sourceDiscoveryRefresh').addEventListener('click',loadSources);
    $('useSimulation').addEventListener('click',() => { pause(); state.mode = 'simulation'; state.data = null; state.error = ''; save(); window.FleetEvidence.showView('condition'); load(); });
    $('discoveredSources').addEventListener('click',event => { const target = event.target.closest('[data-select-source]'); if (target) { $('kdSourceId').value = target.dataset.selectSource; save(); $('kdSourceId').focus(); $('sourceTestStatus').textContent = 'Source selected. Test it to open Pump condition for the selected A-17 or A-18 pump.'; } });
    window.addEventListener('fleet-asset-changed',() => { pause(); $('sourceAssetContext').textContent = assetId(); $('sourceTestStatus').textContent = ''; load(); });
    window.addEventListener('fleet-view-changed',event => { if (event.detail.view !== 'condition') pause(); if (event.detail.view === 'sources' && !state.sources && !state.sourcesLoading) loadSources(); });
    renderControls(); load();
    if (window.FleetEvidence.getView() === 'sources') loadSources();
  }
  mount();
})();
