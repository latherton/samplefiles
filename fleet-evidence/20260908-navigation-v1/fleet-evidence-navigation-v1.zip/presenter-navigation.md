# Finding your way around Fleet Evidence

The sidebar follows the maintenance workflow. Start in **Fleet overview** to find equipment needing attention, then open **Maintenance cases** or **Equipment & parts**. The logo returns to Fleet overview.

## Evidence

**Evidence library** combines the former Workspace and Evidence library destinations. Switch between **Cards** and **List** without changing your equipment scope, filters or selected sources. Both layouts offer the full retrieved result set. **Training references** filters the library; it is not a qualification-management workflow.

Add useful sources to **Review packet**, then record your observations and download the brief. The packet remains a browser-saved selection. A saved maintenance case is a separate server-retained record with its own captured evidence and export.

## Data management

Use **Import workspace** to preview readings or documents, map fields and inspect accepted/rejected rows and verified delivery.

**Sources & health** has two tabs:

- **Saved connections** manages configured import sources, mappings and delivery health.
- **Indexed KD windows** tests and selects already-indexed sensor windows for the A-17/A-18 pump demonstrator. It does not acquire or index new readings.

Existing source links still open the relevant tab. Switching tabs preserves an unfinished source form.

## Demonstration and evaluation

**Synthetic feed control** is the former Mission control page. Inspect its paused/running state before using acquisition controls; navigation alone does not start the feed.

**Pump condition** is the original A-17/A-18 condition experience. It can show simulated replay or a selected KD sensor source. Registered-equipment import reviews continue through Equipment & parts and Maintenance cases.

**Model evidence** shows the illustrative model's evaluation and limits. No independent real equipment histories or validated prediction results are introduced by this navigation update.

The About control explains the demonstration scope. Earlier `#workspace`, `#sources`, `#mission` and `#condition` links remain supported.
