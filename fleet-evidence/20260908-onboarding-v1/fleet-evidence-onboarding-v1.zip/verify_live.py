#!/usr/bin/env python3
"""Bounded HTTP acceptance of Fleet Evidence; no indexing, service or KD writes."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import json
import math
import os
from pathlib import Path
import re
import statistics
import time
import urllib.error
import urllib.parse
import urllib.request

DATABASE = 'FLEET_EVIDENCE_DEMO'
LOOPBACK = {'127.0.0.1', 'localhost', '::1'}


class Document(HTMLParser):
    def __init__(self, raw):
        super().__init__(convert_charrefs=True)
        self.ids, self.links, self.assets, self.tags, self.data = [], [], [], [], []
        self.feed(raw.decode('utf-8'))

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        self.tags.append(tag)
        if 'id' in attrs:
            self.ids.append(attrs['id'])
        if tag == 'a':
            self.links.append(attrs.get('href', ''))
        if tag == 'script' and attrs.get('src'):
            self.assets.append(attrs['src'])
        if tag == 'link' and 'stylesheet' in attrs.get('rel', '').split():
            self.assets.append(attrs.get('href', ''))

    def handle_data(self, data):
        self.data.append(data)

    @property
    def text(self):
        return ' '.join(self.data)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise RuntimeError('Unexpected HTTP redirect; no destination followed.')


class Verification:
    def __init__(self, args):
        self.args, self.path = args, Path(args.output)
        self.acceptance_raw = Path(args.acceptance).read_bytes()
        self.acceptance = json.loads(self.acceptance_raw)
        if self.acceptance.get('synthetic') is not True:
            raise ValueError('The synthetic acceptance contract is required.')
        base = urllib.parse.urlsplit(args.base)
        if base.scheme != 'http' or base.hostname not in LOOPBACK or base.username or base.password or base.path not in {'', '/'} or base.query or base.fragment:
            raise ValueError('Use the loopback HTTP application origin only.')
        self.base = args.base.rstrip('/')
        self.port = base.port or 80
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        self.r = dict(complete=False, passed=False, read_only=True, kd_writes=False,
            scope='Live application/API acceptance; not a browser visual, ACL or production qualification test.',
            base=self.base, acceptance_sha256=hashlib.sha256(self.acceptance_raw).hexdigest(),
            started_at_utc=datetime.now(timezone.utc).isoformat(), requests=[], checks=[], optional_ask=dict(attempted=False))
        self.current = None
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(fd)
        self.save()

    def save(self):
        self.r['updated_at_utc'] = datetime.now(timezone.utc).isoformat()
        raw = (json.dumps(self.r, indent=2, ensure_ascii=False) + '\n').encode()
        temp = self.path.with_name(self.path.name + '.updating')
        fd = os.open(temp, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, 'wb') as out:
            out.write(raw)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temp, self.path)

    def check(self, name, condition, **evidence):
        self.r['checks'].append(dict(name=name, passed=bool(condition), **evidence))

    def stage(self, name, function):
        self.current = name
        try:
            function()
        except Exception as error:
            self.check(name + '.completed', False, error_type=type(error).__name__,
                       error=str(error)[:250] if isinstance(error, (ValueError, RuntimeError, KeyError, AssertionError)) else 'Transport or response inspection failed.')
        self.save()

    def url(self, relative):
        url = urllib.parse.urljoin(self.base + '/', relative)
        parts = urllib.parse.urlsplit(url)
        if parts.scheme != 'http' or parts.hostname not in LOOPBACK or (parts.port or 80) != self.port or parts.username or parts.password:
            raise ValueError('App-linked resource must stay on the loopback application port.')
        return url

    def request(self, path, *, params=None, payload=None, timeout=25):
        if len(self.r['requests']) >= 80:
            raise ValueError('HTTP request bound exceeded.')
        url = self.url(path)
        if params:
            url += '?' + urllib.parse.urlencode(params)
        data = None if payload is None else json.dumps(payload).encode()
        method = 'GET' if data is None else 'POST'
        route = urllib.parse.urlsplit(url).path
        if method == 'POST' and route not in {'/api/packet', '/api/ask'}:
            raise ValueError('Only derived packet export and optional Ask may use POST.')
        if route == '/api/ask' and not self.args.ask_unsupported:
            raise ValueError('Optional Ask was not requested.')
        item = dict(stage=self.current, method=method, path=route, started_at_utc=datetime.now(timezone.utc).isoformat())
        self.r['requests'].append(item)
        self.save()
        start = time.monotonic()
        req = urllib.request.Request(url, data=data, headers={'Content-Type':'application/json'} if data else {}, method=method)
        try:
            try:
                response = self.opener.open(req, timeout=timeout)
            except urllib.error.HTTPError as error:
                response = error
            with response:
                raw = response.read(4 * 1024**2 + 1)
                status, headers = response.code, dict(response.headers.items())
            if len(raw) > 4 * 1024**2:
                raise ValueError('Response exceeded 4 MiB.')
            item.update(http_status=status, elapsed_ms=round((time.monotonic()-start)*1000, 2),
                response_bytes=len(raw), response_sha256=hashlib.sha256(raw).hexdigest())
            return status, {k.lower():v for k,v in headers.items()}, raw, item
        except Exception as error:
            item.update(elapsed_ms=round((time.monotonic()-start)*1000, 2), error_type=type(error).__name__)
            raise

    def get_json(self, path, params=None):
        status, headers, raw, item = self.request(path, params=params)
        self.check(self.current+'.http', status == 200, http_status=status)
        self.check(self.current+'.json_content_type', 'application/json' in headers.get('content-type',''))
        value = json.loads(raw)
        if not isinstance(value, dict):
            raise ValueError('Expected a JSON object.')
        return value, item

    def live_rows(self, params):
        value, item = self.get_json('/api/search', params)
        rows = value.get('records', [])
        self.check(self.current+'.live_backend', value.get('live') is True and value.get('database') == DATABASE
                   and 'Knowledge Discovery' in value.get('backend',''))
        ids = [r['id'] for r in rows]
        self.check(self.current+'.unique_ids', len(ids)==len(set(ids)), record_ids=ids)
        valid = all(isinstance(r.get('score'), (int,float)) and math.isfinite(r['score'])
            and r.get('excerpt') and r.get('retrieval',{}).get('text')
            and r['retrieval'].get('reference') == 'urn:fleet-evidence:'+r['id']
            and re.fullmatch('[0-9a-f]{64}', r['retrieval'].get('source_sha256',''))
            and re.fullmatch('[0-9a-f]{64}', r['retrieval'].get('record_sha256',''))
            and r.get('metadata_origin') == 'authored synthetic fixture' for r in rows)
        self.check(self.current+'.retrieved_text_and_authored_metadata', bool(rows) and valid)
        item['server_elapsed_ms'] = value.get('elapsed_ms')
        return {r['id']:r for r in rows}, item

    def availability(self):
        health, _ = self.get_json('/api/health')
        self.check('health.correct_live_count', health.get('ok') is True and health.get('database') == DATABASE
            and health.get('indexed_records') == self.acceptance['counts']['records'], indexed_records=health.get('indexed_records'))
        boot, _ = self.get_json('/api/bootstrap')
        self.bootstrap = boot
        expected = self.acceptance['counts']
        self.check('bootstrap.collection_counts', boot.get('synthetic') is True and boot.get('app_name') == 'Fleet Evidence'
            and boot.get('service',{}).get('available') is True
            and all(boot.get('counts',{}).get(key)==expected[key] for key in ['records','duplicate_groups','unresolved','superseded']))
        self.check('bootstrap.asset_configuration', {r['id']:r['configuration'] for r in boot.get('assets',[])} == {'A-17':'B','A-18':'A'})

    def static(self):
        status, headers, raw, _ = self.request('/')
        doc = Document(raw)
        self.check('static.index', status==200 and 'text/html' in headers.get('content-type','')
                   and 'synthetic demonstration' in doc.text.lower())
        self.check('static.local_asset_links', 2 <= len(doc.assets) <= 10, assets=doc.assets)
        for asset in doc.assets:
            code, meta, content, _ = self.request(asset)
            suffix = urllib.parse.urlsplit(asset).path.rsplit('.',1)[-1]
            suitable = 'text/css' in meta.get('content-type','') if suffix=='css' else 'javascript' in meta.get('content-type','') if suffix=='js' else True
            self.check('static.asset.'+asset, code==200 and bool(content) and suitable, bytes=len(content))

    def scopes(self):
        expected = self.acceptance['scope_expectations']
        for asset, key in [('A-17','A17_applicable_without_history'),('A-18','A18_applicable_without_history')]:
            self.current = 'scope.'+asset
            rows, _ = self.live_rows(dict(q='',asset=asset,kind='all',scope='applicable',history='0'))
            self.check(self.current+'.exact_ids', set(rows)==set(expected[key]), missing_ids=sorted(set(expected[key])-set(rows)), unexpected_ids=sorted(set(rows)-set(expected[key])))
        self.current = 'scope.all_history'
        self.all_rows, _ = self.live_rows(dict(q='',asset='A-17',kind='all',scope='all',history='1'))
        all_ids = set(expected['A17_applicable_without_history']) | set(expected['A18_applicable_without_history']) | set(expected['superseded_ids'])
        self.check('scope.all_history.exact_ids', set(self.all_rows)==all_ids, missing_ids=sorted(all_ids-set(self.all_rows)), unexpected_ids=sorted(set(self.all_rows)-all_ids))
        self.check('scope.unknown_stays_unknown', self.all_rows['INS-09']['asset_id']=='unknown'
            and self.all_rows['INS-09']['configuration']=='unknown' and self.all_rows['INS-09']['status']=='unresolved'
            and self.all_rows['INS-09']['applicability']['review_required'] is True)
        self.check('scope.current_reference', self.all_rows['TM-P200-C']['status']=='current'
            and self.all_rows['TM-P200-C']['supersedes']=='TM-P200-B' and self.all_rows['TM-P200-B']['status']=='superseded')

    def retrieval(self):
        for case in self.acceptance['retrieval_cases']:
            self.current = 'retrieval.'+case['id']
            rows, _ = self.live_rows(dict(q=case['query'],asset=case['asset'],kind=case['kind'],scope=case['scope'],history='1' if case['history'] else '0'))
            self.check(self.current+'.expected_evidence', set(case['relevant_record_ids']) <= set(rows), missing_ids=sorted(set(case['relevant_record_ids'])-set(rows)))
            self.check(self.current+'.excluded_evidence', not set(case['excluded_ids']) & set(rows), unexpected_ids=sorted(set(case['excluded_ids']) & set(rows)))

    def issues(self):
        result, _ = self.get_json('/api/issues', dict(asset='A-17'))
        issues = result.get('issues', [])
        self.check('issues.live', result.get('live') is True and 'Knowledge Discovery' in result.get('backend',''))
        duplicates = [r for r in issues if r['type']=='duplicate']
        expected = set(self.acceptance['invariants']['duplicate_pair']['record_ids'])
        self.check('issues.exact_copy_group', len(duplicates)==1 and set(duplicates[0]['record_ids'])==expected,
                   groups=[r['record_ids'] for r in duplicates])
        self.check('issues.missing_identity', any(r['type']=='missing_identity' and r['record_ids']==['INS-09'] for r in issues))
        self.check('issues.superseded_visible', any(r['type']=='superseded' and 'TM-P200-B' in r['record_ids'] for r in issues))
        conflicts = {rid for r in issues if r['type']=='conflicting_record' for rid in r['record_ids']}
        self.check('issues.conflicting_sources', {'INS-28','BLT-08'} <= conflicts)
        self.check('issues.distinct_events_retained', self.all_rows['WO-104']['event_id']==self.all_rows['WO-104-COPY']['event_id']=='EVT-A17-104'
            and self.all_rows['WO-219']['event_id']=='EVT-A17-219'
            and self.all_rows['INS-03']['event_id']=='EVT-A17-104' and not self.all_rows['INS-03']['duplicate_group'])

    def sources(self):
        selected = set(self.acceptance['packet_case']['ids']) | {'WO-104-COPY','WO-307','INS-03'}
        selected |= {check['record_id'] for check in self.acceptance['source_checks']}
        sources = {}
        for rid in sorted(selected):
            self.current = 'source.'+rid
            record, _ = self.get_json('/api/record/'+rid)
            self.check(self.current+'.identity', record.get('id')==rid and record.get('reference')=='urn:fleet-evidence:'+rid)
            code, headers, raw, _ = self.request(record['source_url'])
            doc = Document(raw)
            digest = hashlib.sha256(raw).hexdigest()
            sources[rid] = digest
            self.check(self.current+'.verified_bytes', code==200 and 'text/html' in headers.get('content-type','')
                and digest==self.all_rows[rid]['retrieval']['source_sha256'])
            self.check(self.current+'.anchors_and_label', {s['id'] for s in record['sections']} <= set(doc.ids)
                and 'synthetic demonstration' in doc.text.lower() and all(link[1:] in doc.ids for link in doc.links if link.startswith('#')))
            for expected in self.acceptance['source_checks']:
                if expected['record_id']==rid:
                    self.check(self.current+'.quote.'+expected['section_id'], expected['section_id'] in doc.ids and expected['exact_quote'] in doc.text)
        self.check('sources.duplicate_bytes_preserved', sources['WO-104']==sources['WO-104-COPY']==self.acceptance['invariants']['duplicate_pair']['same_source_sha256']
                   and sources['INS-03']!=sources['WO-104'])

    def packet(self):
        case = self.acceptance['packet_case']
        note = case['note']+'\nNote encoding check: <b id="FE-VERIFY-NOTE">review & retain</b>'
        code, headers, raw, _ = self.request('/api/packet', payload=dict(ids=case['ids'], notes=note, asset_id=case['asset_id']))
        doc = Document(raw)
        self.check('packet.downloadable', code==200 and 'text/html' in headers.get('content-type','') and 'attachment' in headers.get('content-disposition','').lower())
        self.check('packet.draft_synthetic', all(label.lower() in doc.text.lower() for label in case['required_labels']))
        self.check('packet.references', all(ref in doc.text for ref in case['required_source_references']))
        self.check('packet.note_escaped', 'FE-VERIFY-NOTE' not in doc.ids and '<b id="FE-VERIFY-NOTE">review & retain</b>' in doc.text)
        self.check('packet.unresolved_retained', 'INS-09' in doc.text and 'missing' in doc.text.lower() and ('identity' in doc.text.lower() or 'serial' in doc.text.lower()))
        for rid in case['ids']:
            self.check('packet.embedded_sections.'+rid, all(rid+'-'+s['id'] in doc.ids for s in self.all_rows[rid]['sections']))
        self.check('packet.original_source_links', all(any(urllib.parse.urlsplit(link).path=='/sources/'+rid for link in doc.links) for rid in case['ids']))
        originals = [link for link in doc.links if urllib.parse.urlsplit(link).path.startswith('/sources/')]
        portable = all(urllib.parse.urlsplit(link).scheme=='http' and urllib.parse.urlsplit(link).hostname in LOOPBACK
                       and (urllib.parse.urlsplit(link).port or 80)==self.port for link in originals)
        self.check('packet.downloaded_source_links_portable', bool(originals) and portable, source_links=originals)
        self.check('packet.self_contained', not doc.assets and 'script' not in doc.tags and '@media print' in raw.decode('utf-8'))

    def timing(self):
        measurements = []
        required = {'WO-104','WO-104-COPY','WO-219'}
        for number in range(1,4):
            self.current = 'timing.run'+str(number)
            rows, item = self.live_rows(dict(q='recurring seal leakage',asset='A-17',kind='all',scope='applicable',history='0'))
            self.check(self.current+'.critical_evidence', required <= set(rows), missing_ids=sorted(required-set(rows)))
            measurements.append(item['elapsed_ms'])
        self.r['critical_retrieval_timing'] = dict(runs=3, client_elapsed_ms=measurements,
            median_ms=round(statistics.median(measurements),2), max_ms=max(measurements),
            note='Three individual sequential HTTP observations, not a throughput or concurrent-load benchmark.',
            configured_max_ms=self.args.max_search_ms)
        if self.args.max_search_ms is not None:
            self.check('timing.explicit_threshold', max(measurements)<=self.args.max_search_ms,
                       max_ms=max(measurements), required_max_ms=self.args.max_search_ms)

    def optional_ask(self):
        if not self.args.ask_unsupported:
            return
        self.current = 'optional_ask'
        result = self.r['optional_ask'] = dict(attempted=True, requests=1, required_for_core_acceptance=False, semantic_review_required=True)
        case = self.acceptance['unsupported_questions'][0]
        try:
            code, _, raw, _ = self.request('/api/ask', payload=dict(question=case['question'],asset_id='A-17'), timeout=70)
            response = json.loads(raw)
            result.update(http_status=code, generated=response.get('generated'), live=response.get('live'), error=response.get('error'))
            text = response.get('answer','')
            if isinstance(text,str):
                result['answer'] = text[:12000]
                result['uncertainty_phrase_present'] = bool(re.search(r'not establish|not determine|cannot determine|insufficient|does not (?:identify|provide)|no (?:definitive|root.cause)',text,re.I))
                result['expected_boundary'] = case['expected']
            result['source_ids'] = [r.get('id') for r in response.get('sources',[])]
            result['source_ids_known'] = bool(result['source_ids']) and set(result['source_ids']) <= set(self.all_rows)
        except Exception as error:
            result['error_type'] = type(error).__name__
        self.save()

    def run(self):
        for name, action in [('availability',self.availability),('static',self.static),('scopes',self.scopes),
                ('retrieval',self.retrieval),('issues',self.issues),('sources',self.sources),('packet',self.packet),('timing',self.timing)]:
            self.stage(name,action)
        self.optional_ask()
        self.r.update(complete=True, passed=all(c['passed'] for c in self.r['checks']),
            checks_passed=sum(c['passed'] for c in self.r['checks']), checks_total=len(self.r['checks']),
            failed_check_names=[c['name'] for c in self.r['checks'] if not c['passed']],
            acceptance_scope='Core HTTP workflow; optional generated text always requires separate semantic review.')
        self.save()
        print(json.dumps(dict(complete=True,passed=self.r['passed'],report=str(self.path),failed_check_names=self.r['failed_check_names'])))
        return 0 if self.r['passed'] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base',default='http://127.0.0.1:8095')
    parser.add_argument('--acceptance',required=True)
    parser.add_argument('--output',required=True,help='Fresh JSON report path; prior files are never overwritten.')
    parser.add_argument('--ask-unsupported',action='store_true',help='Make at most one optional generated-answer request; no automatic retry.')
    parser.add_argument('--max-search-ms',type=float,help='Optional explicitly chosen threshold for each of three critical retrieval runs.')
    args = parser.parse_args()
    if args.max_search_ms is not None and (not math.isfinite(args.max_search_ms) or args.max_search_ms<=0):
        parser.error('--max-search-ms must be a positive finite number.')
    return Verification(args).run()


if __name__ == '__main__':
    raise SystemExit(main())
