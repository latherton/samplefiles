# Fleet Evidence — five-minute synthetic maintenance demonstration

The story is an evidence review for auxiliary cooling pump **A-17**, model **P-200**, configuration **B**. All records and maintenance facts are fictional. The goal is a draft packet a planner can inspect and discuss, not a repair recommendation, technical approval, root-cause diagnosis or readiness declaration.

This collection contains **48 source records**, **47 distinct source byte hashes**, **one duplicate group**, **three unresolved records** and **three superseded records**. Those are authored collection counts. Live indexed counts and retrieval must come from the application backend. The related A-18 asset is configuration A.

## Before presenting

The installed release has passed live indexing and all 164 HTTP assertions against [acceptance.json](acceptance.json); see the [dated build and acceptance record](../../docs/navy-demo-build-2026-09-07.md) for scope and the latest browser QA observations. Before each presentation, run the full story three times against the actual backend. Search, source navigation, selection and packet export must work without waiting for generative AI. If KD is unavailable, stop and show the reported unavailable state; do not substitute prewritten search results while describing them as live.

Open the workspace with A-17 selected, applicable scope and history off. Clear any old selections and notes. Keep “Synthetic demonstration” visible. Start with a clean packet. The recorded HTTP acceptance and browser QA are distinct from this per-presentation rehearsal; use the current application to confirm the complete walkthrough.

## 0:00–0:35 — give the planner a job

**Say:** “A planner is preparing a review of recurring seal leakage on this fictional pump. The challenge is assembling the relevant history, the applicable reference and the questions still open. Let's make that evidence visible.”

Select A-17. Search **recurring seal leakage**. Avoid narration about servers, vectors or document counts at this point. The source cards and their asset/configuration labels should establish the task.

## 0:35–1:35 — make the evidence tangible

Open **WO-219** at [Cause not established](corpus/sources/WO-219.html#cause-not-established). Then open **WO-104** at [Recorded outcome](corpus/sources/WO-104.html#recorded-outcome).

**Say:** “The February record describes an immediate follow-up observation. July is a separate report of renewed leakage. These sources establish a chronology. They do not establish why the symptom recurred.”

Select one WO-104 source and WO-219 for the packet. Click the section links so the audience sees the underlying words, not just a generated explanation. Do not call administrative closure proof of successful maintenance or long-term reliability.

## 1:35–2:35 — show why records stewardship matters

Open the review findings. Expand **DUP-WO-104**: WO-104 and WO-104-COPY have identical source bytes and the same event identifier. Both file references remain available. **WO-219 remains a distinct event.** INS-03 is another report about the February follow-up and is not a duplicate file.

**Say:** “Two copies should not look like two failures. But two separate failures should not disappear because the narratives sound alike. This review keeps those distinctions visible.”

Search **inspection guidance**, select the **Guidance** filter (manuals) and open **TM-P200-C** at [Applicability](corpus/sources/TM-P200-C.html#applicability). Then replace the search with **TM-P200** before turning history on briefly. This query exposes **TM-P200-B** alongside Revision C. Its later repository receipt is described in the source, while the source register still marks it superseded.

**Say:** “The supplied source register identifies Revision C for configuration B. A newer copy date does not turn the old revision into the current one.”

Select TM-P200-C. Restore history off. If time permits, switch the filter to **Work orders**, replace the search with **seal leakage**, broaden scope to **all configurations** and open **WO-307**: A-18/configuration A stays visibly different. Restore applicable scope afterward. Do not claim that the application decided technical equivalence or publication authority; these are explicit, reviewable source-register facts.

## 2:35–3:35 — make the unresolved question useful

Open **INS-09** at [Identity gap](corpus/sources/INS-09.html#identity-gap). Keep the unknown asset and configuration labels visible. Select it for the packet with an unresolved flag.

**Say:** “This inspection names the model but lacks the serial and configuration. It may matter, but assigning it to A-17 would be a guess. The packet carries the source-owner question forward instead.”

If asked for a root cause, point back to WO-219: **“The records do not establish a root cause.”** The collection contains no answer that authorizes operation or establishes a person's qualification. If optional live generation is available, use it only after its own source/unsupported-question acceptance has passed; otherwise explain the source directly. Never present an authored line as a live model response.

## 3:35–4:15 — connect to training without inferring a deficiency

Search **training seal leakage**, select the training filter, and open **TRN-P200-01** at [Related evidence](corpus/sources/TRN-P200-01.html#related-evidence). It links the evidence-reading discussion to TM-P200-C, WO-104, WO-219 and INS-09.

**Say:** “An instructor can use the reviewed evidence to prepare a discussion of history, references and uncertainty. This is a related learning source; it does not tell us that a crew is unqualified or that training caused the discrepancy.”

Select TRN-P200-01, then open the review packet.

## 4:15–5:00 — finish with a deliverable and the sponsor ask

The packet should contain **TM-P200-C, WO-104, WO-219, INS-09 and TRN-P200-01**. Add this note:

> Retain the INS-09 identity question for the source owner. The records establish separate observations but do not establish a cause.

Export the draft HTML evidence brief and show its source links, synthetic label and unresolved item. The print layout can be saved as PDF; no formal approval button is part of the workflow.

**Say:** “This is what Ellis's records work can enable: a planner reaches review with the relevant evidence and the unanswered questions together. The next step is to select one real planning team and one records collection, establish today's baseline, and test whether this reduces evidence-preparation effort and reviewer rework.”

For RDML Ettlich, ask for sponsorship of that bounded pilot and identification of the maintenance workflow owner, records steward and funding/contracting path. Ellis Varela's exact role and the actual source collections still require confirmation. Do not imply that a meeting itself grants data access or deployment authority.

## What the audience is seeing

KD supplies live retrieval IDs, matching text and scores. The application presents the source records, supplied revision/applicability metadata, duplicate review groups, unresolved items and packet workflow. This 48-record application's live HTTP acceptance is recorded in the [installed build record](../../docs/navy-demo-build-2026-09-07.md), with browser QA tracked separately there. Its content was indexed from authored IDX; the general KD26.1 environment's earlier extraction, name recognition, vector and answer demonstrations are separate evidence. Optional generation is not exposed in this release's UI and was not tested by its HTTP acceptance run.

The corpus does not contain real operational records, official Navy publications or executable maintenance procedures. Duplicate grouping does not delete records. Current-reference status is authored metadata. The demo does not establish source ACL enforcement, repair suitability, Navy endorsement, fleet readiness improvement or automated qualification decisions.
