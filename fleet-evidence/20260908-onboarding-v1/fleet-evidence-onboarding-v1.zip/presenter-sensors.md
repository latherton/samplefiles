# Fleet Evidence: five-minute sensor demonstration

Updated September 8, 2026 UTC / September 7 Honolulu. Release `20260908-sensors-v5` is active. The build passed 62 local tests; native sensor indexing, complete payload readback and live application sample/analysis/provenance checks passed for both assets, along with 166 evidence HTTP checks and 55 Windows sensor checks covering the connector contract and condition packet. Remote browser source selection, provenance, condition-packet assembly and downloaded HTML passed; v5 also passed the corrected source-navigation check. Rehearse the complete story before presenting. See the [sensor build record](../../docs/navy-demo-sensor-build-2026-09-08.md); retain the [original evidence presenter](presenter.md) for the earlier document-focused demonstration.

## Before presenting

Open [Fleet Evidence](http://localhost:8095) in Chrome inside the remote Windows desktop. Select **A-17**. Open **Data sources → Use simulated readings** to start explicitly in replay mode, then choose **Persistent change** at minute 30. Check live evidence retrieval separately. Confirm that `demo-pump-replay` appears in Data sources and passes **Test & use source** before presenting the KD sensor readback segment; its remote seed, full API readback and browser source-selection/provenance checks have passed.

Pause replay before changing views or selecting a condition. For a clean rehearsal, clear the packet selection and planner observations. The packet needs at least one source from the live KD evidence collection. Source documents remain fictional throughout, including when the sensor source changes.

## 0:00–1:15 — Show the changing condition

“This is fictional pump A-17. We are replaying simulated measurements so we can show the complete workflow without connecting equipment.”

In **Equipment condition**, point to the **SIMULATED READINGS** label, UTC observation time and vibration, temperature and pressure cards. At minute 30, show the steady baseline. Move the slider to **80** or play toward it, then pause.

“Vibration has risen even after accounting for the simulated load and speed. The recent trend would reach our demonstration review threshold in about 19 minutes if it continued. That is a threshold projection, not a prediction of when the pump will fail.”

Select temperature and pressure to show their observed trends. Point to **Why this condition**, the observed-trend method and version. Move to minute **120** briefly: the review threshold is now observed, so a future crossing is no longer estimated.

## 1:15–1:45 — Show why context and quality matter

Choose **Load change**, which resets the position to minute 80. The raw measurements are higher, but the authored load/speed correction retains a steady condition.

“An operating change can explain a higher reading. We want that context before raising a review.”

Choose **Missing readings**. Show the gaps and unavailable estimate.

“Questionable measurements stay visible. Missing data does not become a healthy reading.”

Return to **Persistent change**, minute **80**, and pause.

## 1:45–2:45 — Retrieve supporting evidence through KD

Choose **Find supporting evidence**. Explain that the application sends the equipment/symptom search into the existing KD evidence collection. Inspect an applicable reference and a historical report, for example **TM-P200-C** and **WO-219** when returned. Open their source passages and add them to the packet.

“The trend gives the planner a reason to review. Knowledge Discovery supplies searchable references, inspections and maintenance history. These fictional reports do not establish the cause of the simulated vibration change.”

If discussing WO-104 and WO-219, retain their distinction as separate events; WO-104's copied file does not become another occurrence. Source revision and applicability still require review.

## 2:45–3:35 — Preserve the condition with the sources

Return to **Equipment condition** and choose **Add condition to packet**, then open the packet view. Confirm that both the condition card and evidence sources are selected. Add this planner observation:

> Review the simulated vibration change against applicable references and historical reports. Confirm equipment mapping and an appropriate engineering target before operational use.

Choose **Download review brief** or **Print / save PDF**. Point to the measurements, event time, forecast reason, model version, origin and snapshot hash alongside source references.

“The server recomputes this condition from the selected readings. The draft carries the source trail and the question for a person to review.”

If a connected window changes after selection, export asks the user to review and select it again; it does not silently substitute the new window.

## 3:35–4:20 — Show the KD source interface

Open **Data sources**, select or type **demo-pump-replay**, then choose **Test & use source**. This segment requires the verified remote seed noted above. The condition view should display **SYNTHETIC · VIA KD**. Open **Source provenance** to show the sensor database, exact source reference, retrieval time and payload hash.

“These measurements are still simulated. This time they have been indexed and retrieved through KD, using the same source interface that accepts normalized external readings.”

Keep the difference between observation time and KD retrieval time explicit. If a source is unavailable, the interface reports that failure and retains the selected source; changing back to simulation is a separate user action.

## 4:20–5:00 — Explain the real-data connection

Return to **Data sources** and show **Download connector contract**.

“A source adapter or a configured NiFi flow would collect an approved historian export or gateway feed, map the asset and units, preserve quality and timestamps, then index bounded sensor windows into the dedicated KD collection. This interface reads those indexed windows.”

“When a producer identifies its readings as real, the current application shows measurements and freshness. It does not apply the demo thresholds or create an operational forecast. The next engineering step is to define the equipment target and validate a suitable model with real history and outcomes.”

The connector is implemented as a normalized-record bridge. Native device protocols, a working historian connection, production identity mapping and a configured NiFi acquisition flow remain integration work. See [SENSOR-SOURCES.md](SENSOR-SOURCES.md) for the exact contract, dry-run/apply commands, indexing receipts and configuration. Real-source freshness defaults to five minutes and is configurable by the administrator; that setting is not a maintenance limit.
