/* Durable synthetic maintenance episodes. All source/case state comes from the server. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const fleet = window.FleetEvidence;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const svg = path => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${path}"/></svg>`;
  const icons = {arrow:svg('M4 12h16m-6-6 6 6-6 6'),plus:svg('M12 5v14M5 12h14'),signal:svg('M2 12h5l3-8 4 16 3-8h5'),case:svg('M4 5h6l2 3h8v12H4z'),check:svg('m5 12 4 4L19 6'),clock:svg('M12 8v4l3 2M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0'),refresh:svg('M20 7a9 9 0 0 0-15-2L2 8m0-5v5h5M4 17a9 9 0 0 0 15 2'),download:svg('M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5')};
  const scenarioNames = {degradation:'Persistent change',normal:'Steady operation',load_change:'Load change',sensor_gap:'Missing readings'};
  const statusNames = {normal:'Within demo baseline',watch:'Watch the trend',review:'Review threshold reached',insufficient:'Reliable readings needed',observed:'Measurements received',open:'Open for review',reviewed:'Review recorded',closed:'Closed'};
  const runNames = {idle:'Ready to begin',running:'Acquisition running',paused:'Acquisition paused',completed:'Run complete',error:'Source needs attention',stopped:'Source stopped'};
  const deliveryNames = {idle:'Awaiting a window',acquiring:'Acquiring readings',queued:'Queued for KD',submitted:'Submitted to KD',pending:'Waiting for KD commit',verified:'Readback verified',error:'Delivery needs attention',blocked:'Delivery blocked'};
  const state = {mission:null,cases:[],caseData:null,selectedId:null,filter:'all',busy:false,error:'',detailError:'',loading:false,serial:0,detailSerial:0,lastFetched:null};
  let timer;
  const num = (value, digits=1) => typeof value === 'number' && Number.isFinite(value) ? value.toLocaleString('en-US',{maximumFractionDigits:digits}) : '—';
  const stamp = value => {
    const date = new Date(value);
    return value && Number.isFinite(date.getTime()) ? new Intl.DateTimeFormat('en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false,timeZone:'UTC'}).format(date) + ' UTC' : 'Not yet recorded';
  };
  const tone = status => ['normal','verified','closed'].includes(status) ? 'green' : ['watch','review','pending','paused'].includes(status) ? 'amber' : ['error','blocked','insufficient'].includes(status) ? 'rose' : 'slate';
  const chip = (text,status='') => `<span class="mc-chip mc-${tone(status)}"><i></i>${esc(text)}</span>`;
  const empty = (title,detail) => `<div class="mc-empty">${icons.case}<h3>${esc(title)}</h3><p>${esc(detail)}</p></div>`;
  const selected = () => fleet.getSelection();
  const assetRow = id => state.mission?.assets?.find(row => row.asset_id === id);
  const latestFor = data => {
    if (data && Object.hasOwn(data,'latest')) return data.latest;
    const row = assetRow(data?.asset_id), source = row?.source_id || state.mission?.run?.source_id;
    return source === data?.source_id ? row?.telemetry || null : null;
  };
  function paint(id, html) {
    const node = $(id), active = document.activeElement;
    const focusKey = node.contains(active) ? ['data-open-case','data-new-case'].find(key => active.hasAttribute?.(key)) : null;
    const value = focusKey ? active.getAttribute(focusKey) : null, left = node.scrollLeft;
    node.innerHTML = html; node.scrollLeft = left;
    if (focusKey) [...node.querySelectorAll('button')].find(button => button.getAttribute(focusKey) === value)?.focus({preventScroll:true});
  }
  const unwrap = data => data?.case || data;

  async function api(path, payload) {
    const abort = new AbortController();
    const timeout = setTimeout(() => abort.abort(),30000);
    try {
      const response = await fetch(path,{method:payload === undefined ? 'GET' : 'POST',credentials:'same-origin',cache:'no-store',signal:abort.signal,...(payload === undefined ? {} : {headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})});
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || data.error || 'The server could not complete this request.');
      return data;
    } catch (error) {
      if (error.name === 'AbortError') throw new Error('The request timed out. Refresh the server state before trying the action again.');
      if (error instanceof TypeError) throw new Error('The application could not be reached. Existing case data is retained on the server.');
      throw error;
    } finally { clearTimeout(timeout); }
  }
  function flash(message, error=false) {
    $('missionMessage').textContent = message;
    $('missionMessage').classList.toggle('mc-error',error);
    $('missionMessage').hidden = !message;
    $('caseMessage').textContent = message;
    $('caseMessage').classList.toggle('mc-error',error);
    $('caseMessage').hidden = !message;
  }
  function buttonBusy(busy) {
    state.busy = busy;
    document.querySelectorAll('[data-mission-action], [data-case-action], #caseCreateSubmit').forEach(button => { button.disabled = busy || button.dataset.unavailable === 'true'; });
  }
  function schedule() {
    clearTimeout(timer);
    if (!document.hidden && ['mission','cases'].includes(fleet.getView())) timer = setTimeout(() => refresh(true),7000);
  }
  async function refresh(background=false) {
    if (state.loading) return;
    state.loading = true;
    const serial = ++state.serial;
    $('missionRefresh').disabled = true;
    try {
      const results = await Promise.allSettled([api('/api/mission'),api('/api/cases')]);
      if (serial !== state.serial) return;
      if (results[0].status === 'fulfilled') state.mission = results[0].value;
      if (results[1].status === 'fulfilled') state.cases = Array.isArray(results[1].value.cases) ? results[1].value.cases : [];
      const errors = results.filter(result => result.status === 'rejected').map(result => result.reason.message);
      const previousError = state.error;
      state.error = errors.join(' ');
      if (errors.length) flash(state.error,true); else if (!background || previousError) flash('');
      state.lastFetched = new Date().toISOString();
      renderMission(); renderCaseList();
      if (state.selectedId && fleet.getView() === 'cases') await loadCase(state.selectedId,true);
    } finally { state.loading = false; $('missionRefresh').disabled = false; schedule(); }
  }
  async function loadCase(id, background=false) {
    const serial = ++state.detailSerial;
    if (!background) {
      state.selectedId = id; state.caseData = null;
      $('caseDetail').innerHTML = empty('Opening the case','Reading its saved condition, evidence and review history.');
      renderCaseList();
    }
    try {
      const data = unwrap(await api('/api/cases/' + encodeURIComponent(id)));
      if (serial !== state.detailSerial || state.selectedId !== id) return;
      const oldUpdated = state.caseData?.updated_at;
      state.caseData = data; state.detailError = '';
      if (!background || !$('caseDetailBody')) renderCase();
      else {
        if ($('caseLatest')) $('caseLatest').innerHTML = conditionCard(latestFor(data),'Latest available',false);
        if ($('caseSelectionCount')) $('caseSelectionCount').textContent = `(${selected().ids.length} sources)`;
        if ($('caseServerStatus')) $('caseServerStatus').textContent = oldUpdated !== data.updated_at ? 'Saved case changed. Refresh case to review the latest history; your draft remains here.' : 'Server refreshed ' + stamp(state.lastFetched);
      }
    } catch (error) {
      if (serial !== state.detailSerial) return;
      state.detailError = error.message;
      if (!background) $('caseDetail').innerHTML = empty('Case unavailable',error.message);
      flash(error.message,true);
    }
  }
  function spark(samples=[]) {
    const valid = samples.filter(sample => typeof sample.vibration_mm_s === 'number' && Number.isFinite(sample.vibration_mm_s) && sample.quality === 'good');
    if (valid.length < 2) return `<div class="mc-chart-empty">A trend appears after enough reliable readings arrive.</div>`;
    const values = valid.map(row => row.vibration_mm_s), lo = Math.min(...values), hi = Math.max(...values), range = Math.max(hi-lo,0.5);
    const x = index => 8 + index / Math.max(samples.length-1,1) * 344;
    const y = value => 67 - (value-lo)/range*48;
    let drawing='',pen=false;
    samples.forEach((row,index) => {
      if (row.quality !== 'good' || typeof row.vibration_mm_s !== 'number' || !Number.isFinite(row.vibration_mm_s)) { pen=false; return; }
      drawing += `${pen ? 'L' : 'M'}${x(index).toFixed(1)},${y(row.vibration_mm_s).toFixed(1)} `; pen=true;
    });
    return `<svg class="mc-spark" viewBox="0 0 360 80" role="img" aria-label="Observed vibration trend, ${valid.length} reliable samples. Gaps retain unavailable readings."><path d="M8 70H352M8 42H352M8 14H352" class="mc-spark-grid"/><path d="${drawing}" class="mc-spark-line"/></svg>`;
  }
  function delivery(row) {
    const item = row?.delivery || {};
    const status = item.state === 'acquiring' && state.mission?.run?.state !== 'running' ? 'idle' : item.state || 'idle';
    const jobs = item.pending_index_ids || (item.index_id ? [item.index_id] : []);
    const pendingCopy = row.telemetry ? 'A newer submitted window is awaiting KD commit. The condition below is from the earlier verified observation; delivery can take several minutes.' : 'A submitted window is awaiting KD commit. No verified condition is available yet; delivery can take several minutes.';
    return `<div class="mc-delivery mc-delivery-${esc(status)}"><span>${chip(deliveryNames[status] || status,status)}</span><small>${esc(status === 'pending' ? pendingCopy : item.message || item.error?.message || (status === 'verified' ? 'Submitted window matched KD readback. Newer local readings may still await delivery.' : 'Condition and metrics appear only after a window is verified through KD.'))}</small><div class="mc-delivery-times">${item.submitted_at ? `<span>Submitted ${esc(stamp(item.submitted_at))}</span>` : ''}${item.verified_at ? `<span>Readback verified ${esc(stamp(item.verified_at))}</span>` : ''}${jobs.length ? `<span>Native job ${esc(jobs.join(', '))}</span>` : ''}</div></div>`;
  }
  function assetCard(row) {
    const data = row.telemetry, analysis = data?.analysis, latest = analysis?.latest || {};
    const good = Boolean(data?.snapshot_id), open = row.open_case_id;
    const status = analysis?.status || 'insufficient';
    const observedAt = latest.timestamp || data?.observed_at || data?.samples?.at(-1)?.timestamp;
    const summary = analysis?.summary ? 'At that observation: ' + analysis.summary.replace(/\bcurrent\b/gi,'observed') : 'Start the synthetic source to acquire, submit and read back a sensor window through KD.';
    return `<article class="mc-asset mc-${tone(status)}"><header><div><span class="mc-overline">${esc(row.asset_id === 'A-17' ? 'PRIMARY ASSET' : 'COMPARISON ASSET')}</span><h3>${esc(row.asset_id)} <span>Auxiliary cooling pump</span></h3></div></header><div class="mc-verified-window"><div><span class="mc-overline">Last verified in KD</span><strong>${data ? 'Observed ' + esc(stamp(observedAt)) : 'No verified observation yet'}</strong><small>${data ? num(data.samples?.length,0) + ' readings in this window · condition at that observation' : 'Condition and metrics are not yet available'}</small></div>${data ? chip(statusNames[status] || 'Reliable readings needed',status) : chip('Awaiting verified readings','idle')}</div>${delivery(row)}<div class="mc-asset-condition"><strong>${esc(analysis?.title || 'Waiting for a verified window')}</strong><p>${esc(summary)}</p></div><div class="mc-asset-numbers"><div><small>Vibration</small><strong>${num(latest.vibration_mm_s,2)}<em>mm/s</em></strong></div><div><small>Temperature</small><strong>${num(latest.temperature_c)}<em>°C</em></strong></div><div><small>Pressure</small><strong>${num(latest.pressure_bar,2)}<em>bar</em></strong></div></div>${spark(data?.samples)}<div class="mc-acquisition-line"><span>Local acquisition · ${num(row.acquired_samples,0)} samples <em>${esc(state.mission?.run?.state === 'paused' ? 'Paused' : row.source_silent ? 'Source silent' : row.acquired_samples ? 'Acquiring' : 'Not started')}</em></span><small>Latest acquired ${esc(stamp(row.last_observed_at))}</small><small>Acquisition history is separate from the verified KD window above.</small></div><footer>${open ? `<button class="button primary" data-open-case="${esc(open)}">Continue case ${icons.arrow}</button>` : `<button class="button secondary" data-new-case="${esc(row.asset_id)}" ${good ? '' : 'disabled'}>Capture a case ${icons.plus}</button>`}<span class="mc-origin">${data ? data.synthetic ? 'Synthetic · via KD' : 'Source-reported measurements' : 'No verified condition'}</span></footer></article>`;
  }
  function renderMission() {
    const mission = state.mission, run = mission?.run || {}, status = run.state || 'idle';
    $('missionRunName').textContent = runNames[status] || status;
    $('missionRunName').dataset.state = tone(status);
    $('missionRunCopy').textContent = run.message || (mission?.available === false ? mission.message : {idle:'Start a labeled synthetic source. Conditions appear only after its submitted windows are verified through KD.',paused:'Acquisition is paused. Submitted windows can still finish the normal KD commit and readback cycle.',running:'Acquiring synthetic readings and publishing bounded windows. Follow each submission through to verified KD readback.'}[status]) || mission?.message || 'Read the retained acquisition and KD delivery state below.';
    $('missionRunMeta').textContent = run.timing_label || (run.interval_seconds ? `One simulated step every ${run.interval_seconds} seconds · demonstration timing` : 'Continuous synthetic acquisition · fixed fictional assets');
    $('missionSourceName').textContent = run.source_id || 'Source assigned when the run begins';
    $('missionRunId').textContent = run.id || run.run_id || 'No run started';
    $('missionStep').textContent = Number.isFinite(run.step) && run.step >= 0 ? String(run.step) : '—';
    $('missionLastRefresh').textContent = state.error ? 'Refresh failed · showing retained state' : 'State checked ' + stamp(state.lastFetched);
    const hasState = Boolean(mission) && mission.available !== false && !state.error;
    const actions = {start:['idle','completed','stopped','paused'].includes(status),pause:status === 'running',resume:status === 'paused'};
    $('missionStart').innerHTML = (status === 'paused' ? 'New episode ' : 'Start source ') + icons.arrow;
    Object.entries(actions).forEach(([action,allowed]) => {
      const button = $('mission' + action[0].toUpperCase() + action.slice(1));
      button.hidden = !allowed; button.dataset.unavailable = String(!hasState || !allowed); button.disabled = state.busy || !hasState || !allowed;
    });
    $('missionScenario').disabled = state.busy || !actions.start;
    $('missionEpisodeNote').hidden = status !== 'paused';
    $('missionRunError').textContent = run.last_error || '';
    $('missionRunError').hidden = !run.last_error;
    const rows = Array.isArray(mission?.assets) ? mission.assets.filter(row => ['A-17','A-18'].includes(row.asset_id)) : [];
    paint('missionAssets',rows.length ? rows.map(assetCard).join('') : empty('Waiting for source state',state.error || 'The server has not returned an asset inventory. No connection or condition is assumed.'));
    const counts = mission?.case_counts || {};
    $('missionOpenCount').textContent = num(counts.open ?? state.cases.filter(item => item.status === 'open').length,0);
    $('missionReviewedCount').textContent = num(counts.reviewed ?? state.cases.filter(item => item.status === 'reviewed').length,0);
    $('missionClosedCount').textContent = num(counts.closed ?? state.cases.filter(item => item.status === 'closed').length,0);
    $('missionCaseCount').textContent = String(state.cases.filter(item => item.status !== 'closed').length);
    paint('missionRecentCases',state.cases.length ? [...state.cases].sort((a,b) => String(b.updated_at).localeCompare(String(a.updated_at))).slice(0,4).map(item => caseRow(item)).join('') : empty('The next signal starts a story','A persistent condition can open a case. You can also capture a verified condition for explicit review.'));
    buttonBusy(state.busy);
  }
  function caseRow(item) {
    return `<button class="mc-case-row ${state.selectedId === item.id ? 'active' : ''}" data-open-case="${esc(item.id)}" ${state.selectedId === item.id ? 'aria-current="true"' : ''}><span class="mc-case-marker">${icons.case}</span><span class="mc-case-row-main"><small>${esc(item.asset_id)} <span>· ${esc(item.id)}</span></small><strong>${esc(item.title || 'Equipment condition review')}</strong><span>${esc(item.summary || item.reviewer_role || 'Captured condition awaiting review')}</span><time>${esc(stamp(item.updated_at || item.created_at))}</time></span>${chip(statusNames[item.status] || item.status,item.status)}</button>`;
  }
  function renderCaseList() {
    const cases = state.cases.filter(item => state.filter === 'all' || item.status === state.filter);
    paint('caseList',cases.length ? cases.map(caseRow).join('') : empty('No cases in this view',state.filter === 'all' ? 'Capture a verified condition from Mission control to begin a durable review.' : 'Choose another status to see more cases.'));
    $('caseListCount').textContent = String(cases.length);
    $('missionCaseCount').textContent = String(state.cases.filter(item => item.status !== 'closed').length);
  }
  function conditionCard(data,label,captured) {
    if (!data?.analysis) return `<article class="mc-condition-card"><span class="mc-overline">${esc(label)}</span><h3>Readings unavailable</h3><p>${captured ? 'This case has no captured condition in the response.' : 'The preserved case remains available when the current source cannot be read.'}</p></article>`;
    const analysis = data.analysis, latest = analysis.latest || {}, provenance = data.source?.provenance || data.provenance || {};
    return `<article class="mc-condition-card ${captured ? 'mc-captured' : ''}"><div class="mc-card-heading"><span class="mc-overline">${esc(label)}</span>${chip(statusNames[analysis.status] || analysis.status,analysis.status)}</div><h3>${esc(analysis.title)}</h3><p>${esc(stamp(latest.timestamp || data.samples?.at(-1)?.timestamp))}</p><div class="mc-compare-values"><span><strong>${num(latest.vibration_mm_s,2)}</strong>mm/s vibration</span><span><strong>${num(latest.temperature_c)}</strong>°C temperature</span><span><strong>${num(latest.pressure_bar,2)}</strong>bar pressure</span></div><small>${analysis.forecast?.available ? `${num(analysis.forecast.minutes_to_review)} minutes to the illustrative review threshold` : esc(analysis.forecast?.reason || 'No threshold projection available')}</small><details class="mc-provenance"><summary>${captured ? 'Preserved condition identity' : 'Latest source identity'}</summary><dl><dt>Origin</dt><dd>${data.synthetic ? 'Synthetic demonstration' : 'Source-reported measurements'}</dd><dt>Model</dt><dd>${esc(analysis.model_version)}</dd><dt>Reference</dt><dd>${esc(provenance.reference || data.source?.source_id || 'Replay generated by the application')}</dd><dt>Snapshot</dt><dd>${esc(data.snapshot_id || provenance.payload_sha256 || 'Not supplied')}</dd><dt>Retrieved</dt><dd>${esc(stamp(provenance.retrieved_at))}</dd></dl></details></article>`;
  }
  function renderCase() {
    const data = state.caseData;
    if (!data) return;
    const review = data.review, closed = data.status === 'closed', followUps = data.follow_ups || [], selection = selected();
    const evidence = data.evidence || [], capture = data.captured?.condition || data.captured;
    const canClose = Boolean(review?.findings && followUps.length);
    $('caseDetail').innerHTML = `<div id="caseDetailBody"><header class="mc-case-heading"><div><span class="mc-overline">${esc(data.asset_id)} · ${esc(data.id)}</span><h2>${esc(data.title || 'Equipment condition review')}</h2><p>Opened ${esc(stamp(data.created_at))}</p></div>${chip(statusNames[data.status] || data.status,data.status)}</header><div class="mc-case-tools"><a class="button secondary" href="/api/cases/${encodeURIComponent(data.id)}/export" download>${icons.download} Export case brief</a><button class="text-button" data-case-action="refresh">Refresh case ${icons.refresh}</button><small id="caseServerStatus">Server-stored case · ${esc(stamp(data.updated_at))}</small></div><ol class="mc-case-progress" aria-label="Case progress">${[['Capture',true],['Evidence',evidence.length > 0],['Review',Boolean(review)],['Follow-up',followUps.length > 0],['Outcome',closed]].map(([label,done],index)=>`<li class="${done ? 'complete' : ''}"><span>${done ? icons.check : index+1}</span>${label}</li>`).join('')}</ol><div class="mc-condition-compare"><div>${conditionCard(capture,'Captured with this case',true)}</div><div id="caseLatest">${conditionCard(latestFor(data),'Latest available',false)}</div></div><p class="mc-preservation-note">${icons.clock} The captured window stays fixed as new readings arrive. Later observations do not, by themselves, establish a cause or repair success.</p><div class="mc-case-columns"><div class="mc-case-work"><section class="mc-panel"><div class="mc-card-heading"><div><span class="mc-overline">01 · EVIDENCE</span><h3>Keep the source with the finding.</h3></div><span class="mc-count">${evidence.length}</span></div>${evidence.length ? `<div class="mc-case-evidence">${evidence.map(record => `<a href="/sources/${encodeURIComponent(record.id)}" target="_blank" rel="noopener"><span>${esc(record.id)}</span><strong>${esc(record.title || record.reference)}</strong>${icons.arrow}</a>`).join('')}</div>` : `<p class="mc-muted">No evidence captured yet. Find sources, select them in the evidence library, then save them with a review.</p>`}<button class="text-button" data-case-action="evidence">Find supporting evidence ${icons.arrow}</button>${data.notes ? `<div class="mc-saved-note"><small>Captured planner notes</small><p>${esc(data.notes)}</p></div>` : ''}</section><section class="mc-panel"><span class="mc-overline">02 · HUMAN REVIEW</span><h3>${review ? 'A finding, with its reasoning.' : 'What does the evidence support?'}</h3>${review ? `<div class="mc-recorded-review"><div>${chip(review.reviewer_role || 'Review role','reviewed')}<time>${esc(stamp(review.at || review.created_at))}</time></div><h4>Finding</h4><p>${esc(review.findings)}</p><h4>Reviewed action</h4><p>${esc(review.action)}</p>${review.notes ? `<h4>Captured planner notes</h4><p>${esc(review.notes)}</p>` : ''}</div>` : ''}${closed ? '' : `<details class="mc-review-form" ${review ? '' : 'open'}><summary>${review ? 'Record another review' : 'Record your review'}</summary><form id="caseReviewForm"><label for="caseReviewerRole">Demonstration reviewer role</label><input id="caseReviewerRole" name="reviewer_role" maxlength="100" required placeholder="e.g. Maintenance planner" value="${esc(review?.reviewer_role || '')}"><small>A role label does not establish authenticated identity or permissions.</small><label for="caseFindings">Evidence-based finding</label><textarea id="caseFindings" name="findings" maxlength="8000" rows="4" required placeholder="What did you observe, which evidence supports it, and what remains uncertain?"></textarea><label for="caseAction">Reviewed action</label><textarea id="caseAction" name="action" maxlength="4000" rows="3" required placeholder="Record the proposed review or inspection action. This does not send a work order or control equipment."></textarea><label class="mc-check-row"><input type="checkbox" name="attach" checked><span>Capture current workspace selection <strong id="caseSelectionCount">(${selection.ids.length} sources)</strong> and planner notes</span></label><p class="mc-form-help">At least one verified evidence source is required. The server preserves source content when this review is saved.</p><button class="button primary" data-case-action="review" type="submit">Save review ${icons.check}</button></form></details>`}</section><section class="mc-panel"><span class="mc-overline">03 · FOLLOW-UP</span><h3>Capture what happens next.</h3><p class="mc-muted">An explicit follow-up preserves the latest verified window with this case. Existing captures stay unchanged.</p>${followUps.length ? `<div class="mc-follow-list">${followUps.map((item,index) => `<details><summary><span>${icons.clock} Follow-up ${index+1}</span><time>${esc(stamp(item.captured_at || item.at))}</time></summary><p>${esc(item.notes || 'No additional note recorded.')}</p>${conditionCard(item.condition || item.snapshot,'Follow-up condition',true)}</details>`).join('')}</div>` : ''}${closed ? '' : `<form id="caseFollowForm">${capture?.source?.through_kd === false ? '<p class="mc-form-help">Select a later replay condition with Add condition to packet, then return here to capture it.</p>' : ''}<label for="caseFollowNotes">Follow-up observations</label><textarea id="caseFollowNotes" name="notes" maxlength="4000" rows="3" placeholder="Describe the new observations and remaining uncertainty."></textarea><button class="button secondary" data-case-action="follow-up" type="submit" data-unavailable="${!review}" ${review ? '' : 'disabled'}>Capture latest follow-up ${icons.plus}</button></form><details class="mc-simulation-control"><summary>Direct the synthetic scenario</summary><p>These controls change the fictional readings. They do not execute the reviewed action or demonstrate a real repair.</p><div><label for="caseOutcomeScenario">Simulated follow-up</label><select id="caseOutcomeScenario"><option value="recovery">Trend eases</option><option value="persistent">Change persists</option><option value="inconclusive">Uncertain readings</option></select><button type="button" class="button secondary" data-case-action="scenario" data-unavailable="${!(capture?.synthetic && capture?.source?.through_kd && data.source_id === state.mission?.run?.source_id && ['running','paused'].includes(state.mission?.run?.state))}">Apply to synthetic source</button></div></details>`}</section><section class="mc-panel mc-close-panel"><span class="mc-overline">04 · RECORDED OUTCOME</span><h3>${closed ? 'The episode is retained.' : 'Close with a clear disposition.'}</h3>${closed ? `<div class="mc-recorded-review">${chip({resolved:'Resolved in the demonstration',monitor:'Continue monitoring',inconclusive:'Inconclusive'}[data.closure?.disposition] || data.closure?.disposition,'closed')}<p>${esc(data.closure?.notes)}</p><small>${esc(stamp(data.closure?.at || data.closed_at))}</small></div>` : `<p class="mc-muted">Closure requires a saved finding and at least one later follow-up. It records a reviewer disposition, not an equipment readiness determination.</p><form id="caseCloseForm"><label for="caseDisposition">Disposition</label><select id="caseDisposition" name="disposition"><option value="resolved">Resolved in the demonstration</option><option value="monitor">Continue monitoring</option><option value="inconclusive">Inconclusive</option></select><label for="caseCloseNotes">Basis for this disposition</label><textarea id="caseCloseNotes" name="notes" maxlength="4000" rows="3" required placeholder="Connect your finding and follow-up observations; retain uncertainty."></textarea><button class="button primary" data-case-action="close" data-unavailable="${!canClose}" ${canClose ? '' : 'disabled'}>Record outcome & close ${icons.check}</button>${canClose ? '' : '<small class="mc-form-help">Save a review and capture a follow-up to enable closure.</small>'}</form>`}</section></div><aside class="mc-case-timeline"><span class="mc-overline">EPISODE HISTORY</span><h3>The record of this review.</h3><ol>${(data.timeline || []).map((event,index) => `<li><span class="mc-timeline-node">${index === 0 ? icons.signal : icons.check}</span><div><time>${esc(stamp(event.at))}</time><strong>${esc(event.title || event.type)}</strong><p>${esc(event.detail || '')}</p></div></li>`).join('') || '<li><p>No timeline entries were returned.</p></li>'}</ol><p class="mc-timeline-note">Server-retained demonstration history. Role labels are not an authenticated audit trail.</p></aside></div></div>`;
    document.querySelectorAll('#caseDetail form').forEach(form => { const message=document.createElement('p'); message.className='mc-field-error'; message.setAttribute('role','alert'); form.append(message); });
    buttonBusy(state.busy);
  }
  function openCreate(assetId) {
    const row = assetRow(assetId), selection = selected();
    $('caseCreateAsset').value = assetId || fleet.getAssetId();
    $('caseCreateTitle').value = `${assetId || fleet.getAssetId()} condition review`;
    $('caseCreateNotes').value = selection.notes;
    $('caseCreateSelection').textContent = `${selection.ids.length} currently selected evidence sources will be verified and captured.`;
    $('caseCreateError').textContent = '';
    const replay = selection.condition?.mode === 'simulation' && selection.condition.asset_id === (assetId || fleet.getAssetId());
    $('caseCreateOrigin').innerHTML = `<option value="kd">Latest verified KD window${row?.source_id ? ' · ' + esc(row.source_id) : ''}</option>${replay ? '<option value="selection">Selected replay condition</option>' : ''}`;
    $('caseCreateOrigin').value = !row?.telemetry && replay ? 'selection' : 'kd';
    $('caseCreateDialog').showModal(); $('caseCreateTitle').focus();
  }
  async function createCase(event) {
    event.preventDefault(); if (state.busy) return;
    const assetId = $('caseCreateAsset').value, row = assetRow(assetId), selection = selected();
    const fromSelection = $('caseCreateOrigin').value === 'selection';
    const condition = fromSelection ? selection.condition : {mode:'kd',asset_id:assetId,source_id:row?.source_id || state.mission?.run?.source_id,snapshot_id:row?.telemetry?.snapshot_id};
    if (!condition || (!fromSelection && !condition.source_id)) { $('caseCreateError').textContent = 'No verified source is selected. Start acquisition or capture a replay condition from Equipment condition.'; return; }
    buttonBusy(true); $('caseCreateError').textContent = '';
    try {
      const result = unwrap(await api('/api/cases',{asset_id:assetId,source_id:condition.source_id || '',condition,snapshot_id:condition.snapshot_id,title:$('caseCreateTitle').value,notes:$('caseCreateNotes').value,ids:selection.ids}));
      $('caseCreateDialog').close(); state.selectedId = result.id; state.caseData = result;
      fleet.showView('cases'); renderCase(); await refresh(true); flash(result.evidence?.length ? 'Case saved with its verified condition and evidence.' : 'Case saved with its preserved condition. Attach evidence when you record a review.');
    } catch (error) { $('caseCreateError').textContent = error.message; }
    finally { buttonBusy(false); }
  }
  async function missionAction(action) {
    if (state.busy) return;
    buttonBusy(true); flash('');
    try {
      state.mission = await api('/api/mission/' + action,action === 'start' ? {scenario:$('missionScenario').value} : {});
      renderMission();
      await refresh(true); flash({start:'Source start requested. Delivery state will show verified KD progress.',pause:'Pause requested. Check the retained delivery state below.',resume:'Resume requested. Observations will advance after acquisition resumes.'}[action]);
    } catch (error) { flash(error.message,true); }
    finally { buttonBusy(false); }
  }
  async function caseAction(action,event) {
    const data = state.caseData;
    if (!data || state.busy) return;
    if (action === 'refresh') return loadCase(data.id);
    if (action === 'evidence') return fleet.searchEvidence((data.captured?.condition || data.captured)?.analysis?.evidence_query || 'pump vibration inspection maintenance',data.asset_id);
    const form = event?.target?.closest('form');
    if (form && !form.reportValidity()) return;
    if (form?.querySelector('[role=alert]')) form.querySelector('[role=alert]').textContent = '';
    let payload, path = '/api/cases/' + encodeURIComponent(data.id) + '/' + action;
    const values = form ? Object.fromEntries(new FormData(form)) : {};
    if (action === 'review') { const selection = selected(); payload = {reviewer_role:values.reviewer_role,findings:values.findings,action:values.action,ids:values.attach ? selection.ids : [],notes:values.attach ? selection.notes : ''}; }
    else if (action === 'follow-up') { const descriptor = selected().condition; payload = data.captured?.source?.through_kd === false && descriptor?.mode === 'simulation' && descriptor.asset_id === data.asset_id ? {notes:values.notes,condition:descriptor,snapshot_id:descriptor.snapshot_id} : {notes:values.notes,snapshot_id:latestFor(data)?.snapshot_id}; }
    else if (action === 'close') payload = {disposition:values.disposition,notes:values.notes};
    else if (action === 'scenario') { path = '/api/mission/outcome'; payload = {asset_id:data.asset_id,outcome:$('caseOutcomeScenario').value}; }
    else return;
    buttonBusy(true); flash('');
    try {
      const result = await api(path,payload);
      if (action !== 'scenario') { state.caseData = unwrap(result); renderCase(); }
      await refresh(true);
      flash({review:'Review and verified source content saved.', 'follow-up':'Follow-up condition preserved with this case.',close:'Disposition saved. The complete episode remains available.',scenario:'Synthetic scenario change requested. Wait for verified new readings before capturing a follow-up.'}[action]);
    } catch (error) { flash(error.message,true); if (form?.querySelector('[role=alert]')) { form.querySelector('[role=alert]').textContent=error.message; form.querySelector('[role=alert]').scrollIntoView({block:'nearest',behavior:'instant'}); } }
    finally { buttonBusy(false); }
  }
  function mount() {
    $('missionView').innerHTML = `<div id="missionMessage" class="mc-message" role="status" hidden></div><section class="mc-run-console"><div class="mc-console-main"><div class="mc-console-top"><span class="mc-dark-kicker">SYNTHETIC SOURCE · KNOWLEDGE DISCOVERY</span><span class="mc-run-state" id="missionRunName">Checking source state</span></div><h2>A maintenance story,<br>as it happens.</h2><p id="missionRunCopy">Reading the server's acquisition and delivery state.</p><div class="mc-run-controls"><label for="missionScenario" class="sr-only">A-17 synthetic scenario</label><select id="missionScenario"><option value="degradation">A-17 · Persistent change</option><option value="normal">A-17 · Steady operation</option><option value="load_change">A-17 · Load change</option><option value="sensor_gap">A-17 · Missing readings</option></select><button id="missionStart" class="button" data-mission-action="start" disabled>Start source ${icons.arrow}</button><button id="missionPause" class="button" data-mission-action="pause" hidden>Pause source</button><button id="missionResume" class="button" data-mission-action="resume" hidden>Resume source ${icons.arrow}</button></div><small id="missionRunMeta"></small><small id="missionEpisodeNote" hidden>A new episode preserves earlier readings and cases. Resume continues the current episode. Pending KD delivery must finish before a new episode can start.</small><p id="missionRunError" class="mc-run-error" hidden></p></div><div class="mc-console-visual" aria-hidden="true"><div class="mc-radar"><span class="mc-radar-ring"></span><span class="mc-radar-ring"></span><span class="mc-radar-ring"></span><div class="mc-radar-core">${icons.signal}</div><span class="mc-radar-asset a17">A-17</span><span class="mc-radar-asset a18">A-18</span></div></div><div class="mc-console-footer"><div><span>Source</span><strong id="missionSourceName">Not yet assigned</strong></div><div><span>Acquired step · continuous run</span><strong id="missionStep">—</strong></div><div><span>Run identity</span><strong id="missionRunId">No run started</strong></div></div></section><ol class="mc-flow" aria-label="Maintenance episode workflow">${[['Signal','Verified readings',icons.signal],['Case','Preserved condition',icons.case],['Evidence','Source context',icons.case],['Review','Recorded finding',icons.check],['Outcome','Follow-up & disposition',icons.clock]].map(([label,detail,mark],index)=>`<li><span class="mc-flow-icon">${mark}</span><div><small>0${index+1}</small><strong>${label}</strong><span>${detail}</span></div></li>`).join('')}</ol><div class="mc-section-heading"><div><span class="mc-overline">TWO ASSETS · ONE WORKFLOW</span><h2>What needs a closer look?</h2></div><button id="missionRefresh" class="text-button">Refresh state ${icons.refresh}</button></div><p id="missionLastRefresh" class="mc-refresh-stamp" role="status">Waiting for the server</p><div id="missionAssets" class="mc-assets">${empty('Checking the source','Reading actual acquisition, submission and verified-readback state.')}</div><div class="mc-bottom-grid"><section class="mc-panel mc-recent"><div class="mc-card-heading"><div><span class="mc-overline">MAINTENANCE CASES</span><h3>Keep the episode together.</h3></div><button class="text-button" data-view="cases">All cases ${icons.arrow}</button></div><div id="missionRecentCases"></div></section><aside class="mc-case-summary"><span class="mc-overline">REVIEW WORKLOAD</span><h3>From a signal<br>to a recorded outcome.</h3><dl><div><dt>Open for review</dt><dd id="missionOpenCount">—</dd></div><div><dt>Review recorded</dt><dd id="missionReviewedCount">—</dd></div><div><dt>Closed episodes</dt><dd id="missionClosedCount">—</dd></div></dl><p>Case counts describe this synthetic demonstration. They are not fleet readiness or maintenance performance metrics.</p></aside></div>`;
    $('casesView').innerHTML = `<div id="caseMessage" class="mc-message" role="status" hidden></div><div class="mc-cases-layout"><aside class="mc-case-browser"><div class="mc-card-heading"><h2>Cases <span id="caseListCount" class="mc-count">0</span></h2><button class="icon-button" id="caseNew" aria-label="Capture a new maintenance case">${icons.plus}</button></div><label class="sr-only" for="caseFilter">Filter cases by status</label><select id="caseFilter"><option value="all">All episodes</option><option value="open">Open for review</option><option value="reviewed">Review recorded</option><option value="closed">Closed</option></select><div id="caseList">${empty('Loading cases','Reading saved episodes from the server.')}</div><p class="mc-storage-note">${icons.clock} Cases persist on the server, independently of this browser's packet selection.</p></aside><section id="caseDetail" aria-label="Selected maintenance case">${empty('Choose an episode to review','The captured condition, source evidence, review and follow-up stay together here.')}</section></div>`;
    const dialog = document.createElement('dialog'); dialog.id = 'caseCreateDialog'; dialog.className = 'mc-dialog'; dialog.setAttribute('aria-labelledby','caseCreateHeading');
    dialog.innerHTML = `<div class="dialog-heading"><span class="mc-overline">NEW MAINTENANCE CASE</span><button type="button" class="icon-button" id="caseCreateCancel" aria-label="Cancel new case">×</button></div><h2 id="caseCreateHeading">Preserve the starting point.</h2><p>The server verifies and saves this condition with the selected source content. New readings cannot replace the captured window.</p><form id="caseCreateForm"><label for="caseCreateAsset">Equipment</label><select id="caseCreateAsset"><option>A-17</option><option>A-18</option></select><label for="caseCreateOrigin">Condition to capture</label><select id="caseCreateOrigin"><option value="kd">Latest verified KD window</option></select><label for="caseCreateTitle">Case title</label><input id="caseCreateTitle" maxlength="160" required><label for="caseCreateNotes">Planner observations</label><textarea id="caseCreateNotes" rows="3" maxlength="12000"></textarea><p id="caseCreateSelection" class="mc-form-help"></p><p id="caseCreateError" class="mc-field-error" role="alert"></p><button id="caseCreateSubmit" class="button primary">Capture case ${icons.plus}</button></form>`;
    document.body.append(dialog);
    $('caseCreateCancel').addEventListener('click',() => dialog.close());
    $('caseCreateForm').addEventListener('submit',createCase);
    $('caseCreateAsset').addEventListener('change',() => { const id=$('caseCreateAsset').value, notes=$('caseCreateNotes').value; dialog.close(); openCreate(id); $('caseCreateNotes').value=notes; });
    $('caseNew').addEventListener('click',() => openCreate(fleet.getAssetId()));
    $('missionRefresh').addEventListener('click',() => refresh());
    $('caseFilter').addEventListener('change',event => { state.filter=event.target.value; renderCaseList(); });
    document.addEventListener('click',event => {
      const button = event.target.closest('[data-mission-action],[data-open-case],[data-new-case],[data-case-action]');
      if (!button || button.disabled) return;
      if (button.dataset.missionAction) missionAction(button.dataset.missionAction);
      else if (button.dataset.openCase) { fleet.showView('cases'); loadCase(button.dataset.openCase); }
      else if (button.dataset.newCase) openCreate(button.dataset.newCase);
      else if (button.dataset.caseAction && !button.closest('form')) caseAction(button.dataset.caseAction,event);
    });
    $('caseDetail').addEventListener('submit',event => { event.preventDefault(); const action={caseReviewForm:'review',caseFollowForm:'follow-up',caseCloseForm:'close'}[event.target.id]; if(action) caseAction(action,event); });
    window.addEventListener('fleet-view-changed',event => { flash(''); if (['mission','cases'].includes(event.detail.view)) refresh(true); else clearTimeout(timer); });
    document.addEventListener('visibilitychange',() => { if (!document.hidden && ['mission','cases'].includes(fleet.getView())) refresh(true); else clearTimeout(timer); });
    refresh();
  }
  mount();
})();
