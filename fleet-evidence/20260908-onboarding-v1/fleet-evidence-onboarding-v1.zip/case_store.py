"""Durable demo episodes. Stored captures are immutable; role labels are fictional."""
from contextlib import contextmanager
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
import uuid


def now():
    return datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00', 'Z')


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False)


def field(value, label, maximum=12000, required=False):
    if not isinstance(value, str) or len(value) > maximum or required and not value.strip():
        raise ValueError(f'{label} must be {"nonempty and " if required else ""}at most {maximum:,} characters.')
    return value.strip()


class CaseStore:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as db:
            db.execute('CREATE TABLE IF NOT EXISTS cases (id TEXT PRIMARY KEY, episode TEXT NOT NULL UNIQUE, asset TEXT NOT NULL, source TEXT NOT NULL, status TEXT NOT NULL, updated TEXT NOT NULL, body TEXT NOT NULL)')

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=15)
        try:
            db.execute('PRAGMA busy_timeout=15000')
            with db:
                yield db
        finally:
            db.close()

    @staticmethod
    def event(case, kind, title, detail='', at=None):
        case['timeline'].append({'id': uuid.uuid4().hex, 'at': at or now(), 'type': kind, 'title': title, 'detail': detail})
        case['updated_at'] = case['timeline'][-1]['at']

    def _read(self, db, ident):
        row = db.execute('SELECT body FROM cases WHERE id=?', (ident,)).fetchone()
        if row is None:
            raise KeyError('Maintenance case not found.')
        return json.loads(row[0])

    def _save(self, db, case):
        db.execute('UPDATE cases SET status=?,updated=?,body=? WHERE id=?', (case['status'], case['updated_at'], encode(case), case['id']))

    def get(self, ident):
        with self.connection() as db:
            return self._read(db, ident)

    def list(self):
        with self.connection() as db:
            return [json.loads(row[0]) for row in db.execute('SELECT body FROM cases ORDER BY updated DESC LIMIT 200')]

    def capture(self, snapshot, evidence=None, notes='', title='', episode=None):
        notes = field(notes, 'Notes')
        title = field(title, 'Case title', 160) or f"{snapshot['asset_id']} · {snapshot['analysis']['title']}"
        asset, source = snapshot['asset_id'], snapshot['source']['label']
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT body FROM cases WHERE episode=?', (episode,)).fetchone() if episode else db.execute("SELECT body FROM cases WHERE asset=? AND source=? AND status!='closed' ORDER BY updated DESC LIMIT 1", (asset, source)).fetchone()
            if row:
                case = json.loads(row[0])
                return case
            stamp, ident = now(), 'FE-' + uuid.uuid4().hex[:12].upper()
            case = {'id': ident, 'episode': episode or uuid.uuid4().hex, 'asset_id': asset, 'source_id': source,
                    'title': title, 'status': 'open', 'created_at': stamp, 'updated_at': stamp,
                    'summary': snapshot['analysis']['summary'], 'captured': snapshot, 'evidence': evidence or [],
                    'notes': notes, 'reviewer_role': '', 'review': None, 'follow_ups': [], 'closure': None,
                    'timeline': [], 'synthetic_demo': True, 'version': 1}
            self.event(case, 'opened', 'Condition captured for review', snapshot['analysis']['summary'], stamp)
            if evidence:
                self.event(case, 'evidence', 'Supporting evidence captured', ', '.join(r['id'] for r in evidence))
            db.execute('INSERT INTO cases VALUES (?,?,?,?,?,?,?)', (ident, case['episode'], asset, source, 'open', case['updated_at'], encode(case)))
            return case

    def review(self, ident, data, evidence):
        review = {'reviewer_role': field(data.get('reviewer_role', ''), 'Fictional reviewer role', 100, True),
                  'findings': field(data.get('findings', ''), 'Inspection findings', required=True),
                  'action': field(data.get('action', ''), 'Reviewed action', required=True),
                  'notes': field(data.get('notes', ''), 'Captured planner notes'), 'at': now()}
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            case = self._read(db, ident)
            if case['status'] == 'closed':
                raise ValueError('This case is closed. Its captured review remains available.')
            if not evidence and not case['evidence']:
                raise ValueError('Select at least one verified evidence source before saving the review.')
            for record in evidence:
                if record['id'] not in {r['id'] for r in case['evidence']}:
                    case['evidence'].append(record)
                    self.event(case, 'evidence', 'Supporting evidence captured', record['id'] + ' · ' + record['title'])
            case['review'], case['reviewer_role'], case['status'] = review, review['reviewer_role'], 'reviewed'
            self.event(case, 'review', 'Review recorded · ' + review['reviewer_role'], review['findings'] + '\nReviewed action: ' + review['action'] + ('\nPlanner notes: ' + review['notes'] if review['notes'] else ''), review['at'])
            case['version'] += 1
            self._save(db, case)
            return case

    def observe(self, episode, snapshot, publication_id):
        """Retain meaningful condition transitions without one case per sample."""
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT body FROM cases WHERE episode=?', (episode,)).fetchone()
            if not row:
                return
            case = json.loads(row[0])
            if case['status'] == 'closed':
                return
            observations = case.setdefault('observations', [])
            prior = observations[-1]['condition'] if observations else case['captured']
            if (prior['analysis']['status'] == snapshot['analysis']['status']
                    or prior['snapshot_id'] == snapshot['snapshot_id']
                    or datetime.fromisoformat(snapshot['observed_at'].replace('Z', '+00:00')) <= datetime.fromisoformat(prior['observed_at'].replace('Z', '+00:00'))):
                return
            if case['asset_id'] != snapshot['asset_id'] or case['source_id'] != snapshot['source']['label']:
                raise ValueError('A condition transition must belong to this case source.')
            observations.append({'publication_id': publication_id, 'captured_at': now(), 'condition': snapshot})
            self.event(case, 'condition', 'Verified condition changed · ' + snapshot['analysis']['title'], snapshot['analysis']['summary'])
            case['version'] += 1
            self._save(db, case)

    def follow_up(self, ident, snapshot, notes=''):
        notes = field(notes, 'Follow-up notes')
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            case = self._read(db, ident)
            if case['status'] != 'reviewed':
                raise ValueError('Record a review before attaching follow-up observations.')
            if snapshot['asset_id'] != case['asset_id'] or snapshot['source']['label'] != case['source_id']:
                raise ValueError('Follow-up must use the same equipment and source as this case.')
            prior = case['follow_ups'][-1]['condition'] if case['follow_ups'] else case['captured']
            stamp = lambda s: datetime.fromisoformat(s.replace('Z', '+00:00'))
            if snapshot['snapshot_id'] == prior['snapshot_id'] or stamp(snapshot['observed_at']) <= stamp(prior['observed_at']):
                raise ValueError('A follow-up requires a later observation window.')
            captured_at = now()
            item = {'id': uuid.uuid4().hex, 'captured_at': captured_at, 'condition': snapshot, 'notes': notes}
            case['follow_ups'].append(item)
            self.event(case, 'follow_up', 'Follow-up observations captured', snapshot['analysis']['summary'] + ('\n' + notes if notes else ''), captured_at)
            case['version'] += 1
            self._save(db, case)
            return case

    def close(self, ident, data):
        disposition = data.get('disposition')
        if disposition not in {'resolved', 'monitor', 'inconclusive'}:
            raise ValueError('Choose resolved, monitor or inconclusive as the reviewed disposition.')
        notes = field(data.get('notes', ''), 'Disposition rationale', required=True)
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            case = self._read(db, ident)
            if case['status'] != 'reviewed' or not case['follow_ups']:
                raise ValueError('A recorded review and later follow-up are required before closing the episode.')
            case['closure'] = {'disposition': disposition, 'notes': notes, 'at': now()}
            case['status'] = 'closed'
            self.event(case, 'closed', 'Episode closed · ' + disposition, notes, case['closure']['at'])
            case['version'] += 1
            self._save(db, case)
            return case
