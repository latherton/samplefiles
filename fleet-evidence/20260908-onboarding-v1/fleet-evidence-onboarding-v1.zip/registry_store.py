"""Persistent equipment identity, explicit part applicability, and item history.

This is application-owned inventory bookkeeping. A catalog entry or recorded
installation does not establish engineering approval, KD delivery, or condition.
"""
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import re
import sqlite3
import uuid


IDENTIFIER = re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}')
REFERENCE = re.compile(r'(?:[A-Za-z0-9][A-Za-z0-9_-]{0,79}|urn:[A-Za-z0-9][A-Za-z0-9:._-]{0,239})')


def now():
    return datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00', 'Z')


def text(value, label, maximum=160, required=False):
    if not isinstance(value, str) or len(value) > maximum or required and not value.strip():
        raise ValueError(f'{label} must be {"nonempty and " if required else ""}at most {maximum} characters.')
    if any(ord(c) < 32 and c not in '\n\t' for c in value):
        raise ValueError(f'{label} contains control characters.')
    return value.strip()


def identifier(value, label='Identifier'):
    value = text(value, label, 80, True)
    if not IDENTIFIER.fullmatch(value):
        raise ValueError(f'{label} must contain letters, digits, underscores or hyphens.')
    return value


def event_date(value=None):
    value = now() if value is None or value == '' else text(value, 'Event date', 40, True)
    try:
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
            stamp = datetime.fromisoformat(value).replace(tzinfo=timezone.utc)
        else:
            stamp = datetime.fromisoformat(value.replace('Z', '+00:00'))
            if stamp.tzinfo is None or stamp.utcoffset() is None:
                raise ValueError()
        stamp = stamp.astimezone(timezone.utc)
    except (ValueError, OverflowError):
        raise ValueError('Event date must be a calendar date or an ISO timestamp with a timezone.') from None
    if stamp.year < 1900 or stamp > datetime.now(timezone.utc) + timedelta(minutes=5):
        raise ValueError('An installation or removal date must be historical, from 1900 through now.')
    return stamp.isoformat(timespec='microseconds').replace('+00:00', 'Z')


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False)


def identity(data):
    result = {k: text(data.get(k, ''), k.capitalize(), 100, True) for k in ('model', 'configuration')}
    if any(v.lower() in {'all', 'unknown', '*'} for v in result.values()):
        raise ValueError('Provide an explicit model and configuration; compatibility is not inferred.')
    return result


class RegistryStore:
    def __init__(self, path, seed_assets=None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS equipment (id TEXT PRIMARY KEY COLLATE NOCASE, body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS catalog_parts (
                    id TEXT PRIMARY KEY COLLATE NOCASE, manufacturer_key TEXT NOT NULL,
                    number_key TEXT NOT NULL, body TEXT NOT NULL, UNIQUE(manufacturer_key, number_key));
                CREATE TABLE IF NOT EXISTS installed_components (
                    id TEXT PRIMARY KEY COLLATE NOCASE, equipment_id TEXT NOT NULL REFERENCES equipment(id),
                    part_id TEXT NOT NULL REFERENCES catalog_parts(id), serial_key TEXT NOT NULL,
                    parent_id TEXT REFERENCES installed_components(id), removed_at TEXT, body TEXT NOT NULL);
                CREATE UNIQUE INDEX IF NOT EXISTS active_component_serial
                    ON installed_components(part_id, serial_key) WHERE removed_at IS NULL AND serial_key != '';
                CREATE TABLE IF NOT EXISTS spare_stock (
                    part_id TEXT NOT NULL REFERENCES catalog_parts(id), location_key TEXT NOT NULL,
                    body TEXT NOT NULL, PRIMARY KEY(part_id, location_key));
                CREATE TABLE IF NOT EXISTS equipment_events (
                    id TEXT PRIMARY KEY, equipment_id TEXT NOT NULL REFERENCES equipment(id),
                    at TEXT NOT NULL, body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS equipment_manuals (
                    id TEXT PRIMARY KEY, equipment_id TEXT NOT NULL REFERENCES equipment(id),
                    reference TEXT NOT NULL, body TEXT NOT NULL, UNIQUE(equipment_id, reference));
            ''')
            db.execute('BEGIN IMMEDIATE')
            if seed_assets is not None and not db.execute('SELECT 1 FROM equipment LIMIT 1').fetchone():
                assets = list(seed_assets.values()) if isinstance(seed_assets, dict) else list(seed_assets)
                fixtures = [
                    ('B-21', 'Ventilation fan B-21', 'VF-DEMO', 'fan'),
                    ('C-31', 'Air compressor C-31', 'AC-DEMO', 'compressor'),
                    ('D-41', 'Drive motor D-41', 'M-DEMO', 'motor'),
                    ('E-51', 'Heat exchanger E-51', 'HX-DEMO', 'heat_exchanger'),
                ]
                for ident, name, model, kind in fixtures:
                    if not any(a['id'].casefold() == ident.casefold() for a in assets):
                        assets.append({'id': ident, 'name': name, 'model': model, 'configuration': 'DEMO',
                                       'kind': kind, 'location': 'Fictional demonstration vessel',
                                       'description': 'Fictional registry example. No readings or condition assessment are available.'})
                for asset in assets:
                    self._save_equipment(db, dict(asset, synthetic_demo=True, kind=asset.get('kind', 'pump')))

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=15)
        try:
            db.execute('PRAGMA busy_timeout=15000')
            db.execute('PRAGMA foreign_keys=ON')
            with db:
                yield db
        except sqlite3.IntegrityError as exc:
            raise ValueError('This identifier, manufacturer/part number, reference, or installed serial already exists.') from exc
        finally:
            db.close()

    @staticmethod
    def _read(db, table, ident):
        # Table names come only from this module, never from request input.
        row = db.execute(f'SELECT body FROM {table} WHERE id=?', (ident,)).fetchone()
        if row is None:
            raise KeyError('Registry record not found.')
        return json.loads(row[0])

    @staticmethod
    def _rows(db, query, parameters=()):
        return [json.loads(row[0]) for row in db.execute(query, parameters)]

    @staticmethod
    def _version(db, table, data):
        row = db.execute(f'SELECT body FROM {table} WHERE id=?', (data['id'],)).fetchone()
        previous = json.loads(row[0]) if row else None
        if previous:
            if type(data.get('version')) is not int or data['version'] != previous['version']:
                raise ValueError('This identifier already exists or the record changed. Reload it before editing.')
            if data['id'] != previous['id']:
                raise ValueError('An existing identifier cannot be renamed or have its letter case changed.')
        elif data.get('version') is not None:
            raise ValueError('Cannot update a record that does not exist.')
        return previous

    @staticmethod
    def _event(db, equipment_id, kind, at, detail, **extra):
        item = dict(id='EV-' + uuid.uuid4().hex[:16].upper(), equipment_id=equipment_id,
                    type=kind, at=at, recorded_at=now(), detail=detail, **extra)
        db.execute('INSERT INTO equipment_events VALUES (?,?,?,?)', (item['id'], equipment_id, at, encode(item)))
        return item

    def _save_equipment(self, db, data):
        if not isinstance(data, dict):
            raise ValueError('Equipment must be an object.')
        ident = identifier(data.get('id'), 'Equipment ID')
        previous = self._version(db, 'equipment', dict(data, id=ident))
        merged = dict(previous or {}, **data)
        item = dict(id=ident, **identity(merged))
        for key, maximum, required in [('name', 160, True), ('kind', 80, False), ('location', 200, False), ('description', 2000, False)]:
            item[key] = text(merged.get(key, ''), key.capitalize(), maximum, required)
        synthetic = merged.get('synthetic_demo', False)
        if type(synthetic) is not bool:
            raise ValueError('synthetic_demo must be true or false.')
        item.update(synthetic_demo=synthetic, created_at=previous['created_at'] if previous else now(),
                    updated_at=now(), version=previous['version'] + 1 if previous else 1)
        if previous and identity(previous) != identity(item):
            active = self._rows(db, 'SELECT body FROM installed_components WHERE equipment_id=? AND removed_at IS NULL', (ident,))
            if any(identity(item) not in c['part_snapshot']['applicability'] for c in active):
                raise ValueError('Remove incompatible installed components before changing equipment identity.')
        if previous:
            db.execute('UPDATE equipment SET body=? WHERE id=?', (encode(item), ident))
        else:
            db.execute('INSERT INTO equipment VALUES (?,?)', (ident, encode(item)))
        self._event(db, ident, 'equipment_updated' if previous else 'equipment_registered', item['updated_at'],
                    'Equipment metadata recorded.', previous_identity=identity(previous) if previous else None,
                    equipment_identity=identity(item))
        return item

    def save_equipment(self, data):
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            return self._save_equipment(db, data)

    def list_equipment(self):
        with self.connection() as db:
            rows = self._rows(db, 'SELECT body FROM equipment ORDER BY id COLLATE NOCASE')
            for item in rows:
                item['installed_quantity'] = db.execute('SELECT COUNT(*) FROM installed_components WHERE equipment_id=? AND removed_at IS NULL', (item['id'],)).fetchone()[0]
                item['manual_count'] = db.execute('SELECT COUNT(*) FROM equipment_manuals WHERE equipment_id=?', (item['id'],)).fetchone()[0]
            return rows

    def get_equipment(self, ident):
        with self.connection() as db:
            item = self._read(db, 'equipment', identifier(ident, 'Equipment ID'))
            ident = item['id']
            item['components'] = self._rows(db, 'SELECT body FROM installed_components WHERE equipment_id=? ORDER BY rowid', (ident,))
            item['installed_components'] = [c for c in item['components'] if c['removed_at'] is None]
            item['history'] = self._rows(db, 'SELECT body FROM equipment_events WHERE equipment_id=? ORDER BY at DESC, rowid DESC', (ident,))
            item['manuals'] = self._rows(db, 'SELECT body FROM equipment_manuals WHERE equipment_id=? ORDER BY rowid', (ident,))
            for manual in item['manuals']:
                manual['applies_to_current_identity'] = identity(manual) == identity(item)
            return item

    def save_part(self, data):
        if not isinstance(data, dict):
            raise ValueError('Part must be an object.')
        ident = identifier(data.get('id'), 'Part ID')
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            previous = self._version(db, 'catalog_parts', dict(data, id=ident))
            merged = dict(previous or {}, **data)
            item = {'id': ident}
            for key in ('name', 'manufacturer', 'part_number'):
                item[key] = text(merged.get(key, ''), key.replace('_', ' ').capitalize(), 160, True)
            nsn = text(merged.get('nsn', ''), 'NSN', 32).replace('-', '').replace(' ', '')
            if nsn and not re.fullmatch(r'\d{13}', nsn):
                raise ValueError('NSN must contain 13 digits when supplied.')
            item['nsn'] = nsn
            applies = merged.get('applicability', [])
            if not isinstance(applies, list) or len(applies) > 100 or any(not isinstance(a, dict) for a in applies):
                raise ValueError('Part applicability must be a list of at most 100 explicit model/configuration records.')
            item['applicability'] = []
            for rule in applies:
                rule = identity(rule)
                if rule in item['applicability']:
                    raise ValueError('Duplicate applicability record.')
                item['applicability'].append(rule)
            if previous and (item['manufacturer'], item['part_number']) != (previous['manufacturer'], previous['part_number']):
                raise ValueError('Manufacturer and part number define this catalog identity; register a new catalog part to change them.')
            item.update(created_at=previous['created_at'] if previous else now(), updated_at=now(),
                        version=previous['version'] + 1 if previous else 1)
            values = (item['manufacturer'].casefold(), item['part_number'].casefold(), encode(item))
            if previous:
                db.execute('UPDATE catalog_parts SET manufacturer_key=?,number_key=?,body=? WHERE id=?', (*values, ident))
            else:
                db.execute('INSERT INTO catalog_parts VALUES (?,?,?,?)', (ident, *values))
            return item

    def list_parts(self):
        with self.connection() as db:
            items = self._rows(db, 'SELECT body FROM catalog_parts ORDER BY id COLLATE NOCASE')
            for item in items:
                item['spare_stock'] = self._rows(db, 'SELECT body FROM spare_stock WHERE part_id=? ORDER BY location_key', (item['id'],))
                item['installed_quantity'] = db.execute('SELECT COUNT(*) FROM installed_components WHERE part_id=? AND removed_at IS NULL', (item['id'],)).fetchone()[0]
            return items

    def _install(self, db, data, replacing=None):
        equipment = self._read(db, 'equipment', identifier(data.get('equipment_id'), 'Equipment ID'))
        part = self._read(db, 'catalog_parts', identifier(data.get('part_id'), 'Part ID'))
        if identity(equipment) not in part['applicability']:
            raise ValueError('This catalog part has no explicit applicability for the equipment model and configuration.')
        ident = identifier(data.get('id') or 'IC-' + uuid.uuid4().hex[:16].upper(), 'Installed component ID')
        stamp = event_date(data.get('installed_at'))
        parent_id = data.get('parent_component_id') or None
        if parent_id:
            parent = self._read(db, 'installed_components', identifier(parent_id, 'Parent component ID'))
            if parent['equipment_id'] != equipment['id'] or parent['removed_at'] is not None:
                raise ValueError('The parent must be an active component on the same equipment.')
            if stamp < parent['installed_at']:
                raise ValueError('A child cannot be installed before its parent.')
            parent_id = parent['id']
        serial = text(data.get('serial', ''), 'Serial', 120)
        item = dict(id=ident, equipment_id=equipment['id'], part_id=part['id'], serial=serial,
                    position=text(data.get('position', ''), 'Position', 160), parent_component_id=parent_id,
                    installed_at=stamp, removed_at=None, notes=text(data.get('notes', ''), 'Notes', 2000),
                    part_snapshot=part, equipment_identity=identity(equipment), recorded_at=now())
        db.execute('INSERT INTO installed_components VALUES (?,?,?,?,?,?,?)',
                   (ident, equipment['id'], part['id'], serial.casefold(), parent_id, None, encode(item)))
        self._event(db, equipment['id'], 'component_replaced' if replacing else 'component_installed', stamp,
                    item['notes'] or ('Replacement recorded.' if replacing else 'Installation recorded.'),
                    component_id=ident, previous_component_id=replacing, part_id=part['id'],
                    serial=serial, equipment_identity=identity(equipment))
        return item

    def install_component(self, data):
        if not isinstance(data, dict):
            raise ValueError('Installation must be an object.')
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            return self._install(db, data)

    def replace_component(self, data):
        if not isinstance(data, dict):
            raise ValueError('Replacement must be an object.')
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            old = self._read(db, 'installed_components', identifier(data.get('component_id'), 'Component ID'))
            if old['removed_at'] is not None:
                raise ValueError('This installed item was already removed.')
            if db.execute('SELECT 1 FROM installed_components WHERE parent_id=? AND removed_at IS NULL', (old['id'],)).fetchone():
                raise ValueError('This assembly has active child components; record their removal before replacing it.')
            stamp = event_date(data.get('installed_at'))
            if stamp < old['installed_at']:
                raise ValueError('A replacement cannot predate the original installation.')
            new_part = self._read(db, 'catalog_parts', identifier(data.get('part_id'), 'Part ID'))
            new_serial = text(data.get('serial', ''), 'Serial', 120)
            if old['serial'] and new_part['id'] == old['part_id'] and new_serial.casefold() == old['serial'].casefold():
                raise ValueError('A replacement must identify a different serialized item.')
            old.update(removed_at=stamp, removal_notes=text(data.get('notes', ''), 'Notes', 2000))
            db.execute('UPDATE installed_components SET removed_at=?,body=? WHERE id=?', (stamp, encode(old), old['id']))
            payload = dict(data, equipment_id=old['equipment_id'], installed_at=stamp,
                           parent_component_id=old['parent_component_id'], position=old['position'])
            item = self._install(db, payload, replacing=old['id'])
            old['replaced_by'] = item['id']
            db.execute('UPDATE installed_components SET body=? WHERE id=?', (encode(old), old['id']))
            return item

    def set_stock(self, data):
        if not isinstance(data, dict):
            raise ValueError('Stock must be an object.')
        location = text(data.get('location', ''), 'Stock location', 200, True)
        quantity = data.get('quantity')
        if type(quantity) is not int or not 0 <= quantity <= 1000000:
            raise ValueError('Spare quantity must be a whole number from zero through 1,000,000.')
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            part = self._read(db, 'catalog_parts', identifier(data.get('part_id'), 'Part ID'))
            item = dict(part_id=part['id'], location=location, quantity=quantity, updated_at=now())
            db.execute('INSERT INTO spare_stock VALUES (?,?,?) ON CONFLICT(part_id,location_key) DO UPDATE SET body=excluded.body',
                       (part['id'], location.casefold(), encode(item)))
            return item

    def attach_manual(self, data):
        if not isinstance(data, dict):
            raise ValueError('Manual must be an object.')
        reference = text(data.get('reference', ''), 'Manual reference', 244, True)
        if not REFERENCE.fullmatch(reference):
            raise ValueError('Use a registered document identifier or URN, not a URL or file path.')
        item = dict(reference=reference, **identity(data))
        for key in ('title', 'revision'):
            item[key] = text(data.get(key, ''), key.capitalize(), 200, True)
        item['status'] = data.get('status', 'unreviewed')
        if not isinstance(item['status'], str) or item['status'] not in {'current', 'superseded', 'historical', 'unreviewed'}:
            raise ValueError('Manual status must be current, superseded, historical or unreviewed.')
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            equipment = self._read(db, 'equipment', identifier(data.get('equipment_id'), 'Equipment ID'))
            if identity(item) != identity(equipment):
                raise ValueError('Manual applicability must explicitly match this equipment model and configuration.')
            item.update(id='MA-' + uuid.uuid4().hex[:16].upper(), equipment_id=equipment['id'],
                        attached_at=now(), applicability_origin='Explicitly recorded metadata; compatibility is not inferred.')
            db.execute('INSERT INTO equipment_manuals VALUES (?,?,?,?)', (item['id'], equipment['id'], reference, encode(item)))
            self._event(db, equipment['id'], 'manual_attached', item['attached_at'], item['title'],
                        reference=reference, revision=item['revision'], equipment_identity=identity(item))
            return item

    def overview(self):
        with self.connection() as db:
            return {
                'equipment': self._rows(db, 'SELECT body FROM equipment ORDER BY id COLLATE NOCASE'),
                'catalog_parts': self._rows(db, 'SELECT body FROM catalog_parts ORDER BY id COLLATE NOCASE'),
                'installed_components': self._rows(db, 'SELECT body FROM installed_components WHERE removed_at IS NULL ORDER BY rowid'),
                'spare_stock': self._rows(db, 'SELECT body FROM spare_stock ORDER BY part_id,location_key'),
                'history': self._rows(db, 'SELECT body FROM equipment_events ORDER BY at DESC,rowid DESC'),
            }
