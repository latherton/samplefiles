"""Continuous synthetic acquisition with retained history and serialized KD delivery.

Generator steps are compressed demo progression; sample timestamps are actual
acquisition times. Missed ticks are never backfilled or future-dated. SQLite is
the history/outbox; SensorIndexer receipts journal every native request. No
DRESYNC is issued here. Pending jobs wait for the server's normal commit cycle.
"""

from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import threading
import uuid

from index_corpus import locked
from kd_client import KDError
from sensor_ingest import SensorIndexer, XML_DOCUMENT_DELIMITERS, sha, xml_bytes
from sensor_kd import (SCHEMA, SensorKD, canonical, load_json, payload_hash,
                       reference_for, sensor_database, source_identifier, validate_snapshot)
from telemetry import simulate


SCENARIOS = frozenset(('normal', 'degradation', 'load_change', 'sensor_gap'))
OUTCOMES = frozenset(('recovery', 'persistent', 'inconclusive'))
ASSETS = ('A-17', 'A-18')
MIN_FIRST_WINDOW = 12
SOURCE_ID = 'mission-pump-feed'


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


class MissionFeed:
    """One paired run and one durable publication at a time.

    on_verified(snapshot, publication_id) receives an exact raw SensorKD window
    with readback provenance. The callback is at-least-once across crashes and
    MUST be idempotent by publication_id. A callback failure does not invent a
    case or prevent acquisition; it is retained and retried before new delivery.
    """

    def __init__(self, client, state_path, *, source_id=SOURCE_ID, database=None,
                 sample_interval_seconds=2, publish_interval_seconds=20,
                 clock=None, on_verified=None):
        source_identifier(source_id)
        if source_id == 'demo-pump-replay':
            raise ValueError('Mission acquisition requires its own source_id.')
        if (type(sample_interval_seconds) not in (int, float) or not 1 <= sample_interval_seconds <= 60
                or type(publish_interval_seconds) not in (int, float) or not 5 <= publish_interval_seconds <= 300):
            raise ValueError('Sample cadence must be 1–60 seconds and publication cadence 5–300 seconds.')
        self.client, self.path = client, Path(state_path).resolve()
        self.source_id, self.database = source_id, sensor_database(database)
        self.sample_interval, self.publish_interval = sample_interval_seconds, publish_interval_seconds
        self.clock = clock or (lambda: datetime.now(timezone.utc))
        self.on_verified = on_verified
        self.receipts = self.path.parent / (self.path.stem + '-receipts')
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.receipts.mkdir(parents=True, exist_ok=True)
        self._mutex = threading.RLock()
        self._stop = threading.Event()
        self._thread = None
        self.connection_hash = hashlib.sha256((client.aci_url + '\n' + str(client.index_url)).encode()).hexdigest()
        with self._guard(), self._db() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS readings (
                    id INTEGER PRIMARY KEY, run_id TEXT NOT NULL, asset_id TEXT NOT NULL,
                    step INTEGER NOT NULL, event_at TEXT NOT NULL, received_at TEXT NOT NULL,
                    scenario TEXT NOT NULL, sample TEXT NOT NULL,
                    UNIQUE(asset_id, event_at));
                CREATE INDEX IF NOT EXISTS readings_run_asset ON readings(run_id,asset_id,id);
                CREATE TABLE IF NOT EXISTS publications (
                    id INTEGER PRIMARY KEY, run_id TEXT NOT NULL, asset_id TEXT NOT NULL,
                    last_reading_id INTEGER NOT NULL UNIQUE, created_at TEXT NOT NULL,
                    payload TEXT NOT NULL, receipt TEXT NOT NULL, state TEXT NOT NULL,
                    verified_at TEXT, snapshot TEXT, notified INTEGER NOT NULL DEFAULT 0,
                    error_code TEXT, error_message TEXT);
                CREATE INDEX IF NOT EXISTS publications_asset ON publications(asset_id,id);
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY, run_id TEXT, event_at TEXT NOT NULL,
                    kind TEXT NOT NULL, detail TEXT NOT NULL);
            ''')
            identity = {'schema': 'fleet.mission.feed.v1', 'source_id': self.source_id,
                        'database': self.database, 'connection_sha256': self.connection_hash}
            stored = self._get(db, 'identity')
            if stored is not None and stored != identity:
                raise ValueError('Mission state belongs to another source, database or KD connection.')
            self._put(db, 'identity', identity)
            if self._get(db, 'state') is None:
                self._put(db, 'state', {'state': 'idle', 'run_id': None, 'next_step': 0,
                    'scenarios': {}, 'outcomes': {}, 'last_sample_at': None, 'round_robin': 0})

    @contextmanager
    def _db(self):
        db = sqlite3.connect(str(self.path), timeout=5)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('PRAGMA synchronous=FULL')
        try:
            with db:
                yield db
        finally:
            db.close()

    @contextmanager
    def _guard(self):
        with self._mutex, locked(self.path):
            yield

    @staticmethod
    def _get(db, key):
        row = db.execute('SELECT value FROM metadata WHERE key=?', (key,)).fetchone()
        return json.loads(row['value']) if row else None

    @staticmethod
    def _put(db, key, value):
        db.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES (?,?)', (key, _json(value)))

    def _now(self):
        result = self.clock()
        if not isinstance(result, datetime) or result.tzinfo is None or result.utcoffset() is None:
            raise ValueError('Mission clock must return a timezone-aware datetime.')
        return result.astimezone(timezone.utc)

    @staticmethod
    def _stamp(value):
        return value.isoformat(timespec='microseconds').replace('+00:00', 'Z')

    @staticmethod
    def _elapsed(now, stamp):
        return (now - datetime.fromisoformat(stamp.replace('Z', '+00:00'))).total_seconds()

    def _event(self, db, state, kind, detail, stamp):
        db.execute('INSERT INTO events(run_id,event_at,kind,detail) VALUES (?,?,?,?)',
                   (state['run_id'], stamp, kind, _json(detail)))

    def start(self, scenario='degradation', asset_scenarios=None):
        scenarios = asset_scenarios if asset_scenarios is not None else {'A-17': scenario, 'A-18': 'load_change'}
        if (not isinstance(scenarios, dict) or set(scenarios) != set(ASSETS)
                or any(not isinstance(value, str) or value not in SCENARIOS for value in scenarios.values())):
            raise ValueError('Provide a supported scenario for both A-17 and A-18.')
        with self._guard(), self._db() as db:
            state = self._get(db, 'state')
            if state['state'] == 'running':
                if state['scenarios'] != scenarios:
                    raise ValueError('Pause the current run before starting a different episode.')
                return self.status()
            if db.execute("SELECT 1 FROM publications WHERE state!='verified' OR notified=0 LIMIT 1").fetchone():
                raise ValueError('Resolve the previous publication/case callback before starting another run.')
            stamp = self._stamp(self._now())
            state = {'state': 'running', 'run_id': uuid.uuid4().hex, 'next_step': 0,
                     'scenarios': dict(scenarios), 'outcomes': {}, 'last_sample_at': None,
                     'round_robin': 0, 'started_at': stamp}
            self._put(db, 'state', state)
            self._event(db, state, 'started', {'scenarios': scenarios}, stamp)
        return self.status()

    def pause(self):
        return self._set_run_state('paused')

    def resume(self):
        return self._set_run_state('running')

    def _set_run_state(self, target):
        with self._guard(), self._db() as db:
            state = self._get(db, 'state')
            if state['run_id'] is None:
                raise ValueError('Start a mission run first.')
            if state['state'] != target:
                state['state'] = target
                self._put(db, 'state', state)
                self._event(db, state, 'resumed' if target == 'running' else 'paused', {}, self._stamp(self._now()))
        return self.status()

    def set_outcome(self, outcome, asset_id='A-17'):
        if not isinstance(outcome, str) or outcome not in OUTCOMES or asset_id not in ASSETS:
            raise ValueError('Choose recovery, persistent or inconclusive for A-17/A-18.')
        with self._guard(), self._db() as db:
            state = self._get(db, 'state')
            if state['run_id'] is None:
                raise ValueError('Start a mission run before choosing subsequent observations.')
            rows = db.execute('SELECT sample FROM readings WHERE run_id=? AND asset_id=? ORDER BY id DESC LIMIT 181',
                              (state['run_id'], asset_id)).fetchall()
            good = next((json.loads(row['sample']) for row in rows if json.loads(row['sample'])['quality'] == 'good'), None)
            if good is None:
                raise ValueError('A good observed baseline is required before a follow-up branch.')
            branch = {'outcome': outcome, 'start_step': state['next_step'], 'anchor': good,
                      'selected_at': self._stamp(self._now())}
            state['outcomes'][asset_id] = branch
            self._put(db, 'state', state)
            self._event(db, state, 'follow_up_selected', {'asset_id': asset_id, 'outcome': outcome,
                        'next_step': state['next_step'], 'boundary': 'Authored synthetic follow-up, not proof of repair or cause.'}, branch['selected_at'])
        return self.status()

    @staticmethod
    def _reference_values(sample):
        load, rpm = sample['load_pct'] - 60, sample['rpm'] - 1800
        return (sample['vibration_mm_s'] - .020 * load - .0007 * rpm,
                sample['temperature_c'] - .12 * load - .002 * rpm,
                sample['pressure_bar'] - .006 * load - .0002 * rpm)

    def _sample(self, asset, scenario, step, branch, stamp):
        sample = dict(simulate(asset, scenario, min(step, 180))['samples'][-1])
        label = scenario
        if branch:
            label = branch['outcome']
            elapsed = step - branch['start_step'] + 1
            sample = dict(simulate(asset, 'normal', min(step, 180))['samples'][-1])
            values = self._reference_values(branch['anchor'])
            if label == 'recovery':
                fraction = min(1.0, elapsed / 30.0)
                values = tuple(value + (target - value) * fraction for value, target in zip(values, (2.0, 62.0, 5.4)))
            elif label == 'persistent':
                values = (values[0] + min(elapsed, 180) * .005, values[1], values[2])
            load, rpm = sample['load_pct'] - 60, sample['rpm'] - 1800
            sample.update(vibration_mm_s=round(values[0] + .020 * load + .0007 * rpm, 3),
                          temperature_c=round(values[1] + .12 * load + .002 * rpm, 3),
                          pressure_bar=round(values[2] + .006 * load + .0002 * rpm, 3))
            if label == 'inconclusive':
                sample['quality'] = 'suspect' if elapsed % 2 else 'missing'
                if sample['quality'] == 'missing':
                    for field in ('vibration_mm_s', 'temperature_c', 'pressure_bar', 'rpm', 'load_pct'):
                        sample[field] = None
        sample['timestamp'] = stamp
        return sample, label

    def _acquire(self, now):
        with self._db() as db:
            state = self._get(db, 'state')
            if state['state'] != 'running':
                return
            if state['last_sample_at'] and self._elapsed(now, state['last_sample_at']) < self.sample_interval:
                return
            # Protect event ordering across a new run, restart, or a backwards clock.
            last = db.execute('SELECT event_at FROM readings ORDER BY id DESC LIMIT 1').fetchone()
            if last and self._elapsed(now, last['event_at']) <= 0:
                return
            stamp = self._stamp(now)
            for asset in ASSETS:
                sample, label = self._sample(asset, state['scenarios'][asset], state['next_step'], state['outcomes'].get(asset), stamp)
                validate_snapshot({'schema': SCHEMA, 'source_id': self.source_id, 'asset_id': asset,
                                   'synthetic': True, 'samples': [sample]})
                db.execute('INSERT INTO readings(run_id,asset_id,step,event_at,received_at,scenario,sample) VALUES (?,?,?,?,?,?,?)',
                           (state['run_id'], asset, state['next_step'], stamp, stamp, label, _json(sample)))
            state['last_sample_at'] = stamp
            state['next_step'] += 1
            self._put(db, 'state', state)

    def _prepare(self, now):
        with self._db() as db:
            pending = db.execute("SELECT * FROM publications WHERE state!='verified' ORDER BY id LIMIT 1").fetchone()
            if pending:
                return dict(pending)
            state = self._get(db, 'state')
            if state['state'] != 'running':
                return None
            for offset in range(len(ASSETS)):
                index = (state['round_robin'] + offset) % len(ASSETS)
                asset = ASSETS[index]
                rows = db.execute('SELECT id,sample FROM readings WHERE run_id=? AND asset_id=? ORDER BY id DESC LIMIT 181',
                                  (state['run_id'], asset)).fetchall()
                if len(rows) < MIN_FIRST_WINDOW:
                    continue
                previous = db.execute('SELECT * FROM publications WHERE run_id=? AND asset_id=? ORDER BY id DESC LIMIT 1',
                                      (state['run_id'], asset)).fetchone()
                if previous and (previous['last_reading_id'] == rows[0]['id'] or self._elapsed(now, previous['created_at']) < self.publish_interval):
                    continue
                payload = validate_snapshot({'schema': SCHEMA, 'source_id': self.source_id, 'asset_id': asset,
                                             'synthetic': True, 'samples': [json.loads(row['sample']) for row in reversed(rows)]})
                receipt = self.receipts / ('window-%d.json' % rows[0]['id'])
                cursor = db.execute('INSERT INTO publications(run_id,asset_id,last_reading_id,created_at,payload,receipt,state) VALUES (?,?,?,?,?,?,?)',
                                   (state['run_id'], asset, rows[0]['id'], self._stamp(now), canonical(payload), str(receipt), 'queued'))
                state['round_robin'] = (index + 1) % len(ASSETS)
                self._put(db, 'state', state)
                return dict(db.execute('SELECT * FROM publications WHERE id=?', (cursor.lastrowid,)).fetchone())
        return None

    def _verify_completed_receipt(self, publication, report):
        payload = json.loads(publication['payload'])
        expected = {'database': self.database, 'payload_sha256': payload_hash(payload),
                    'request_sha256': sha(xml_bytes(payload)), 'document_delimiters': XML_DOCUMENT_DELIMITERS,
                    'connection_sha256': self.connection_hash,
                    'reference': reference_for(self.source_id, publication['asset_id']), 'complete': True,
                    'dry_run': False}
        if (not isinstance(report, dict) or any(report.get(key) != value for key, value in expected.items())
                or not isinstance(report.get('jobs'), list)
                or any(not isinstance(job, dict) or job.get('complete') is not True
                       or type(job.get('index_id')) is not int
                       or job.get('action') not in {'DRECREATEDBASE', 'DREADDDATA'}
                       or (job['action'] == 'DREADDDATA' and job.get('documents_processed') != 1)
                       for job in report['jobs'])):
            raise KDError('Retained publication receipt does not match the exact mission window.', 'mission_receipt_mismatch')
        actual = SensorKD(self.client, self.database).snapshot(self.source_id, publication['asset_id'])
        if canonical({key: actual[key] for key in payload}) != canonical(payload):
            raise KDError('KD readback differs from the retained mission window.', 'sensor_readback_mismatch')
        return actual

    def _deliver(self, publication):
        if publication['state'] == 'blocked':
            return
        payload, receipt = json.loads(publication['payload']), Path(publication['receipt'])
        try:
            report = load_json(receipt.read_bytes()) if receipt.exists() else None
            if report is not None and not isinstance(report, dict):
                raise ValueError('Retained publication receipt must be an object.')
            if report is None or report.get('complete') is not True:
                indexer = SensorIndexer(self.client, payload, receipt, self.database, timeout=1, poll=.05, allow_sync=False)
                report = indexer.run(resume=report is not None)
            snapshot = self._verify_completed_receipt(publication, report)
            with self._db() as db:
                db.execute("UPDATE publications SET state='verified',verified_at=?,snapshot=?,error_code=NULL,error_message=NULL WHERE id=?",
                           (self._stamp(self._now()), _json(snapshot), publication['id']))
        except (KDError, OSError, ValueError) as exc:
            code = getattr(exc, 'code', 'mission_delivery_error')
            retryable = code in {'sensor_pending_sync', 'index_pending'} or (isinstance(exc, KDError) and code == 'kd_unavailable')
            with self._db() as db:
                db.execute('UPDATE publications SET state=?,error_code=?,error_message=? WHERE id=?',
                           ('pending' if retryable else 'blocked', code,
                            'Waiting for the retained KD job/readback.' if retryable else 'Delivery needs review; the exact window and native receipt are retained. No blind resubmission.', publication['id']))

    def _notify_verified(self):
        with self._db() as db:
            row = db.execute("SELECT * FROM publications WHERE state='verified' AND notified=0 ORDER BY id LIMIT 1").fetchone()
        if row is None:
            return True
        try:
            if self.on_verified:
                self.on_verified(json.loads(row['snapshot']), row['id'])
            with self._db() as db:
                db.execute('UPDATE publications SET notified=1,error_code=NULL,error_message=NULL WHERE id=?', (row['id'],))
            return True
        except Exception:
            with self._db() as db:
                db.execute('UPDATE publications SET error_code=?,error_message=? WHERE id=?',
                           ('mission_callback_failed', 'KD readback is verified; the case callback is pending and will retry with the same publication ID.', row['id']))
            return False

    def tick(self):
        """Acquire at most one observation per asset and reconcile one publication.

        Pausing stops acquisition and new windows; already journaled jobs can
        finish reconciliation. A pending/uncertain job prevents later submissions.
        """
        with self._guard():
            now = self._now()
            self._acquire(now)
            if self._notify_verified():
                publication = self._prepare(now)
                if publication:
                    self._deliver(publication)
                    self._notify_verified()
        return self.status()

    def status(self):
        with self._db() as db:
            state = self._get(db, 'state')
            assets = []
            for asset in ASSETS:
                latest = db.execute('SELECT * FROM readings WHERE run_id=? AND asset_id=? ORDER BY id DESC LIMIT 1', (state['run_id'], asset)).fetchone()
                pub = db.execute('SELECT * FROM publications WHERE run_id=? AND asset_id=? ORDER BY id DESC LIMIT 1', (state['run_id'], asset)).fetchone()
                verified = db.execute("SELECT * FROM publications WHERE run_id=? AND asset_id=? AND state='verified' ORDER BY id DESC LIMIT 1", (state['run_id'], asset)).fetchone()
                pending_ids, submitted_at = [], None
                if pub and Path(pub['receipt']).exists():
                    try:
                        report = load_json(Path(pub['receipt']).read_bytes())
                        jobs = report.get('jobs', []) if isinstance(report, dict) else []
                        pending_ids = [job['index_id'] for job in jobs if not job.get('complete') and type(job.get('index_id')) is int]
                        submitted_at = next((job.get('intent_at') for job in jobs if job.get('action') == 'DREADDDATA'), None)
                    except (OSError, ValueError):
                        pass
                count = db.execute('SELECT COUNT(*) FROM readings WHERE run_id=? AND asset_id=?', (state['run_id'], asset)).fetchone()[0]
                assets.append({'asset_id': asset, 'source_id': self.source_id, 'scenario': state['scenarios'].get(asset),
                    'outcome': state['outcomes'].get(asset, {}).get('outcome'), 'step': latest['step'] if latest else -1,
                    'acquired_samples': count, 'last_observed_at': latest['event_at'] if latest else None,
                    'latest_sample': json.loads(latest['sample']) if latest else None,
                    'delivery': {'state': pub['state'] if pub else 'acquiring', 'publication_id': pub['id'] if pub else None,
                        'pending_index_ids': pending_ids, 'queued_at': pub['created_at'] if pub else None,
                        'submitted_at': submitted_at, 'verified_publication_id': verified['id'] if verified else None,
                        'verified_at': verified['verified_at'] if verified else None,
                        'error': {'code': pub['error_code'], 'message': pub['error_message']} if pub and pub['error_code'] else None},
                    'verified_snapshot': json.loads(verified['snapshot']) if verified else None})
            total = db.execute('SELECT COUNT(*) FROM readings').fetchone()[0]
            events = [dict(row) for row in db.execute('SELECT id,event_at,kind,detail FROM events WHERE run_id=? ORDER BY id DESC LIMIT 30', (state['run_id'],))]
        for event in events:
            event['detail'] = json.loads(event['detail'])
        return {'state': state['state'], 'running': state['state'] == 'running', 'run_id': state['run_id'],
                'source_id': self.source_id, 'synthetic': True, 'database': self.database,
                'step': state['next_step'] - 1, 'sample_interval_seconds': self.sample_interval,
                'publish_interval_seconds': self.publish_interval, 'total_history_samples': total,
                'timing_label': 'Compressed synthetic episode: one generator step per acquired reading; timestamps are actual UTC acquisition times.',
                'commit_policy': 'No automatic DRESYNC; delivery waits for the normal KD commit cycle.',
                'daemon_running': bool(self._thread and self._thread.is_alive()), 'assets': assets,
                'events': list(reversed(events))}

    def history(self, after_id=0, limit=500, asset_id=None):
        if type(after_id) is not int or after_id < 0 or type(limit) is not int or not 1 <= limit <= 1000 or asset_id not in (*ASSETS, None):
            raise ValueError('Choose a valid history cursor, asset and limit (1–1000).')
        with self._db() as db:
            rows = db.execute('SELECT * FROM readings WHERE id>? AND (? IS NULL OR asset_id=?) ORDER BY id LIMIT ?',
                              (after_id, asset_id, asset_id, limit)).fetchall()
        result = [dict(row) for row in rows]
        for row in result:
            row['sample'] = json.loads(row['sample'])
        return {'readings': result, 'next_cursor': result[-1]['id'] if result else after_id}

    def publication(self, publication_id):
        if type(publication_id) is not int or publication_id < 1:
            raise ValueError('Choose a valid publication ID.')
        with self._db() as db:
            row = db.execute('SELECT * FROM publications WHERE id=?', (publication_id,)).fetchone()
        if row is None:
            raise ValueError('Publication not found.')
        result = dict(row)
        result['payload'] = json.loads(result['payload'])
        result['snapshot'] = json.loads(result['snapshot']) if result['snapshot'] else None
        return result

    def launch_daemon(self):
        with self._mutex:
            if self._thread and self._thread.is_alive():
                return
            self._stop.clear()
            self._thread = threading.Thread(target=self._loop, name='fleet-mission-feed', daemon=True)
            self._thread.start()

    def _loop(self):
        while not self._stop.is_set():
            try:
                self.tick()
            except Exception:
                # Native intents remain durable; a later tick must reconcile them.
                # Preserve a generic worker event without source bodies or credentials.
                try:
                    with self._db() as db:
                        state = self._get(db, 'state')
                        self._event(db, state, 'worker_error', {'message': 'Acquisition/delivery tick failed; retained state will be retried.'}, self._stamp(self._now()))
                except Exception:
                    pass
            self._stop.wait(min(1.0, self.sample_interval))

    def shutdown(self, timeout=5):
        if type(timeout) not in (int, float) or not 0 <= timeout <= 30:
            raise ValueError('Shutdown wait must be 0–30 seconds.')
        self._stop.set()
        if self._thread and self._thread is not threading.current_thread():
            self._thread.join(timeout)
