"""Deterministic, illustrative pump telemetry and strictly causal demo analysis.

All limits, context corrections and signal trajectories here are authored for a
synthetic demonstration. They are not engineering limits or a trained condition
model. A projection estimates crossing of one illustrative vibration threshold;
it never estimates failure probability or remaining useful life. Real readings
are validated and described without applying this synthetic model.

For synthetic readings, staleness here means a gap in the submitted minute-cadence
series, not wall-clock age. The acquisition interface must retain receipt time
and assess real-source freshness using its configured sampling cadence. Fixed
historical replay timestamps are intentional.
"""

from datetime import datetime, timedelta, timezone
import math
import re


ASSETS = ('A-17', 'A-18')
SCENARIOS = ('normal', 'degradation', 'load_change', 'sensor_gap')
SIGNALS = ('vibration_mm_s', 'temperature_c', 'pressure_bar', 'rpm', 'load_pct')
START = datetime(2026, 9, 7, 12, 0, 0, tzinfo=timezone.utc)
MODEL_VERSION = 'fleet-demo-condition-v1'
REFERENCE_LOAD_PCT = 60.0
REFERENCE_RPM = 1800.0
WATCH_VIBRATION_MM_S = 2.9
REVIEW_VIBRATION_MM_S = 4.3
MIN_CONDITION_SAMPLES = 12
FORECAST_SAMPLES = 20
MAX_GAP_SECONDS = 90
MAX_SAMPLES = 10000
TARGET_LABEL = 'Illustrative vibration review threshold: 4.3 mm/s at reference load/speed'
FORECAST_METHOD = 'Linear fit of the latest 20 consecutive good observed readings; maximum horizon 120 minutes'
TIMESTAMP_PATTERN = re.compile(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?Z$')


def _validate_samples(samples):
    if not isinstance(samples, (list, tuple)):
        raise ValueError('samples must be a list of measurement objects.')
    if len(samples) > MAX_SAMPLES:
        raise ValueError('samples exceeds the 10000-reading analysis limit.')
    timestamps = []
    for row in samples:
        if not isinstance(row, dict):
            raise ValueError('Each sample must be a measurement object.')
        stamp = row.get('timestamp')
        if not isinstance(stamp, str) or not TIMESTAMP_PATTERN.fullmatch(stamp):
            raise ValueError('Sample timestamps must be UTC ISO 8601 strings ending in Z.')
        try:
            timestamp = datetime.fromisoformat(stamp[:-1] + '+00:00')
        except ValueError as exc:
            raise ValueError('Sample timestamp is not a valid UTC date/time.') from exc
        if timestamps and timestamp <= timestamps[-1]:
            raise ValueError('Sample timestamps must be strictly increasing; duplicates are not accepted.')
        timestamps.append(timestamp)
        if row.get('quality') not in ('good', 'missing', 'suspect'):
            raise ValueError('Sample quality must be good, missing, or suspect.')
        for signal in SIGNALS:
            if signal not in row:
                raise ValueError('Every sample must include every measurement field; use null for unavailable values.')
            value = row[signal]
            if value is not None and (isinstance(value, bool) or not isinstance(value, (float, int))):
                raise ValueError('Measurement values must be finite numbers or null.')
            if value is not None:
                try:
                    finite = math.isfinite(value)
                except OverflowError:
                    finite = False
                if not finite:
                    raise ValueError('Measurement values must be finite numbers or null.')
    return timestamps


def _complete_good(row):
    return row['quality'] == 'good' and all(row[signal] is not None for signal in SIGNALS)


def _normalize(row):
    """Remove the exact load/speed effects authored in this demo's generator."""
    load_delta = row['load_pct'] - REFERENCE_LOAD_PCT
    rpm_delta = row['rpm'] - REFERENCE_RPM
    return {
        'normalized_vibration_mm_s': row['vibration_mm_s'] - 0.020 * load_delta - 0.0007 * rpm_delta,
        'normalized_temperature_c': row['temperature_c'] - 0.12 * load_delta - 0.002 * rpm_delta,
        'normalized_pressure_bar': row['pressure_bar'] - 0.006 * load_delta - 0.0002 * rpm_delta,
    }


def _fit(timestamps, values):
    minutes = [(timestamp - timestamps[0]).total_seconds() / 60.0 for timestamp in timestamps]
    x_mean = sum(minutes) / len(minutes)
    y_mean = sum(values) / len(values)
    variance = sum((x - x_mean) ** 2 for x in minutes)
    slope = sum((x - x_mean) * (y - y_mean) for x, y in zip(minutes, values)) / variance
    fitted = [y_mean + slope * (x - x_mean) for x in minutes]
    rmse = math.sqrt(sum((actual - estimate) ** 2 for actual, estimate in zip(values, fitted)) / len(values))
    return slope, fitted[-1], rmse


def analyze_samples(samples, synthetic=True):
    """Validate and analyze only the supplied observations, without future access.

    Schema: timestamp (UTC ISO with Z); vibration_mm_s, temperature_c,
    pressure_bar, rpm, load_pct (finite number or null); quality (good, missing,
    suspect). Input is never mutated. All fields are required even when missing.
    Invalid schemas and unordered timestamps raise ValueError; empty and
    incomplete observations return an explicit insufficient-data assessment.
    """
    if not isinstance(synthetic, bool):
        raise ValueError('synthetic must be a boolean.')
    timestamps = _validate_samples(samples)
    intervals = [(right - left).total_seconds() for left, right in zip(timestamps, timestamps[1:])]
    latest_gap = intervals[-1] if synthetic and intervals and intervals[-1] > MAX_GAP_SECONDS else 0.0
    contiguous = 0
    for index in range(len(samples) - 1, -1, -1):
        if not _complete_good(samples[index]):
            break
        contiguous += 1
        if synthetic and index and (timestamps[index] - timestamps[index - 1]).total_seconds() > MAX_GAP_SECONDS:
            break
    latest_usable = bool(samples and _complete_good(samples[-1]) and not latest_gap)
    issues = []
    incomplete = sum(any(row[signal] is None for signal in SIGNALS) for row in samples)
    missing = sum(row['quality'] == 'missing' for row in samples)
    suspect = sum(row['quality'] == 'suspect' for row in samples)
    if not samples:
        issues.append('No readings are available.')
    if missing:
        issues.append('%d readings are flagged missing.' % missing)
    if suspect:
        issues.append('%d readings are flagged suspect.' % suspect)
    if incomplete:
        issues.append('%d readings have unavailable measurements.' % incomplete)
    gap_count = sum(interval > MAX_GAP_SECONDS for interval in intervals) if synthetic else 0
    if gap_count:
        issues.append('%d timestamp gaps exceed the 90-second replay cadence allowance.' % gap_count)
    quality = {
        'total_samples': len(samples),
        'good_samples': sum(_complete_good(row) for row in samples),
        'missing_samples': missing,
        'suspect_samples': suspect,
        'incomplete_samples': incomplete,
        'latest_quality': samples[-1]['quality'] if samples else 'missing',
        'latest_usable': latest_usable,
        'contiguous_good_samples': contiguous,
        'cadence_seconds': 60 if synthetic else None,
        'stale_gap_seconds': latest_gap,
        'issues': issues,
    }
    latest = {field: samples[-1][field] if samples else None for field in ('timestamp', *SIGNALS)}
    latest['quality'] = quality['latest_quality']
    latest.update({
        'normalized_vibration_mm_s': None,
        'normalized_temperature_c': None,
        'normalized_pressure_bar': None,
    })
    result = {
        'status': 'insufficient',
        'title': 'Reliable readings needed',
        'summary': 'Missing, suspect, or interrupted observations cannot establish equipment condition.',
        'quality': quality,
        'latest': latest,
        'forecast': {
            'available': False,
            'minutes_to_review': None,
            'target_label': TARGET_LABEL if synthetic else 'Requires a site-validated condition target',
            'reason': 'A continuous window of reliable observations is required.',
            'method': FORECAST_METHOD if synthetic else 'No condition model applied to real readings',
        },
        'contributors': [],
        'model_version': MODEL_VERSION if synthetic else 'observation-only-v1',
        'evidence_query': 'pump vibration inspection maintenance',
    }
    if not latest_usable:
        result['contributors'].append({
            'label': 'Data quality',
            'detail': 'The most recent reading is missing, suspect, incomplete, or follows a timestamp gap; no condition estimate is issued.',
        })
        return result
    if not synthetic:
        result.update({
            'status': 'observed',
            'title': 'Measurements received',
            'summary': 'Real source measurements are displayed. Condition classification and prediction require an equipment-specific, site-validated model.',
        })
        result['forecast']['reason'] = 'Demonstration thresholds and load corrections are not applied to real source measurements.'
        result['contributors'] = [{
            'label': 'Observed measurements',
            'detail': 'Latest vibration %.2f mm/s, temperature %.1f C, pressure %.2f bar, speed %.0f rpm, load %.1f%%. No equipment-health conclusion is made.' % tuple(latest[field] for field in SIGNALS),
        }]
        return result
    if contiguous < MIN_CONDITION_SAMPLES:
        result['summary'] = 'Collecting a continuous reading window: %d of %d required good readings. No healthy status or forecast is inferred.' % (contiguous, MIN_CONDITION_SAMPLES)
        result['contributors'] = [{'label': 'Observation coverage', 'detail': result['summary']}]
        return result

    normalized = _normalize(samples[-1])
    latest.update({key: round(value, 3) for key, value in normalized.items()})
    vibration = normalized['normalized_vibration_mm_s']
    if vibration >= REVIEW_VIBRATION_MM_S:
        result.update({
            'status': 'review',
            'title': 'Illustrative review threshold reached',
            'summary': 'The simulated vibration trend has reached the authored review threshold. Open related maintenance evidence and prepare a human review.',
        })
    elif vibration >= WATCH_VIBRATION_MM_S:
        result.update({
            'status': 'watch',
            'title': 'Persistent simulated change',
            'summary': 'Vibration is elevated after adjustment for simulated speed and load. The accompanying measurements provide context for maintenance review.',
        })
    else:
        result.update({
            'status': 'normal',
            'title': 'Within the illustrative baseline range',
            'summary': 'The current simulated vibration stays below the authored watch threshold after adjustment for speed and load.',
        })
    result['contributors'] = [
        {'label': 'Vibration', 'detail': '%.2f mm/s observed; %.2f mm/s at reference load/speed. Illustrative watch %.1f, review %.1f mm/s.' % (latest['vibration_mm_s'], vibration, WATCH_VIBRATION_MM_S, REVIEW_VIBRATION_MM_S)},
        {'label': 'Temperature and pressure', 'detail': 'At reference load/speed: %.1f C and %.2f bar, against authored baselines 62.0 C and 5.40 bar. These channels provide context; the projected target is vibration only.' % (normalized['normalized_temperature_c'], normalized['normalized_pressure_bar'])},
        {'label': 'Operating context', 'detail': 'Observed %.1f%% load and %.0f rpm. The synthetic correction compares readings at 60%% load and 1800 rpm; it has not been calibrated for real equipment.' % (latest['load_pct'], latest['rpm'])},
    ]
    forecast = result['forecast']
    if vibration >= REVIEW_VIBRATION_MM_S:
        forecast['minutes_to_review'] = 0
        forecast['reason'] = 'The illustrative review threshold is already observed. No future crossing is projected.'
    elif contiguous < FORECAST_SAMPLES:
        forecast['reason'] = 'At least 20 consecutive good observations are required for a trend projection.'
    else:
        values = [_normalize(row)['normalized_vibration_mm_s'] for row in samples[-FORECAST_SAMPLES:]]
        slope, fitted_latest, rmse = _fit(timestamps[-FORECAST_SAMPLES:], values)
        result['contributors'].append({
            'label': 'Observed trend',
            'detail': 'Latest 20 good readings: adjusted vibration slope %.3f mm/s per minute; fit residual %.3f mm/s. The fit uses only observations already received.' % (slope, rmse),
        })
        if slope <= 0.01 or values[-1] - values[0] < 0.2:
            forecast['reason'] = 'The observed window does not contain a sustained increasing vibration trend.'
        elif rmse > 0.12:
            forecast['reason'] = 'The observed trend is too irregular for this illustrative linear projection.'
        else:
            minutes = (REVIEW_VIBRATION_MM_S - fitted_latest) / slope
            if minutes <= 0:
                forecast['reason'] = 'The fitted threshold crossing is not in the future; a forward projection is unavailable.'
            elif minutes > 120:
                forecast['reason'] = 'The projected crossing lies beyond this demonstration model\'s 120-minute horizon.'
            else:
                forecast.update({
                    'available': True,
                    'minutes_to_review': round(minutes, 1),
                    'reason': 'If the recent adjusted trend continues, it reaches the illustrative review threshold in about %.0f minutes. This is not time to equipment failure.' % minutes,
                })
    return result


def simulate(asset_id='A-17', scenario='degradation', step=80):
    """Return reproducible readings 0..step at minute cadence and their analysis.

    Scenarios share a stable baseline. Degradation starts after minute 35;
    load_change ramps operating context up and back down; sensor_gap marks
    minutes 62..95 missing or suspect. These are fixture choices, not fault
    signatures. Every prefix is identical regardless of the requested endpoint.
    """
    if asset_id not in ASSETS:
        raise ValueError('asset_id must be A-17 or A-18.')
    if scenario not in SCENARIOS:
        raise ValueError('scenario must be normal, degradation, load_change, or sensor_gap.')
    if isinstance(step, bool) or not isinstance(step, int) or not 0 <= step <= 180:
        raise ValueError('step must be an integer from 0 through 180.')
    phase = 0.0 if asset_id == 'A-17' else 0.8
    samples = []
    for minute in range(step + 1):
        load = 60.0 + 2.0 * math.sin(minute / 7.0 + phase)
        rpm = 1800.0 + 15.0 * math.sin(minute / 9.0 + phase)
        if scenario == 'load_change':
            ramp = max(0.0, min(1.0, (minute - 40) / 15.0, (140 - minute) / 20.0))
            load += 34.0 * ramp
            rpm += 450.0 * ramp
        load_delta = load - REFERENCE_LOAD_PCT
        rpm_delta = rpm - REFERENCE_RPM
        drift = max(0, minute - 35) if scenario == 'degradation' else 0
        row = {
            'timestamp': (START + timedelta(minutes=minute)).isoformat(timespec='seconds').replace('+00:00', 'Z'),
            'vibration_mm_s': round(2.0 + 0.020 * load_delta + 0.0007 * rpm_delta + 0.036 * drift + 0.025 * math.sin(minute / 3.0 + phase), 3),
            'temperature_c': round(62.0 + 0.12 * load_delta + 0.002 * rpm_delta + 0.19 * drift + 0.08 * math.sin(minute / 5.0 + phase), 3),
            'pressure_bar': round(5.4 + 0.006 * load_delta + 0.0002 * rpm_delta - 0.012 * drift + 0.008 * math.sin(minute / 4.0 + phase), 3),
            'rpm': round(rpm, 3),
            'load_pct': round(load, 3),
            'quality': 'good',
        }
        if scenario == 'sensor_gap' and 62 <= minute <= 95:
            if minute % 2 == 0:
                row.update({signal: None for signal in SIGNALS})
                row['quality'] = 'missing'
            else:
                row['vibration_mm_s'] = round(row['vibration_mm_s'] + 4.0, 3)
                row['quality'] = 'suspect'
        samples.append(row)
    analysis = analyze_samples(samples, synthetic=True)
    analysis['evidence_query'] = '%s pump vibration inspection maintenance' % asset_id
    return {
        'asset_id': asset_id,
        'scenario': scenario,
        'step': step,
        'synthetic': True,
        'observed_at': samples[-1]['timestamp'],
        'samples': samples,
        'analysis': analysis,
    }
