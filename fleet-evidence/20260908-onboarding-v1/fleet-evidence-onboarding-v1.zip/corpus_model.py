"""Authored fixture metadata, integrity checks and explicit applicability rules."""
import hashlib
import json
from pathlib import Path
import re

from kd_client import KDError

KINDS = {'manual', 'work_order', 'inspection', 'bulletin', 'training', 'turnover'}
ID = re.compile(r'[A-Z0-9][A-Z0-9_-]{0,79}')


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


class Corpus:
    def __init__(self, directory):
        self.directory = Path(directory).resolve()
        self.manifest = json.loads((self.directory / 'manifest.json').read_text(encoding='utf-8'))
        if self.manifest.get('synthetic') is not True:
            raise ValueError('Only the authored synthetic corpus is supported.')
        self.assets = {a['id']: a for a in self.manifest['assets']}
        if set(self.assets) != {'A-17', 'A-18'}:
            raise ValueError('Expected the two contract assets.')
        self.records, self.by_reference, self.hashes, self.source_hashes = {}, {}, {}, {}
        for r in self.manifest['records']:
            ident, reference = r['id'], r['reference']
            if not ID.fullmatch(ident) or reference != 'urn:fleet-evidence:' + ident or ident in self.records:
                raise ValueError('Record IDs and references must be unique and namespaced.')
            if r['kind'] not in KINDS or r['status'] not in {'current', 'superseded', 'historical', 'unresolved'}:
                raise ValueError('Unknown fixture kind or status.')
            if r['asset_id'] not in {*self.assets, 'all', 'unknown'} or r['configuration'] not in {'A', 'B', 'all', 'unknown'}:
                raise ValueError('Unknown fixture applicability.')
            sections = r['sections']
            if not sections or len({s['id'] for s in sections}) != len(sections):
                raise ValueError('Unique source sections are required.')
            if any(not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}', s['id']) for s in sections):
                raise ValueError('Invalid source section anchor.')
            source = self.source_path(r)
            raw = source.read_bytes()
            if len(raw) > 2 * 1024 * 1024:
                raise ValueError('Source file exceeds demo size limit.')
            html = raw.decode('utf-8')
            if any(not re.search(r'\bid\s*=\s*[\"\']' + re.escape(s['id']) + r'[\"\']', html) for s in sections):
                raise ValueError('Source file is missing a declared section anchor.')
            self.records[ident] = r
            self.by_reference[reference] = r
            self.hashes[ident] = sha(canonical(r))
            self.source_hashes[ident] = sha(raw)
        if not 1 <= len(self.records) <= 1000:
            raise ValueError('Expected a bounded nonempty corpus.')
        self.manifest_sha256 = sha(canonical(self.manifest))

    def source_path(self, record):
        relative = Path(record['source_file'])
        if relative.is_absolute() or '..' in relative.parts or '\\' in record['source_file']:
            raise ValueError('Source paths must remain inside the corpus.')
        p = self.directory / relative
        if p.is_symlink() or any(parent.is_symlink() for parent in p.parents) or not p.resolve().is_relative_to(self.directory):
            raise ValueError('Source path escapes the corpus.')
        if not p.is_file() or p.suffix.lower() not in {'.html', '.htm'}:
            raise ValueError('An existing HTML source is required.')
        return p

    def text(self, record):
        # This exact authored text is indexed once; results must come back from KD.
        header = f"Synthetic demonstration. {record['title']}\nAsset {record['asset_id']}; model {record['equipment_model']}; configuration {record['configuration']}."
        return header + '\n' + record['summary'] + '\n' + '\n\n'.join(s['title'] + '\n' + s['text'] for s in record['sections'])

    def applicability(self, record, asset_id):
        asset = self.assets[asset_id]
        unknown = lambda x: x in ('', None, 'unknown')
        asset_ok = record['asset_id'] in {asset_id, 'all', 'unknown'}
        model_ok = record['equipment_model'] in {asset['model'], 'all'} or unknown(record['equipment_model'])
        config_ok = record['configuration'] in {asset['configuration'], 'all', 'unknown'}
        review = 'missing_identity' in record.get('issue_flags', []) or any(unknown(record.get(k)) for k in ('asset_id', 'equipment_model', 'configuration'))
        applies = asset_ok and model_ok and config_ok
        reason = ('Identity incomplete; planner review required.' if review and applies else
                  'Matches selected asset/model/configuration.' if applies else 'Different asset, model or configuration.')
        return {'applies': applies, 'reason': reason, 'review_required': review}

    def public(self, record, asset_id=None):
        value = dict(record, source_url='/sources/' + record['id'], metadata_origin='authored synthetic fixture')
        if asset_id:
            value['applicability'] = self.applicability(record, asset_id)
        return value

    def map_hits(self, response, asset_id, kind='all', scope='applicable', history=False):
        if response['total'] > len(response['hits']):
            raise KDError('KD results exceed the demo retrieval bound.', 'kd_results_incomplete')
        rows, seen = [], set()
        for hit in response['hits']:
            record = self.by_reference.get(hit['reference'])
            if not record or record['id'] in seen:
                raise KDError('Unexpected or duplicate reference in the demo database.', 'kd_corpus_mismatch')
            seen.add(record['id'])
            ident, fields = record['id'], hit['fields']
            if (fields.get('fe_record_id') != ident or fields.get('fe_record_sha256') != self.hashes[ident]
                    or fields.get('fe_source_sha256') != self.source_hashes[ident]):
                raise KDError('KD and the source collection differ. Run the dedicated corpus indexer.', 'kd_corpus_mismatch')
            live_text = hit['text'] or hit['summary']
            if not live_text:
                raise KDError('KD returned no source text for a matched record.', 'kd_text_missing')
            if kind != 'all' and record['kind'] != kind:
                continue
            if record['status'] == 'superseded' and not history:
                continue
            item = self.public(record, asset_id)
            if scope == 'applicable' and not item['applicability']['applies']:
                continue
            item.update(score=hit['score'], excerpt=(hit['summary'] or live_text)[:700],
                        retrieval={'reference': hit['reference'], 'text': live_text,
                                   'record_sha256': fields['fe_record_sha256'], 'source_sha256': fields['fe_source_sha256']})
            rows.append(item)
        return rows

    def issues(self, records):
        result, groups = [], {}
        for r in records:
            if r.get('duplicate_group'):
                groups.setdefault(r['duplicate_group'], []).append(r)
            if r['status'] == 'superseded' or 'superseded' in r.get('issue_flags', []):
                result.append({'id': 'superseded-' + r['id'], 'type': 'superseded', 'title': 'Superseded reference',
                               'description': r['title'] + ' is retained for history; review the current revision.',
                               'record_ids': [r['id']], 'severity': 'warning'})
            for flag in ('missing_identity', 'conflicting_record'):
                if flag in r.get('issue_flags', []):
                    result.append({'id': flag + '-' + r['id'], 'type': flag,
                                   'title': 'Missing equipment identity' if flag == 'missing_identity' else 'Conflicting record',
                                   'description': 'Resolve the missing serial or equipment identity before relying on this record.' if flag == 'missing_identity' else 'The authored fixture flags conflicting evidence for planner review.',
                                   'record_ids': [r['id']], 'severity': 'warning'})
        for group, members in groups.items():
            if len(members) > 1 and len({self.source_hashes[r['id']] for r in members}) == 1:
                result.append({'id': 'duplicate-' + group, 'type': 'duplicate', 'title': 'Exact source copies',
                               'description': 'Source bytes match. Separate references, files and event identifiers are retained; this is not evidence of separate maintenance events.',
                               'record_ids': [r['id'] for r in members], 'severity': 'warning'})
        return result
