"""Durable, bounded equipment-data onboarding, separate from demonstration fixtures.

CSV originals and all accepted/rejected rows are retained in SQLite. KD writes
use immutable references in two dedicated databases. A native receipt is only
submission evidence; verification requires the exact indexed payload read back.
This module configures source metadata, not device or historian adapters.
"""
import csv
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import io
import json
import math
from pathlib import Path
import re
import sqlite3
import threading
import urllib.parse
import uuid
import xml.etree.ElementTree as ET

from kd_client import KDError
from sensor_ingest import submit_native
from sensor_kd import METRICS, SCHEMA, UNITS, canonical, payload_hash, source_identifier, utc_timestamp

READINGS_DATABASE = 'FLEET_IMPORT_READINGS'
DOCUMENTS_DATABASE = 'FLEET_IMPORT_DOCUMENTS'
MAX_UPLOAD = 2 * 1024 * 1024
MAX_ROWS = 5000
TARGETS = ('asset_id', 'timestamp', 'quality', *METRICS)
DEFAULT_MAPPING = {name: name for name in TARGETS}


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def _text(value, name, limit=200, required=True):
    if not isinstance(value, str) or len(value) > limit or any(ord(c) < 32 for c in value):
        raise ValueError(name + ' must be bounded plain text.')
    value = value.strip()
    if required and not value:
        raise ValueError(name + ' is required.')
    return value


def _raw(content):
    if isinstance(content, str):
        content = content.encode('utf-8')
    if not isinstance(content, bytes) or not 1 <= len(content) <= MAX_UPLOAD:
        raise ValueError('Upload must contain 1 byte–2 MiB.')
    try:
        decoded = content.decode('utf-8-sig')
    except UnicodeError as exc:
        raise ValueError('Only UTF-8 text uploads are supported; binary extraction is not connected.') from exc
    if any(ord(char) < 32 and char not in '\r\n\t' for char in decoded):
        raise ValueError('Binary/control-character uploads are not supported; upload extracted UTF-8 text.')
    return content, decoded


def _filename(value):
    value = _text(value, 'filename', 255)
    if '/' in value or '\\' in value or value in {'.', '..'}:
        raise ValueError('filename must be a base filename without a path.')
    return value


class _PreviewHTML(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.hidden = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in {'script', 'style', 'iframe', 'object'}:
            self.hidden += 1
        if tag in {'p', 'div', 'br', 'li', 'h1', 'h2', 'h3', 'tr'} and not self.hidden:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag in {'script', 'style', 'iframe', 'object'} and self.hidden:
            self.hidden -= 1

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)


class OnboardingStore:
    def __init__(self, path, asset_lookup):
        self.path, self.asset_lookup = Path(path), asset_lookup
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        with self._db() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS onboarding_sources (
                    source_id TEXT PRIMARY KEY, data TEXT NOT NULL,
                    created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                    last_received_at TEXT, last_verified_at TEXT, latest_reading_at TEXT,
                    problem TEXT);
                CREATE TABLE IF NOT EXISTS onboarding_imports (
                    import_id TEXT PRIMARY KEY, identity TEXT NOT NULL UNIQUE,
                    kind TEXT NOT NULL, source_id TEXT, filename TEXT NOT NULL,
                    original BLOB NOT NULL, data TEXT NOT NULL, status TEXT NOT NULL,
                    created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                    connection_sha256 TEXT, error TEXT);
                CREATE TABLE IF NOT EXISTS onboarding_readings (
                    source_id TEXT NOT NULL, asset_id TEXT NOT NULL, timestamp TEXT NOT NULL,
                    sample TEXT NOT NULL, import_id TEXT NOT NULL, received_at TEXT NOT NULL,
                    PRIMARY KEY(source_id,asset_id,timestamp));
                CREATE TABLE IF NOT EXISTS onboarding_documents (
                    document_id TEXT PRIMARY KEY, document_key TEXT NOT NULL,
                    revision TEXT NOT NULL, applicability TEXT NOT NULL,
                    metadata TEXT NOT NULL, text TEXT NOT NULL,
                    original BLOB NOT NULL, filename TEXT NOT NULL,
                    import_id TEXT NOT NULL, created_at TEXT NOT NULL,
                    UNIQUE(document_key,revision,applicability));
                CREATE TABLE IF NOT EXISTS onboarding_jobs (
                    job_id TEXT PRIMARY KEY, import_id TEXT NOT NULL,
                    database_name TEXT NOT NULL, reference TEXT, action TEXT NOT NULL,
                    payload TEXT, status TEXT NOT NULL, index_id INTEGER,
                    native_status INTEGER, processed INTEGER,
                    intent_at TEXT, verified_at TEXT, error TEXT);
                CREATE INDEX IF NOT EXISTS onboarding_jobs_import ON onboarding_jobs(import_id);
                CREATE INDEX IF NOT EXISTS onboarding_readings_asset ON onboarding_readings(asset_id);
            ''')

    @contextmanager
    def _db(self):
        db = sqlite3.connect(str(self.path), timeout=30)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        try:
            with db:
                yield db
        finally:
            db.close()

    def _asset(self, asset_id):
        asset_id = _text(asset_id, 'asset_id', 80)
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}', asset_id):
            raise ValueError('Equipment identifier contains unsupported characters.')
        try:
            found = self.asset_lookup(asset_id) if callable(self.asset_lookup) else asset_id in self.asset_lookup
        except (KeyError, ValueError):
            found = None
        if not found:
            raise ValueError('Equipment ' + asset_id + ' is not registered.')
        return found.get('id', found.get('asset_id', asset_id)) if isinstance(found, dict) else asset_id

    @staticmethod
    def _mapping(mapping):
        if not isinstance(mapping, dict) or set(mapping) != set(TARGETS):
            raise ValueError('Map asset_id, timestamp, quality and all five measurement fields.')
        result = {key: _text(value, 'column mapping', 128) for key, value in mapping.items()}
        if len(set(result.values())) != len(result):
            raise ValueError('Each target must map to a distinct CSV column.')
        return result

    def save_source(self, data):
        allowed = {'source_id', 'label', 'kind', 'endpoint', 'expected_interval_seconds', 'synthetic', 'mapping', 'units'}
        if not isinstance(data, dict) or set(data) - allowed:
            raise ValueError('Unsupported source fields; credentials and tokens must not be saved here.')
        source_id = source_identifier(data.get('source_id'))
        label = _text(data.get('label', source_id), 'label', 120)
        kind = data.get('kind', 'csv')
        if kind not in {'csv', 'api', 'historian'}:
            raise ValueError('Source kind must be csv, api or historian.')
        endpoint = _text(data.get('endpoint', ''), 'endpoint', 500, False)
        if endpoint:
            parsed = urllib.parse.urlsplit(endpoint)
            if (parsed.scheme not in {'http', 'https'} or not parsed.hostname or parsed.username or parsed.password
                    or parsed.query or parsed.fragment or any(c.isspace() for c in endpoint)):
                raise ValueError('Endpoint must be an HTTP(S) URL without credentials, query parameters or fragment.')
        cadence = data.get('expected_interval_seconds', 300)
        if type(cadence) is not int or not 1 <= cadence <= 604800:
            raise ValueError('Expected interval must be 1–604800 seconds.')
        synthetic = data.get('synthetic', False)
        if type(synthetic) is not bool:
            raise ValueError('synthetic must be a boolean.')
        units = data.get('units', dict(UNITS))
        if units != UNITS:
            raise ValueError('This importer requires normalized units: ' + canonical(UNITS) + '. Unit conversion is not connected.')
        saved = {'source_id': source_id, 'label': label, 'kind': kind, 'endpoint': endpoint,
                 'expected_interval_seconds': cadence, 'synthetic': synthetic,
                 'mapping': self._mapping(data.get('mapping', DEFAULT_MAPPING)), 'units': dict(UNITS),
                 'adapter_status': 'manual_upload' if kind == 'csv' else 'not_connected'}
        stamp = now()
        with self._db() as db:
            prior = db.execute('SELECT data FROM onboarding_sources WHERE source_id=?', (source_id,)).fetchone()
            if prior and json.loads(prior['data'])['synthetic'] != synthetic:
                raise ValueError('A saved source cannot switch between synthetic and source-reported origin; create a new source.')
            db.execute('''INSERT INTO onboarding_sources(source_id,data,created_at,updated_at) VALUES(?,?,?,?)
                ON CONFLICT(source_id) DO UPDATE SET data=excluded.data,updated_at=excluded.updated_at''',
                       (source_id, canonical(saved), stamp, stamp))
        return self.source(source_id)

    def source(self, source_id, at=None):
        source_identifier(source_id)
        with self._db() as db:
            row = db.execute('SELECT * FROM onboarding_sources WHERE source_id=?', (source_id,)).fetchone()
            if not row:
                raise ValueError('Save this source before importing readings.')
            counts = db.execute("SELECT status,json_extract(data,'$.rejected_count') AS rejected_count FROM onboarding_imports WHERE source_id=?", (source_id,)).fetchall()
        result = {**json.loads(row['data']), **{key: row[key] for key in ('created_at', 'updated_at', 'last_received_at', 'last_verified_at', 'latest_reading_at')}}
        clock = utc_timestamp(at) if at else datetime.now(timezone.utc)
        cadence = result['expected_interval_seconds']
        stale = bool(row['latest_reading_at'] and (clock - utc_timestamp(row['latest_reading_at'])).total_seconds() > cadence * 2)
        interrupted = bool(result['kind'] != 'csv' and row['last_received_at'] and (clock - utc_timestamp(row['last_received_at'])).total_seconds() > cadence * 2)
        delivery = any(item['status'] in {'delivery_problem', 'uncertain'} for item in counts)
        pending = any(item['status'] in {'queued', 'submitted', 'indexing'} for item in counts)
        errors = ([row['problem']] if row['problem'] else [])
        if result['adapter_status'] == 'not_connected':
            errors.append('Connection details are saved; an acquisition adapter has not been connected.')
        state = ('delivery_problem' if delivery else 'connection_problem' if row['problem'] else 'interrupted' if interrupted else 'stale' if stale else
                 'not_connected' if result['adapter_status'] == 'not_connected' else 'indexing' if pending else
                 'verified' if row['last_verified_at'] else 'received' if row['last_received_at'] else 'awaiting_import')
        result.update({'health': {'state': state, 'stale': stale, 'interrupted': interrupted,
                                  'delivery_problem': delivery, 'indexing': pending, 'errors': errors},
                       'rejected_count': sum(item['rejected_count'] or 0 for item in counts),
                       'prediction_status': 'observation_only'})
        return result

    def sources(self, at=None):
        with self._db() as db:
            identifiers = [row[0] for row in db.execute('SELECT source_id FROM onboarding_sources ORDER BY source_id')]
        return [self.source(identifier, at) for identifier in identifiers]

    def record_source_problem(self, source_id, message):
        self.source(source_id)
        message = _text(message, 'source problem', 500, False)
        with self._db() as db:
            db.execute('UPDATE onboarding_sources SET problem=?,updated_at=? WHERE source_id=?', (message or None, now(), source_id))
        return self.source(source_id)

    def _preview(self, source, filename, content, mapping, db):
        raw, decoded = _raw(content)
        filename = _filename(filename)
        if not filename.lower().endswith('.csv'):
            raise ValueError('Readings uploads must use a .csv filename.')
        mapping = self._mapping(mapping or source['mapping'])
        try:
            reader = csv.DictReader(io.StringIO(decoded, newline=''), strict=True)
            columns = reader.fieldnames or []
            if not columns or len(columns) > 100 or len(set(columns)) != len(columns):
                raise ValueError('CSV must have 1–100 uniquely named columns.')
            if any(len(name) > 128 or not name.strip() for name in columns):
                raise ValueError('CSV column names must be nonempty and at most 128 characters.')
            missing = sorted(set(mapping.values()) - set(columns))
            if missing:
                return {'source_id': source['source_id'], 'filename': filename, 'columns': columns, 'mapping': mapping,
                        'mapping_errors': ['Mapped columns are missing: ' + ', '.join(missing)], 'units': dict(UNITS),
                        'accepted_count': 0, 'rejected_count': 0, 'duplicate_count': 0,
                        'accepted_rows': [], 'rejected_rows': [], 'duplicate_rows': []}, raw
            accepted, rejected, duplicates, seen = [], [], [], {}
            for number, row in enumerate(reader, 2):
                if number > MAX_ROWS + 1:
                    raise ValueError('CSV exceeds the 5000-row import limit.')
                reasons, sample, asset = [], {}, None
                try:
                    if None in row or any(value is None for value in row.values()):
                        raise ValueError('Row column count does not match the header.')
                    asset = self._asset(row[mapping['asset_id']].strip())
                    stamp = row[mapping['timestamp']].strip()
                    parsed_stamp = utc_timestamp(stamp)
                    if (parsed_stamp - utc_timestamp(now())).total_seconds() > 60:
                        raise ValueError('Reading timestamp is more than 60 seconds in the future; check the source clock.')
                    stamp = parsed_stamp.isoformat().replace('+00:00', 'Z')
                    quality = row[mapping['quality']].strip().lower()
                    if quality not in {'good', 'missing', 'suspect'}:
                        raise ValueError('quality must be good, missing or suspect.')
                    sample = {'timestamp': stamp, 'quality': quality}
                    for metric in METRICS:
                        value = row[mapping[metric]].strip()
                        try:
                            sample[metric] = None if value == '' else float(value)
                        except (ValueError, OverflowError) as exc:
                            raise ValueError(metric + ' must be numeric or empty.') from exc
                        if sample[metric] is not None and not math.isfinite(sample[metric]):
                            raise ValueError(metric + ' must be finite.')
                    if quality == 'good' and any(sample[name] is None for name in METRICS):
                        raise ValueError('A row with missing measurements cannot be labeled good.')
                    key, encoded = (asset, stamp), canonical(sample)
                    prior = seen.get(key)
                    retained = db.execute('SELECT sample FROM onboarding_readings WHERE source_id=? AND asset_id=? AND timestamp=?',
                                          (source['source_id'], asset, stamp)).fetchone()
                    prior = prior if prior is not None else retained['sample'] if retained else None
                    if prior is not None:
                        if prior == encoded:
                            duplicates.append({'row_number': number, 'reason': 'Exact source/equipment/timestamp duplicate.'})
                            continue
                        raise ValueError('Conflicting measurements for the same source, equipment and timestamp.')
                    seen[key] = encoded
                except (ValueError, KeyError) as exc:
                    reasons.append(str(exc))
                if reasons:
                    rejected.append({'row_number': number, 'reasons': reasons, 'values': {str(k): v for k, v in row.items()}})
                else:
                    accepted.append({'row_number': number, 'asset_id': asset, 'sample': sample})
        except csv.Error as exc:
            raise ValueError('CSV could not be parsed: ' + str(exc)) from exc
        return {'source_id': source['source_id'], 'filename': filename, 'columns': columns, 'mapping': mapping,
                'mapping_errors': [], 'units': dict(UNITS), 'accepted_count': len(accepted),
                'rejected_count': len(rejected), 'duplicate_count': len(duplicates),
                'accepted_rows': accepted, 'rejected_rows': rejected, 'duplicate_rows': duplicates}, raw

    def preview_csv(self, source_id, filename, content, mapping=None):
        source = self.source(source_id)
        with self._db() as db:
            preview, _ = self._preview(source, filename, content, mapping, db)
        return preview

    def _add_job(self, db, import_id, database, reference, payload, action='DREADDDATA'):
        db.execute('''INSERT INTO onboarding_jobs(job_id,import_id,database_name,reference,action,payload,status)
                      VALUES(?,?,?,?,?,?,?)''', ('job-' + uuid.uuid4().hex, import_id, database, reference, action,
                                                canonical(payload) if payload else None, 'queued'))

    def import_csv(self, source_id, filename, content, mapping=None):
        source, stamp = self.source(source_id), now()
        raw, _ = _raw(content)
        identity = payload_hash({'kind': 'csv', 'source': source_id, 'raw_sha256': hashlib.sha256(raw).hexdigest(),
                                 'mapping': self._mapping(mapping or source['mapping']), 'synthetic': source['synthetic']})
        with self.lock, self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            prior = db.execute('SELECT import_id FROM onboarding_imports WHERE identity=?', (identity,)).fetchone()
            if prior:
                import_id = prior['import_id']
            else:
                preview, raw = self._preview(source, filename, content, mapping, db)
                if preview['mapping_errors']:
                    raise ValueError(preview['mapping_errors'][0])
                import_id = 'imp-' + uuid.uuid4().hex
                status = 'queued' if preview['accepted_count'] else 'rejected' if preview['rejected_count'] else 'duplicates_only'
                db.execute('''INSERT INTO onboarding_imports(import_id,identity,kind,source_id,filename,original,data,status,created_at,updated_at)
                              VALUES(?,?,?,?,?,?,?,?,?,?)''', (import_id, identity, 'csv', source_id, filename, raw,
                                                               canonical(preview), status, stamp, stamp))
                groups = {}
                for row in preview['accepted_rows']:
                    sample, asset_id = row['sample'], row['asset_id']
                    db.execute('INSERT INTO onboarding_readings VALUES(?,?,?,?,?,?)',
                               (source_id, asset_id, sample['timestamp'], canonical(sample), import_id, stamp))
                    groups.setdefault(asset_id, []).append(sample)
                for asset_id, samples in groups.items():
                    samples.sort(key=lambda item: utc_timestamp(item['timestamp']))
                    for offset in range(0, len(samples), 181):
                        payload = {'schema': SCHEMA, 'source_id': source_id, 'asset_id': asset_id,
                                   'synthetic': source['synthetic'], 'samples': samples[offset:offset + 181]}
                        self._add_job(db, import_id, READINGS_DATABASE,
                                      'urn:fleet-import:' + import_id + ':' + asset_id + ':' + str(offset // 181), payload)
                latest = max((row['sample']['timestamp'] for row in preview['accepted_rows']), key=utc_timestamp, default=None)
                previous = source['latest_reading_at']
                latest = max(filter(None, (previous, latest)), key=utc_timestamp, default=None)
                db.execute('UPDATE onboarding_sources SET last_received_at=?,latest_reading_at=?,updated_at=? WHERE source_id=?',
                           (stamp, latest, stamp, source_id))
        return self.receipt(import_id)

    def import_document(self, filename, content, metadata):
        filename, (raw, decoded) = _filename(filename), _raw(content)
        suffix = Path(filename).suffix.lower()
        if suffix not in {'.txt', '.md', '.html', '.htm'}:
            raise ValueError('Supported documents are UTF-8 .txt, .md and .html; PDF/Office/binary extraction is not connected.')
        if not isinstance(metadata, dict) or set(metadata) - {'title', 'revision', 'asset_ids', 'document_type', 'document_key'}:
            raise ValueError('Document metadata must contain title, revision, explicit asset_ids and optional document_type/document_key.')
        assets = metadata.get('asset_ids')
        if not isinstance(assets, list) or not 1 <= len(assets) <= 100:
            raise ValueError('Attach this document to 1–100 explicitly registered equipment identifiers.')
        assets = sorted({self._asset(asset) for asset in assets})
        applicability = []
        for asset in assets:
            equipment = self.asset_lookup(asset) if callable(self.asset_lookup) else None
            applicability.append({'asset_id': asset,
                                  'model': equipment.get('model') if isinstance(equipment, dict) else None,
                                  'configuration': equipment.get('configuration') if isinstance(equipment, dict) else None})
        meta = {'title': _text(metadata.get('title'), 'title'), 'revision': _text(metadata.get('revision'), 'revision', 80),
                'asset_ids': assets, 'document_type': _text(metadata.get('document_type', 'manual'), 'document_type', 80),
                'document_key': _text(metadata.get('document_key', filename), 'document_key', 200),
                'applicability': applicability}
        if suffix in {'.html', '.htm'}:
            parser = _PreviewHTML()
            parser.feed(decoded)
            decoded = ''.join(parser.parts)
        # XML parsers normalize source line endings. Normalize the extracted
        # text first while retaining the uploaded original bytes unchanged.
        preview_text = decoded.replace('\r\n', '\n').replace('\r', '\n').strip()
        if not preview_text:
            raise ValueError('Document does not contain readable text.')
        digest = hashlib.sha256(raw).hexdigest()
        identity = payload_hash({'kind': 'document', 'metadata': meta, 'original_sha256': digest})
        stamp = now()
        with self.lock, self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            prior = db.execute('SELECT import_id FROM onboarding_imports WHERE identity=?', (identity,)).fetchone()
            if prior:
                import_id = prior['import_id']
            else:
                existing = db.execute('SELECT document_id FROM onboarding_documents WHERE document_key=? AND revision=? AND applicability=?',
                                      (meta['document_key'], meta['revision'], canonical(assets))).fetchone()
                if existing:
                    raise ValueError('This document revision already exists with different content or metadata; provide a new revision.')
                import_id, document_id = 'imp-' + uuid.uuid4().hex, 'doc-' + uuid.uuid4().hex
                data = {'document_id': document_id, 'metadata': meta, 'preview_text': preview_text[:20000],
                        'original_sha256': digest, 'accepted_count': 1, 'rejected_count': 0, 'duplicate_count': 0}
                db.execute('INSERT INTO onboarding_documents VALUES(?,?,?,?,?,?,?,?,?,?)',
                           (document_id, meta['document_key'], meta['revision'], canonical(assets), canonical(meta),
                            preview_text, raw, filename, import_id, stamp))
                db.execute('''INSERT INTO onboarding_imports(import_id,identity,kind,filename,original,data,status,created_at,updated_at)
                              VALUES(?,?,?,?,?,?,?,?,?)''', (import_id, identity, 'document', filename, raw, canonical(data), 'queued', stamp, stamp))
                payload = {'schema': 'fleet.import.document.v1', 'document_id': document_id,
                           'metadata': meta, 'text': preview_text, 'original_sha256': digest}
                self._add_job(db, import_id, DOCUMENTS_DATABASE, 'urn:fleet-import-document:' + document_id, payload)
        return self.receipt(import_id)

    def receipt(self, import_id):
        with self._db() as db:
            row = db.execute('SELECT * FROM onboarding_imports WHERE import_id=?', (import_id,)).fetchone()
            if not row:
                raise ValueError('Import receipt does not exist.')
            jobs = db.execute('SELECT * FROM onboarding_jobs WHERE import_id=? ORDER BY rowid', (import_id,)).fetchall()
        data = json.loads(row['data'])
        result = {key: row[key] for key in ('import_id', 'kind', 'source_id', 'filename', 'status', 'created_at', 'updated_at', 'error')}
        result.update({key: data[key] for key in ('accepted_count', 'rejected_count', 'duplicate_count')})
        result['rows'] = {key: data.get(key, []) for key in ('accepted_rows', 'rejected_rows', 'duplicate_rows')}
        result['jobs'] = [{key: item[key] for key in ('job_id', 'database_name', 'reference', 'action', 'status', 'index_id', 'native_status', 'processed', 'intent_at', 'verified_at', 'error')} for item in jobs]
        result['verified_count'] = sum(len(json.loads(item['payload'])['samples']) if row['kind'] == 'csv' else 1
                                       for item in jobs if item['action'] == 'DREADDDATA' and item['status'] == 'verified')
        if row['kind'] == 'document':
            result.update({key: data[key] for key in ('document_id', 'metadata', 'preview_text', 'original_sha256')})
        return result

    def imports(self):
        with self._db() as db:
            rows = db.execute("""SELECT import_id,kind,source_id,filename,status,created_at,updated_at,error,
                json_extract(data,'$.accepted_count') AS accepted_count,
                json_extract(data,'$.rejected_count') AS rejected_count,
                json_extract(data,'$.duplicate_count') AS duplicate_count
                FROM onboarding_imports ORDER BY created_at DESC LIMIT 200""").fetchall()
        return [dict(row) for row in rows]

    def pending_import_ids(self):
        """All explicitly started unfinished plans, without loading uploaded rows."""
        with self._db() as db:
            return [row[0] for row in db.execute("""SELECT import_id FROM onboarding_imports
                WHERE connection_sha256 IS NOT NULL AND status IN ('queued','submitted','indexing','delivery_problem','uncertain')
                ORDER BY created_at""")]

    def document(self, document_id):
        with self._db() as db:
            row = db.execute('SELECT * FROM onboarding_documents WHERE document_id=?', (document_id,)).fetchone()
        if not row:
            raise ValueError('Document does not exist.')
        receipt, metadata = self.receipt(row['import_id']), json.loads(row['metadata'])
        matches = []
        for applicability in metadata.get('applicability', []):
            try:
                self._asset(applicability['asset_id'])
                current = self.asset_lookup(applicability['asset_id']) if callable(self.asset_lookup) else None
                current = current if isinstance(current, dict) else {}
                matches.append({**applicability, 'matches': current.get('model') == applicability['model']
                                and current.get('configuration') == applicability['configuration']})
            except (ValueError, KeyError):
                matches.append({**applicability, 'matches': False})
        return {'document_id': document_id, **metadata, 'filename': row['filename'],
                'text': row['text'], 'created_at': row['created_at'], 'import_id': row['import_id'],
                'indexing_status': receipt['status'], 'original_sha256': receipt['original_sha256'],
                'applicability_matches': matches,
                'applicable_asset_ids': [item['asset_id'] for item in matches if item['matches']],
                'preview_format': 'plain_text', 'applicability_basis': 'Explicit equipment attachment; suitability is not inferred.'}

    def documents(self, asset_id=None):
        if asset_id:
            asset_id = self._asset(asset_id)
        with self._db() as db:
            rows = db.execute('SELECT document_id,applicability FROM onboarding_documents ORDER BY created_at DESC').fetchall()
        return [self.document(row['document_id']) for row in rows if not asset_id or asset_id in json.loads(row['applicability'])]

    def original(self, document_id):
        with self._db() as db:
            row = db.execute('SELECT filename,original FROM onboarding_documents WHERE document_id=?', (document_id,)).fetchone()
        if not row:
            raise ValueError('Document does not exist.')
        return row['filename'], row['original']

    @staticmethod
    def _body(job):
        envelope = ET.Element('DOCUMENTS')
        doc = ET.SubElement(envelope, 'DOCUMENT')
        payload = json.loads(job['payload'])
        ET.SubElement(doc, 'DREREFERENCE').text = job['reference']
        ET.SubElement(doc, 'DRETITLE').text = payload.get('metadata', {}).get('title', 'Imported equipment observations')
        ET.SubElement(doc, 'FE_IMPORT_PAYLOAD').text = canonical(payload)
        ET.SubElement(doc, 'FE_IMPORT_SHA256').text = payload_hash(payload)
        ET.SubElement(doc, 'FE_IMPORT_ID').text = job['import_id']
        ET.SubElement(doc, 'DRECONTENT').text = payload.get('text', 'Imported readings for ' + payload.get('asset_id', 'equipment'))
        return ET.tostring(envelope, encoding='utf-8') + b'\n#DREENDDATAREFERENCE\r\n\r\n'

    @staticmethod
    def _connection(client):
        return hashlib.sha256((client.aci_url + '\n' + str(client.index_url)).encode()).hexdigest()

    def _job_update(self, job_id, **fields):
        allowed = {'status', 'index_id', 'native_status', 'processed', 'intent_at', 'verified_at', 'error'}
        if not fields or set(fields) - allowed:
            raise ValueError('Invalid job update.')
        with self._db() as db:
            db.execute('UPDATE onboarding_jobs SET ' + ','.join(key + '=?' for key in fields) + ' WHERE job_id=?',
                       (*fields.values(), job_id))

    def _readback(self, client, job):
        result = client.query('*', database=job['database_name'], limit=10000, print_fields=True)
        if (not isinstance(result, dict) or type(result.get('total')) is not int or not isinstance(result.get('hits'), list)
                or result['total'] != len(result['hits']) or not 0 <= result['total'] <= 10000):
            raise KDError('Cannot verify a truncated import database readback.', 'import_readback_incomplete')
        if any(hit.get('database', '').casefold() != job['database_name'].casefold() for hit in result['hits']):
            raise KDError('Import readback returned a record outside its dedicated database.', 'import_scope_error')
        hits = [hit for hit in result['hits'] if hit.get('reference') == job['reference']]
        expected = json.loads(job['payload'])
        if len(hits) != 1:
            return False
        fields = hits[0].get('fields', {})
        if fields.get('fe_import_sha256') != payload_hash(expected) or fields.get('fe_import_id') != job['import_id']:
            return False
        if expected.get('schema') == 'fleet.import.document.v1' and hits[0].get('text', '').strip() != expected['text'].strip():
            return False
        try:
            actual = json.loads(fields.get('fe_import_payload', ''))
            return canonical(actual) == canonical(expected)
        except (ValueError, TypeError):
            return False

    def dispatch(self, import_id, client):
        """Explicitly begin this receipt's planned writes. Never replay an intent."""
        return self._advance(import_id, client, start=True)

    def poll(self, import_id, client, should_stop=None):
        """Poll original jobs and continue their queued plan after database creation."""
        return self._advance(import_id, client, start=False, should_stop=should_stop)

    def _advance(self, import_id, client, start, should_stop=None):
        with self.lock:
            receipt = self.receipt(import_id)
            if receipt['status'] in {'verified', 'rejected', 'duplicates_only'}:
                return receipt
            if not client.index_url:
                with self._db() as db:
                    db.execute("UPDATE onboarding_imports SET status='delivery_problem',error=?,updated_at=? WHERE import_id=?",
                               ('KD index endpoint is not configured. Configure it before starting this import.', now(), import_id))
                return self.receipt(import_id)
            fingerprint = self._connection(client)
            with self._db() as db:
                row = db.execute('SELECT connection_sha256 FROM onboarding_imports WHERE import_id=?', (import_id,)).fetchone()
                if row[0] and row[0] != fingerprint:
                    raise ValueError('Resume requires the exact original KD connection.')
                if not row[0] and not start:
                    return receipt
                db.execute('UPDATE onboarding_imports SET connection_sha256=? WHERE import_id=?', (fingerprint, import_id))
            try:
                databases = {name.casefold() for name in client.databases()}
                with self._db() as db:
                    jobs = [dict(row) for row in db.execute('SELECT * FROM onboarding_jobs WHERE import_id=? ORDER BY rowid', (import_id,))]
                    target = jobs[0]['database_name']
                    creates = [job for job in jobs if job['action'] == 'DRECREATEDBASE']
                    if target.casefold() not in databases and not creates:
                        self._add_job(db, import_id, target, None, None, 'DRECREATEDBASE')
                        jobs = [dict(row) for row in db.execute('SELECT * FROM onboarding_jobs WHERE import_id=? ORDER BY rowid', (import_id,))]
                jobs.sort(key=lambda job: job['action'] != 'DRECREATEDBASE')
                for job in jobs:
                    if should_stop and should_stop():
                        break
                    if job['status'] == 'verified':
                        continue
                    if job['status'] in {'intent', 'uncertain'}:
                        # A write may have reached KD before its receipt was retained.
                        # Exact immutable readback can settle it; absence cannot authorize replay.
                        if job['action'] == 'DRECREATEDBASE' and job['database_name'].casefold() in databases:
                            self._job_update(job['job_id'], status='verified', verified_at=now(), error=None)
                        elif job['action'] == 'DREADDDATA' and self._readback(client, job):
                            self._job_update(job['job_id'], status='verified', verified_at=now(), error=None)
                        else:
                            self._job_update(job['job_id'], status='uncertain', error='Submission outcome is uncertain. Retain this receipt; no automatic replay.')
                        continue
                    if job['status'] == 'failed':
                        continue
                    if job['status'] == 'queued':
                        if job['action'] == 'DREADDDATA' and job['database_name'].casefold() not in databases:
                            continue
                        # Commit the intent before any network write. Conditional claim
                        # prevents separate server processes from submitting the same job.
                        with self._db() as db:
                            changed = db.execute("UPDATE onboarding_jobs SET status='intent',intent_at=? WHERE job_id=? AND status='queued'",
                                                 (now(), job['job_id'])).rowcount
                        if not changed:
                            continue
                        try:
                            index_id = submit_native(client, job['database_name'], job['action'],
                                                     self._body(job) if job['action'] == 'DREADDDATA' else b'')
                        except (KDError, OSError, ValueError):
                            self._job_update(job['job_id'], status='uncertain', error='KD submission did not return a retained native receipt. Poll for exact readback; do not replay.')
                            continue
                        self._job_update(job['job_id'], status='submitted', index_id=index_id, error=None)
                        continue  # Submission is never verification.
                    if job['status'] in {'submitted', 'indexing', 'awaiting_readback'}:
                        status, count = client.index_status(job['index_id'])
                        self._job_update(job['job_id'], native_status=status, processed=count)
                        if status in {-1, -34}:
                            if job['action'] == 'DREADDDATA' and count != 1:
                                self._job_update(job['job_id'], status='failed', error='KD job processed an unexpected document count.')
                            elif job['action'] == 'DRECREATEDBASE':
                                if job['database_name'].casefold() in databases:
                                    self._job_update(job['job_id'], status='verified', verified_at=now(), error=None)
                                else:
                                    self._job_update(job['job_id'], status='awaiting_readback', error='Waiting for the created database to become visible.')
                            elif self._readback(client, job):
                                self._job_update(job['job_id'], status='verified', verified_at=now(), error=None)
                            else:
                                self._job_update(job['job_id'], status='awaiting_readback', error='Waiting for exact KD readback; native completion alone is insufficient.')
                        elif status < 0 and status not in {-7, -8, -12, -13, -16, -17}:
                            self._job_update(job['job_id'], status='failed', error='KD indexing failed with status ' + str(status) + '.')
                        else:
                            self._job_update(job['job_id'], status='indexing', error=None)
                self._refresh(import_id)
            except (KDError, OSError) as exc:
                # Do not expose raw endpoints, response bodies or credentials.
                with self._db() as db:
                    db.execute("UPDATE onboarding_imports SET status='delivery_problem',error=?,updated_at=? WHERE import_id=?",
                               ('KD connection or receipt check failed; poll this retained import to retry the check.', now(), import_id))
            return self.receipt(import_id)

    def _refresh(self, import_id):
        with self._db() as db:
            jobs = db.execute('SELECT status,action,verified_at,payload FROM onboarding_jobs WHERE import_id=?', (import_id,)).fetchall()
            states = {row['status'] for row in jobs}
            status = ('verified' if states == {'verified'} else 'uncertain' if 'uncertain' in states or 'intent' in states else
                      'delivery_problem' if 'failed' in states else 'submitted' if states & {'submitted', 'indexing', 'awaiting_readback'} else 'queued')
            stamp = now()
            db.execute('UPDATE onboarding_imports SET status=?,updated_at=?,error=NULL WHERE import_id=?', (status, stamp, import_id))
            import_row = db.execute('SELECT source_id FROM onboarding_imports WHERE import_id=?', (import_id,)).fetchone()
            verified = [row['verified_at'] for row in jobs if row['action'] == 'DREADDDATA' and row['status'] == 'verified']
            if verified and import_row['source_id']:
                latest = max(verified, key=utc_timestamp)
                current = db.execute('SELECT last_verified_at FROM onboarding_sources WHERE source_id=?', (import_row['source_id'],)).fetchone()[0]
                latest = max(filter(None, (latest, current)), key=utc_timestamp)
                db.execute('UPDATE onboarding_sources SET last_verified_at=?,updated_at=? WHERE source_id=?', (latest, stamp, import_row['source_id']))

    def latest_readings(self, asset_id=None):
        if asset_id:
            asset_id = self._asset(asset_id)
        with self._db() as db:
            rows = db.execute('SELECT * FROM onboarding_readings' + (' WHERE asset_id=?' if asset_id else ''), (asset_id,) if asset_id else ()).fetchall()
            jobs = db.execute("SELECT * FROM onboarding_jobs WHERE database_name=? AND status='verified' AND action='DREADDDATA'", (READINGS_DATABASE,)).fetchall()
        latest, verified = {}, {}
        for row in rows:
            key = (row['source_id'], row['asset_id'])
            if key not in latest or utc_timestamp(row['timestamp']) > utc_timestamp(latest[key]['timestamp']):
                latest[key] = row
        for row in jobs:
            payload = json.loads(row['payload'])
            key = (payload['source_id'], payload['asset_id'])
            if key not in verified or utc_timestamp(payload['samples'][-1]['timestamp']) > utc_timestamp(verified[key]['payload']['samples'][-1]['timestamp']):
                verified[key] = {'job': row, 'payload': payload}
        result = []
        for key, row in sorted(latest.items()):
            item = {'source_id': key[0], 'asset_id': key[1], 'latest_sample': json.loads(row['sample']),
                    'last_received_at': row['received_at'], 'import_id': row['import_id'],
                    'verified_sample': None, 'last_verified_at': None, 'prediction_status': 'observation_only'}
            if key in verified:
                entry = verified[key]
                item.update({'verified_sample': entry['payload']['samples'][-1], 'last_verified_at': entry['job']['verified_at'],
                             'verified_reference': entry['job']['reference'], 'synthetic': entry['payload']['synthetic']})
            result.append(item)
        return result

    def verified_snapshot(self, source_id, asset_id):
        self.source(source_id)
        asset_id = self._asset(asset_id)
        with self._db() as db:
            jobs = db.execute("SELECT * FROM onboarding_jobs WHERE database_name=? AND status='verified' AND action='DREADDDATA'", (READINGS_DATABASE,)).fetchall()
        matches = [(row, json.loads(row['payload'])) for row in jobs]
        matches = [(row, data) for row, data in matches if data['source_id'] == source_id and data['asset_id'] == asset_id]
        if not matches:
            raise ValueError('No exactly KD-verified imported snapshot exists for this equipment and source.')
        row, payload = max(matches, key=lambda item: utc_timestamp(item[1]['samples'][-1]['timestamp']))
        return {**payload, 'provenance': {'backend': 'OpenText Knowledge Discovery Content', 'database': READINGS_DATABASE,
                                         'reference': row['reference'], 'payload_sha256': payload_hash(payload),
                                         'verified_at': row['verified_at'], 'retained_verified_readback': True,
                                         'live': False, 'import_id': row['import_id']}}
