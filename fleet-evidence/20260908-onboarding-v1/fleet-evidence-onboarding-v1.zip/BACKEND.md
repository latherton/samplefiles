# Fleet Evidence backend

This Python standard-library service retrieves evidence from the existing Knowledge Discovery Content component. The separate, fixed `FLEET_EVIDENCE_DEMO` database contains the 48 synthetic records. Existing Default/Archive records remain outside the application's retrieval and mutation scope. No generation service is required for search, issue review, source viewing or packet export.

## Owner commands

The deployment owner supplies the observed internal endpoints. The service does not need Docker privileges when these are present:

```sh
export KD_CONTENT_URL=http://172.19.0.2:9100
export KD_INDEX_URL=http://172.19.0.2:9101
export KD_LLM_URL=http://172.19.0.20:8080
export PYTHONDONTWRITEBYTECODE=1

# Read-only plan: does not create or touch the receipt.
python3 index_corpus.py --corpus ./corpus --receipt /mnt/d/KDDeployment/NavyDemo/receipts/index.json

# Apply the dedicated database plan and retain the ingestion receipt.
python3 index_corpus.py --corpus ./corpus --receipt /mnt/d/KDDeployment/NavyDemo/receipts/index.json --apply

python3 server.py --host 127.0.0.1 --port 8095 --corpus ./corpus --static ./static
```

When Content has accepted a job but has not committed it, the indexer sends one journaled `DRESYNC` and keeps polling the original job. `DRESYNC` flushes Content's pending cache and submits no documents. A bounded timeout leaves an incomplete receipt. Resume that exact operation with `--resume`, never by deleting the receipt or rerunning the submitted body. A submission whose receipt is unknown requires inspection; it cannot be safely replayed by the helper.

Each original job has a default 180-second wait (`--timeout`, at most900). A deployment process should allow at least600 seconds for database creation, indexing and verification together. Subsequent `--apply` calls archive a completed receipt and read the live index first; unchanged records cause no create/index/commit calls. Changed fixture records are replaced only by their exact references in the dedicated database. An unknown reference causes refusal, not deletion. There is no truncate, database-delete, NiFi replay, configuration update, container restart or corpus-wide content deduplication action.

The indexer checks every other database's reference list and count before and after. This is reference/count continuity, not a full byte-level snapshot of those databases. A concurrent change causes verification to fail rather than being silently ignored. The current bounded preservation read supports at most10,000 records per other database.

## Retrieval and provenance

`/api/search` uses live Content Query results, with database scope fixed by the server. Blank or `*` is a browse request. The backend verifies each returned record ID, authored-metadata SHA256 and source-file SHA256 against the corpus, then attaches the authored metadata to the live text, reference and score. It never performs local search or local ranking when KD fails. An unavailable or mismatched index returns503JSON with a useful `message` and `live:false`.

Applicability filtering is an explicit application rule over verified fixture metadata: selected asset/model/configuration or authored `all`; unknown identity remains visible with review required. Superseded records appear only with `history=1`. `scope=all` retains other configurations with their mismatch explanation. This does not infer ship readiness, configuration authority, repair completion or compliance from prose.

The issue view performs its own live collection read. The exact-copy finding requires both authored group membership and equal source bytes; separate event IDs and source references are preserved. `WO-104` and `WO-104-COPY` remain separate references for one event. `WO-219` is a distinct later event; `WO-307` belongs to A-18/configurationA. Supersession and missing-identity findings are authored demonstration facts, not autonomous authority judgments.

`/api/bootstrap` distinguishes source-collection counts from live service availability. `/api/health` probes the live database count. Health alone is not full content verification; search and indexing perform the per-record checks. `/api/record/ID` and `/sources/ID` intentionally expose authored metadata/source HTML even if KD is unavailable, and label that origin. Sources use persistent section anchors.

Packet export verifies selected references against the live collection, escapes notes and source text, and embeds complete authored source sections in one HTML file. It retains original references and hashes, review flags, and draft/synthetic labels. Source links use `http://localhost:8095`; set `KD_PUBLIC_URL` to another explicit loopback origin if using a different port. The file can be printed to PDF by the browser. It is not an approved maintenance package.

## Optional generated draft

`POST /api/ask` uses at most six applicable live results, then one bounded request to the optional local llama endpoint. The current model alias is `kd-local-qwen` (`KD_LLM_MODEL` can override). No outbound proxy is used for Content or generation. A single in-process semaphore prevents concurrent draft requests; generation has a60-second timeout,450-token output bound and no automatic retry.

A generated draft must contain citations to the exact retrieved record IDs; any cited section must exist in that record. Unknown citations or missing citations fail visibly. This validates citation identity, **not factual entailment of every sentence**. The response explicitly requires human review; it can express insufficient evidence. No results returns `generated:false` without calling the model. Optional generation still requires live acceptance on the remote service; tests of the adapter do not establish model answer quality.

## Verification and technical references

Run locally with `python3 -m unittest discover -s tests -v`. The focused contracts cover the actual48-record fixture, asset/history boundaries, exact-copy/event separation, unavailable-KD behavior, metadata mismatch, real loopback HTTP routing, packet escaping/absolute source links, scoped mutation parameters, idempotence, exact receipt anchoring, pending-commit recovery, refusal of uncertain replays, other-database continuity, directive/path rejection and optional citation validation. These tests use controlled KD responses; live indexing/API/browser acceptance is separate and is recorded by the deployment owner.

The implementation follows the installed26.1 API family and the cached official26.1 references:

- [DRECREATEDBASE](https://www.microfocus.com/documentation/idol/knowledge-discovery-26.1/Content_26.1_Documentation/Help/Content/Index%20Actions/ManageDatabases/_IX_DRECREATEDBASE.htm): create the one named database.
- [DREADDDATA](https://www.microfocus.com/documentation/idol/knowledge-discovery-26.1/Content_26.1_Documentation/Help/Content/Index%20Actions/IndexData/_IX_DREADDDATA.htm): POST IDX, explicit database, duplicate-mode termination and trailing blank line.
- [KillDuplicates](https://www.microfocus.com/documentation/idol/knowledge-discovery-26.1/Content_26.1_Documentation/Help/Content/Index%20Actions/IndexData/Parameters/_IX_KillDuplicates.htm): `REFERENCE` replacement; explicit `KillDuplicatesMatchTargetDB=True` and fixed `KillDuplicatesMatchDBs` constrain the target.

Live integration assumptions to verify at deployment are standard Content Query `totalhits`, direct hit reference/database and `Print=All` content fields; FE_* field preservation; exact index receipt and IndexerGetStatus structure. The remote preflight already verified GetStatus's database-name structure and observed the endpoints above. The service uses no customer corpus, ACL implementation or Navy identity integration.
