#!/usr/bin/env python3
"""Add/update only the fixed synthetic database; retain exact index receipts."""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import sys
import time

from corpus_model import Corpus, canonical, sha
from kd_client import DATABASE, KDClient, KDError

ROOT = Path(__file__).resolve().parent


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def save(path, report):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.tmp')
    with temp.open('w', encoding='utf-8', newline='\n') as out:
        json.dump(report, out, ensure_ascii=False, indent=2)
        out.write('\n')
        out.flush()
        os.fsync(out.fileno())
    os.replace(temp, path)


@contextmanager
def locked(path):
    """POSIX owner execution uses a kernel lock, released on crash; no daemon."""
    lock = path.with_name(path.name + '.lock')
    lock.parent.mkdir(parents=True, exist_ok=True)
    with lock.open('a+b') as handle:
        if os.name == 'posix':
            import fcntl
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise ValueError('This indexing receipt is already in use.') from exc
        else:
            import msvcrt
            handle.seek(0)
            if not handle.read(1):
                handle.write(b'0')
                handle.flush()
            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as exc:
                raise ValueError('This indexing receipt is already in use.') from exc
        yield


def snapshot_other_databases(client):
    result = {}
    for name in client.databases():
        if name.casefold() == DATABASE.casefold():
            continue
        data = client.query('*', database=name, limit=10000, print_fields=False)
        if data['total'] != len(data['hits']):
            raise KDError('An existing database exceeds the bounded preservation snapshot.', 'preservation_unverified')
        refs = sorted(hit['reference'] for hit in data['hits'])
        if any(not ref for ref in refs):
            raise KDError('An existing database has a missing reference.', 'preservation_unverified')
        result[name] = {'records': len(refs), 'references_sha256': sha(canonical(refs))}
    return result


def inventory(client, corpus):
    exists = any(name.casefold() == DATABASE.casefold() for name in client.databases())
    existing = client.query('*', limit=1000) if exists else {'total': 0, 'hits': []}
    if existing['total'] != len(existing['hits']):
        raise KDError('Demo inventory exceeds the bounded result limit.', 'kd_results_incomplete')
    seen, changed = {}, []
    for hit in existing['hits']:
        if hit['reference'] not in corpus.by_reference or hit['reference'] in seen:
            raise KDError('Unexpected or repeated reference in the dedicated database; no deletion is permitted.', 'kd_corpus_mismatch')
        seen[hit['reference']] = hit
    for record in corpus.records.values():
        hit = seen.get(record['reference'])
        fields = hit['fields'] if hit else {}
        ident = record['id']
        if (fields.get('fe_record_id') != ident or fields.get('fe_record_sha256') != corpus.hashes[ident]
                or fields.get('fe_source_sha256') != corpus.source_hashes[ident]
                or fields.get('fe_text_sha256') != sha(corpus.text(record).encode())):
            changed.append(ident)
    return {'database': DATABASE, 'database_exists': exists, 'existing_records': len(seen),
            'corpus_records': len(corpus.records), 'changed_ids': changed,
            'manifest_sha256': corpus.manifest_sha256}


def idx_bytes(corpus, ids):
    documents = []
    for ident in ids:
        record = corpus.records[ident]
        title, text = record['title'], corpus.text(record)
        if any(c in title for c in '\r\n\0') or '\0' in text or re.search(r'^\s*#DRE', text, flags=re.I | re.M):
            raise ValueError('Source text cannot contain IDX directives or embedded nulls.')
        fields = {'FE_RECORD_ID': ident, 'FE_RECORD_SHA256': corpus.hashes[ident],
                  'FE_SOURCE_SHA256': corpus.source_hashes[ident], 'FE_TEXT_SHA256': sha(text.encode()),
                  'FE_SYNTHETIC': 'TRUE'}
        lines = ['#DREREFERENCE ' + record['reference'], '#DRETITLE ' + title]
        lines += [f'#DREFIELD {name}="{value}"' for name, value in fields.items()]
        lines += ['#DRECONTENT', text, '#DREENDDOC']
        documents.append('\n'.join(lines))
    # 26.1 suffix is the duplicate mode; explicit target-DB parameters also scope it.
    return ('\n'.join(documents) + '\n#DREENDDATAREFERENCE\r\n\r\n').encode('utf-8')


class Indexer:
    def __init__(self, client, corpus, receipt, timeout=180, poll=1):
        self.client, self.corpus, self.receipt = client, corpus, Path(receipt)
        self.timeout, self.poll = timeout, poll
        self.report = None

    def write(self, stage=None):
        if stage:
            self.report['stage'] = stage
        self.report['updated_at'] = timestamp()
        save(self.receipt, self.report)

    def submit(self, action, ids=None):
        ids = ids or []
        body = idx_bytes(self.corpus, ids) if action == 'DREADDDATA' else b''
        job = {'action': action, 'ids': ids, 'body_sha256': sha(body), 'intent_at': timestamp(), 'index_id': None,
               'complete': False, 'commit': None}
        self.report['jobs'].append(job)
        self.write('index-request-intent')
        job['index_id'] = self.client.index(action, body)
        self.write('index-receipt-retained')
        self.wait(job)

    def wait(self, job):
        if job.get('index_id') is None:
            raise KDError('A prior index request has an uncertain outcome. Inspect the intent; do not resubmit.', 'index_receipt_uncertain')
        deadline = time.monotonic() + self.timeout
        while time.monotonic() < deadline:
            status, count = self.client.index_status(job['index_id'])
            job['last_status'], job['documents_processed'] = status, count
            self.write('waiting-for-exact-index-receipt')
            if status == -1:
                if job['action'] == 'DREADDDATA' and count != len(job['ids']):
                    raise KDError('The completed index job processed an unexpected record count.', 'index_count_mismatch')
                job['complete'] = True
                self.write('index-job-complete')
                return
            if status == -34 and job['commit'] is None:
                if job['action'] == 'DREADDDATA' and count != len(job['ids']):
                    raise KDError('Pending commit has an unexpected processed count.', 'index_count_mismatch')
                # DRESYNC flushes the Content pending index cache. It submits no records.
                job['commit'] = {'intent_at': timestamp(), 'index_id': None}
                self.write('pending-cache-commit-intent')
                job['commit']['index_id'] = self.client.index('DRESYNC')
                self.write('pending-cache-commit-receipt-retained')
            elif status < 0 and status not in {-7, -8, -12, -13, -16, -17, -34}:
                raise KDError('The exact index job returned failure status ' + str(status) + '.', 'index_failed')
            time.sleep(self.poll)
        raise KDError('Index wait timed out. Use --resume with this receipt; no records will be resubmitted.', 'index_pending')

    def run(self, resume=False):
        if resume:
            self.report = json.loads(self.receipt.read_text(encoding='utf-8'))
            if (self.report.get('manifest_sha256') != self.corpus.manifest_sha256 or self.report.get('database') != DATABASE
                    or self.report.get('complete') is True or not isinstance(self.report.get('jobs'), list)):
                raise ValueError('Receipt is not a resumable operation for this exact corpus.')
            if self.report.get('source_hashes') != self.corpus.source_hashes:
                raise ValueError('Source bytes changed after the retained index intent.')
            for job in self.report['jobs']:
                if not job['complete']:
                    self.wait(job)
        else:
            if self.receipt.exists():
                prior = json.loads(self.receipt.read_text(encoding='utf-8'))
                if prior.get('complete') is not True:
                    raise ValueError('Incomplete receipt already exists. Use --resume, never replay the index submission.')
                archived = self.receipt.with_name(self.receipt.stem + '-' + sha(self.receipt.read_bytes())[:16] + '.json')
                if not archived.exists():
                    with archived.open('xb') as out:
                        out.write(self.receipt.read_bytes())
            self.report = {'version': 1, 'started_at': timestamp(), 'database': DATABASE,
                           'manifest_sha256': self.corpus.manifest_sha256, 'source_hashes': self.corpus.source_hashes,
                           'complete': False, 'jobs': []}
            self.report['other_databases_before'] = snapshot_other_databases(self.client)
            self.write('preservation-baseline-retained')
        try:
            if snapshot_other_databases(self.client) != self.report['other_databases_before']:
                raise KDError('Another database changed since the retained baseline; inspect before continuing.', 'preservation_changed')
            plan = inventory(self.client, self.corpus)
            self.report['plan'] = plan
            self.write('dedicated-database-plan-retained')
            if not plan['database_exists']:
                if any(j['action'] == 'DRECREATEDBASE' for j in self.report['jobs']):
                    raise KDError('A completed database-create receipt is not reflected in inventory; no replay.', 'index_verification_failed')
                self.submit('DRECREATEDBASE')
            if plan['changed_ids']:
                if any(j['action'] == 'DREADDDATA' for j in self.report['jobs']):
                    raise KDError('Previously submitted records did not verify; no automatic reindex.', 'index_verification_failed')
                self.submit('DREADDDATA', plan['changed_ids'])
            final = inventory(self.client, self.corpus)
            if final['changed_ids'] or final['existing_records'] != len(self.corpus.records):
                raise KDError('Live demo index does not match the complete corpus.', 'index_verification_failed')
            data = self.client.query('*', limit=1000)
            verified = self.corpus.map_hits(data, 'A-17', scope='all', history=True)
            if len(verified) != len(self.corpus.records):
                raise KDError('Not every record returned verified live text.', 'index_verification_failed')
            after = snapshot_other_databases(self.client)
            self.report['other_databases_after'] = after
            if after != self.report['other_databases_before']:
                raise KDError('Existing database reference/count continuity did not pass.', 'preservation_changed')
            self.report.update(complete=True, indexed_records=len(verified),
                               other_database_references_and_counts_preserved=True,
                               duplicate_source_references_retained=True,
                               verification='Live KD references, metadata hashes, source hashes and nonempty text; other databases reference/count continuity.')
            self.write('complete')
            return self.report
        except (KDError, ValueError, OSError) as exc:
            self.report['error'] = {'type': type(exc).__name__, 'message': str(exc)}
            self.write('failed-or-pending-no-automatic-resubmission')
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--corpus', type=Path, default=ROOT / 'corpus')
    parser.add_argument('--receipt', type=Path, required=True)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--apply', action='store_true')
    group.add_argument('--resume', action='store_true')
    parser.add_argument('--timeout', type=int, default=180)
    args = parser.parse_args()
    if not 1 <= args.timeout <= 900:
        parser.error('--timeout must be between 1 and 900 seconds per original receipt.')
    corpus, client = Corpus(args.corpus), KDClient()
    if not args.apply and not args.resume:
        print(json.dumps(dict(inventory(client, corpus), other_databases=snapshot_other_databases(client), read_only=True), indent=2))
        return
    with locked(args.receipt):
        report = Indexer(client, corpus, args.receipt, args.timeout).run(args.resume)
    print(json.dumps({'complete': report['complete'], 'indexed_records': report['indexed_records'], 'receipt': str(args.receipt)}))


if __name__ == '__main__':
    try:
        main()
    except (KDError, ValueError, OSError) as error:
        print(type(error).__name__ + ': ' + str(error), file=sys.stderr)
        sys.exit(1)
