"""Evaluate a frozen illustrative rule against supplied, complete held-out histories.

Input is a JSON list. Each history requires id, asset_id, partition='held-out',
provenance (nonempty text), samples (the five telemetry fields, quality, and UTC
timestamp), event_timestamp (first adjudicated event, or null), and followup_end
(UTC timestamp through which outcome ascertainment is claimed complete). Rows
must remain at one-minute cadence; represent gaps explicitly with missing rows.
Metadata statements, independence and event adjudication are not verified here.

By default this CLI validates input only. --apply-demo-rule explicitly applies
the uncalibrated synthetic thresholds/corrections for an offline analytic study;
it does not enable condition scoring for live real-source equipment.
"""
import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import re
import statistics

import telemetry


PROTOCOL_VERSION = 'fleet-supplied-history-evaluation-v1'
WINDOW_SAMPLES = 181
FIRST_SCORE_INDEX = 19
HORIZON_MINUTES = 120
USEFUL_LEAD_MINUTES = 10
MAX_HISTORIES = 500
MAX_TOTAL_SAMPLES = 500000
MAX_FILE_BYTES = 100 * 1024 * 1024
IDENTIFIER = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,119}')


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     allow_nan=False).encode()).hexdigest()


def _text(value, label, maximum=2000):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise ValueError(f'{label} must be nonempty text of at most {maximum} characters.')
    return value.strip()


def _identifier(value, label):
    value = _text(value, label, 120)
    if not IDENTIFIER.fullmatch(value):
        raise ValueError(f'{label} must contain letters, digits, periods, underscores or hyphens.')
    return value


def _timestamp(value, label):
    if not isinstance(value, str) or not telemetry.TIMESTAMP_PATTERN.fullmatch(value):
        raise ValueError(f'{label} must be a UTC ISO timestamp ending in Z.')
    try:
        return datetime.fromisoformat(value[:-1] + '+00:00')
    except ValueError:
        raise ValueError(f'{label} is not a valid timestamp.') from None


def validate_histories(histories):
    """Validate full supplied histories without deriving labels from measurements."""
    if not isinstance(histories, list) or not 1 <= len(histories) <= MAX_HISTORIES:
        raise ValueError(f'Provide a JSON list of 1 through {MAX_HISTORIES} complete histories.')
    ids, measurements, ranges, total_samples = set(), set(), {}, 0
    normalized = []
    for supplied in histories:
        if not isinstance(supplied, dict):
            raise ValueError('Each history must be an object.')
        ident = _identifier(supplied.get('id'), 'History ID')
        asset = _identifier(supplied.get('asset_id'), 'Equipment ID')
        if ident.casefold() in ids:
            raise ValueError('History IDs must be unique, including letter case variants.')
        ids.add(ident.casefold())
        if supplied.get('partition') != 'held-out':
            raise ValueError(f'{ident}: only complete histories marked partition="held-out" are accepted; no training or tuning is performed.')
        provenance = _text(supplied.get('provenance'), f'{ident} provenance')
        samples = supplied.get('samples')
        if not isinstance(samples, list) or not samples:
            raise ValueError(f'{ident}: samples must be a nonempty list.')
        stamps = telemetry._validate_samples(samples)
        total_samples += len(samples)
        if total_samples > MAX_TOTAL_SAMPLES:
            raise ValueError(f'Input exceeds the {MAX_TOTAL_SAMPLES:,}-sample evaluation bound.')
        if any((right - left).total_seconds() != 60 for left, right in zip(stamps, stamps[1:])):
            raise ValueError(f'{ident}: the frozen demo rule requires one-minute cadence; provide explicit missing rows for gaps.')
        # Only declared measurement fields reach the analyzer. Labels or other
        # metadata smuggled into a sample cannot become model features.
        samples = [{key: row[key] for key in ('timestamp', *telemetry.SIGNALS, 'quality')} for row in samples]
        sample_hash = digest(samples)
        if sample_hash in measurements:
            raise ValueError('Duplicate measurement histories are not independent evaluation units.')
        measurements.add(sample_hash)
        if 'event_timestamp' not in supplied:
            raise ValueError(f'{ident}: event_timestamp is required; use null only when no event was ascertained through followup_end.')
        event = _timestamp(supplied['event_timestamp'], f'{ident} event_timestamp') if supplied['event_timestamp'] is not None else None
        end = _timestamp(supplied.get('followup_end'), f'{ident} followup_end')
        if end > datetime.now(timezone.utc):
            raise ValueError(f'{ident}: complete outcome follow-up cannot be claimed in the future.')
        if end < stamps[-1]:
            raise ValueError(f'{ident}: followup_end cannot precede the final measurement.')
        if event is not None and not stamps[0] <= event <= end:
            raise ValueError(f'{ident}: event_timestamp must lie between the first measurement and followup_end.')
        for start, prior_end in ranges.get(asset.casefold(), []):
            if stamps[0] <= prior_end and end >= start:
                raise ValueError(f'{ident}: overlapping histories for the same equipment cannot be counted as independent units.')
        ranges.setdefault(asset.casefold(), []).append((stamps[0], end))
        normalized.append(dict(id=ident, asset_id=asset, partition='held-out', provenance=provenance,
                               samples=samples, event_timestamp=supplied['event_timestamp'], followup_end=supplied['followup_end']))
    return normalized


def _alert_score(alerts, event, eligible_issues, eligible_event):
    first = alerts[0].isoformat().replace('+00:00', 'Z') if alerts else None
    if event is None:
        eligible = set(eligible_issues)
        complete_alerts = [stamp for stamp in alerts if stamp in eligible]
        return dict(alert_count=len(alerts), first_alert_at=first,
                    false_alarm_with_complete_followup=bool(complete_alerts) if eligible else None,
                    alerts_with_censored_followup=len(alerts) - len(complete_alerts),
                    detected_by_event=None, useful_warning=None, lead_minutes=None)
    matched = [stamp for stamp in alerts if event - timedelta(minutes=HORIZON_MINUTES) <= stamp <= event]
    lead = (event - matched[0]).total_seconds() / 60 if matched else None
    return dict(alert_count=len(alerts), first_alert_at=first, false_alarm_with_complete_followup=None,
                alerts_with_censored_followup=0, detected_by_event=bool(matched) if eligible_event else None,
                useful_warning=(lead is not None and lead >= USEFUL_LEAD_MINUTES) if eligible_event else None,
                lead_minutes=round(lead, 6) if lead is not None else None,
                alerts_before_matching_horizon=sum(stamp < event - timedelta(minutes=HORIZON_MINUTES) for stamp in alerts))


def _evaluate_validated(item, analyzer):
    event = _timestamp(item['event_timestamp'], 'event_timestamp') if item['event_timestamp'] else None
    end = _timestamp(item['followup_end'], 'followup_end')
    model_alerts, baseline_alerts, complete_issues, all_issues = [], [], [], []
    abstentions = 0
    samples = item['samples']
    for index in range(FIRST_SCORE_INDEX, len(samples)):
        stamp = _timestamp(samples[index]['timestamp'], 'sample timestamp')
        if event is not None and stamp > event:
            break
        all_issues.append(stamp)
        if stamp + timedelta(minutes=HORIZON_MINUTES) <= end:
            complete_issues.append(stamp)
        # Copies preserve supplied observations even for a mutating test double.
        # Neither outcome metadata nor future measurements reach the analyzer.
        prefix = [dict(row) for row in samples[max(0, index - WINDOW_SAMPLES + 1):index + 1]]
        analysis = analyzer(prefix, synthetic=True)
        if analysis['status'] in ('watch', 'review') or analysis['forecast']['available']:
            model_alerts.append(stamp)
        adjusted = analysis['latest']['normalized_vibration_mm_s']
        if analysis['status'] != 'insufficient' and adjusted is not None and adjusted >= telemetry.REVIEW_VIBRATION_MM_S:
            baseline_alerts.append(stamp)
        abstentions += analysis['status'] == 'insufficient'
    eligible_event = event is not None and bool(all_issues)
    eligible_non_event = event is None and bool(complete_issues)
    exclusions = []
    if not all_issues:
        exclusions.append('No scoring issue with the required 20-observation prefix before the event or history end.')
    elif event is None and not complete_issues:
        exclusions.append('Censored non-event history: no issue has complete 120-minute outcome follow-up.')
    return dict(history_id=item['id'], asset_id=item['asset_id'], provenance=item['provenance'],
                history_sha256=digest(item), measurement_sha256=digest(samples), sample_count=len(samples),
                event_timestamp=item['event_timestamp'], followup_end=item['followup_end'],
                eligible_for_event_metrics=eligible_event, eligible_for_non_event_metrics=eligible_non_event,
                scoring_opportunities=len(all_issues), complete_followup_issues=len(complete_issues),
                censored_issue_count=len(all_issues) - len(complete_issues) if event is None else 0,
                condition_abstentions=abstentions, exclusion_reasons=exclusions,
                model=_alert_score(model_alerts, event, complete_issues, eligible_event),
                threshold_baseline=_alert_score(baseline_alerts, event, complete_issues, eligible_event))


def _ratio(numerator, denominator):
    return round(numerator / denominator, 6) if denominator else None


def summarize(rows):
    events = [row for row in rows if row['eligible_for_event_metrics']]
    non_events = [row for row in rows if row['eligible_for_non_event_metrics']]
    result = dict(histories=len(rows), eligible_event_histories=len(events),
                  eligible_non_event_histories=len(non_events), excluded_histories=sum(bool(r['exclusion_reasons']) for r in rows),
                  scoring_opportunities=sum(r['scoring_opportunities'] for r in rows),
                  censored_non_event_issues=sum(r['censored_issue_count'] for r in rows),
                  condition_abstentions=sum(r['condition_abstentions'] for r in rows))
    for key in ('model', 'threshold_baseline'):
        false = sum(row[key]['false_alarm_with_complete_followup'] for row in non_events)
        missed = sum(not row[key]['detected_by_event'] for row in events)
        useful = sum(row[key]['useful_warning'] for row in events)
        leads = [row[key]['lead_minutes'] for row in events if row[key]['lead_minutes'] is not None]
        result[key] = dict(false_alarm_histories=false, non_event_denominator=len(non_events),
                           false_alarm_rate=_ratio(false, len(non_events)), missed_events=missed,
                           event_denominator=len(events), missed_event_rate=_ratio(missed, len(events)),
                           events_with_useful_warning=useful, useful_warning_rate=_ratio(useful, len(events)),
                           median_lead_minutes_among_detected=statistics.median(leads) if leads else None)
    return result


def run_evaluation(histories, apply_demo_rule=False, event_definition='Supplied first event; outcome adjudication has not been verified.', analyzer=None):
    if type(apply_demo_rule) is not bool:
        raise ValueError('apply_demo_rule must be a boolean.')
    event_definition = _text(event_definition, 'Event definition')
    input_hash = digest(histories)
    items = validate_histories(histories)
    model_path = Path(telemetry.__file__)
    model_hash = hashlib.sha256(model_path.read_bytes()).hexdigest()
    report = dict(protocol_version=PROTOCOL_VERSION, input_sha256=input_hash, normalized_input_sha256=digest(items),
                  evaluation_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  model_version=telemetry.MODEL_VERSION, model_source_sha256=model_hash,
                  mode='offline_demo_rule_evaluation' if apply_demo_rule else 'validation_only',
                  apply_demo_rule=apply_demo_rule, synthetic_corrections_applied=apply_demo_rule,
                  custom_analyzer_used=analyzer is not None, model_tuned_during_evaluation=False,
                  independence_verified=False, equipment_failure_validation=False,
                  event_definition=event_definition, summary=None,
                  protocol=dict(cadence_seconds=60, observation_window_samples=WINDOW_SAMPLES,
                                first_score_sample_count=FIRST_SCORE_INDEX + 1, matching_horizon_minutes=HORIZON_MINUTES,
                                useful_warning_minutes=USEFUL_LEAD_MINUTES,
                                model_alert='watch/review status or an available forecast from the frozen illustrative rule.',
                                baseline_alert='Adjusted current vibration at least the existing illustrative 4.3 mm/s review threshold; same preprocessing, no projection.',
                                event_matching='First matching warning in the 120 minutes through the supplied first event, including the event timestamp; lead uses actual timestamps.',
                                false_alarm_rate='Fraction of eligible non-event histories with any alert at an issue having 120 complete minutes of outcome follow-up. Censored later issues are excluded. This is not alarms per hour.',
                                independence='Full histories are the evaluation units. Supplied held-out/provenance labels are recorded, not independently verified. Same-equipment overlap and identical measurement histories are rejected.'),
                  limitations=[
                      'No equipment-specific calibration, engineering approval, target adjudication or independent provenance verification is provided.',
                      'Opt-in applies the synthetic demo corrections to supplied measurements only for offline analysis; live real-source observations remain observation-only.',
                      'The demo forecasts an illustrative vibration threshold, which may differ from the supplied event. Agreement with an event label does not establish failure prediction or remaining useful life.',
                      'The supplier must ascertain the first event or absence of events through followup_end. No event label is inferred from measurements, and metadata cannot establish that outcome assessment was unbiased.',
                      'Missing and suspect samples remain scored opportunities and can produce abstentions or missed events. Histories with no scoring opportunity are reported as exclusions.',
                      'False alarms use only complete outcome horizons; late censored alerts are shown separately. Variable history length means exposure differs between history-level denominators.',
                      'Whole histories may remain correlated across equipment, operating conditions or maintenance interventions; duplicate and overlap checks do not establish statistical independence.',
                      'No fitted parameters, threshold search, uncertainty calibration or repair-causality claim is produced.',
                  ])
    if apply_demo_rule:
        rows = [_evaluate_validated(item, analyzer or telemetry.analyze_samples) for item in items]
        report.update(summary=summarize(rows), histories=rows,
                      exclusions=[dict(history_id=r['history_id'], reasons=r['exclusion_reasons']) for r in rows if r['exclusion_reasons']])
    else:
        report.update(histories=[dict(history_id=i['id'], asset_id=i['asset_id'], provenance=i['provenance'],
                                      sample_count=len(i['samples']), history_sha256=digest(i),
                                      event_timestamp=i['event_timestamp'], followup_end=i['followup_end']) for i in items],
                      exclusions=[], note='Input validated; no model was applied. Use --apply-demo-rule to opt into offline scoring with uncalibrated illustrative corrections.')
    if hashlib.sha256(model_path.read_bytes()).hexdigest() != model_hash:
        raise RuntimeError('The model source changed during evaluation; discard this run.')
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--event-definition', required=True, help='Describe how the supplied first event was independently ascertained; no automatic failure target is assumed.')
    parser.add_argument('--apply-demo-rule', action='store_true', help='Opt into offline use of uncalibrated synthetic corrections and thresholds.')
    args = parser.parse_args(argv)
    if args.input.resolve() == args.output.resolve() or (args.input.exists() and args.output.exists() and args.input.samefile(args.output)):
        parser.error('Input and output must be different files; original histories must be retained.')
    try:
        if args.input.stat().st_size > MAX_FILE_BYTES:
            raise ValueError('Input exceeds the 100 MiB file limit.')
        raw = args.input.read_bytes()
        histories = json.loads(raw.decode('utf-8-sig'))
        report = run_evaluation(histories, args.apply_demo_rule, args.event_definition)
        report['input_file_sha256'] = hashlib.sha256(raw).hexdigest()
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    print(json.dumps(dict(report=str(args.output.resolve()), mode=report['mode'], summary=report['summary']), indent=2))


if __name__ == '__main__':
    main()
