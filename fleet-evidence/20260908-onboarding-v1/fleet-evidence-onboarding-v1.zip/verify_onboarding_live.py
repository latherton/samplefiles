#!/usr/bin/env python3
"""Read-only installed onboarding acceptance; --exercise opts into a synthetic demo.

Run from the installed release as Linux root to inspect protected state and the
existing service contract. Default checks use GET and read-only KD inventory.
--exercise creates uniquely named, clearly fictional equipment, catalog parts,
installation/replacement history, stock, one source, one mixed CSV import and
one manual through the loopback application only. These records remain retained.
No cleanup, mission start/pause, case edits, service restart or cache sync occurs.
Every mutation intent is recorded before dispatch; uncertain writes are not retried.
"""
import argparse
from collections import Counter
from datetime import datetime, timedelta, timezone
import importlib
import json
import os
from pathlib import Path
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

from deploy_onboarding_update import (APP_STATE, ORIGIN, SERVICE, UNIT, app_state_snapshot,
                                     canonical, command, container_snapshot, database_snapshot,
                                     digest, fresh_write, inspect_unit, no_symlinks, now, require)

IMPORT_DATABASES = {'FLEET_IMPORT_READINGS', 'FLEET_IMPORT_DOCUMENTS'}
MAX_BODY = 8 * 1024 * 1024


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, message, headers, newurl):
        raise RuntimeError('Unexpected redirect; no alternate destination was followed.')


def mission_identity(mission):
    run = mission.get('run', {})
    require(run.get('state') in {'idle', 'paused'} and run.get('source_id') == 'mission-pump-feed',
            'The existing mission must remain idle or paused; this helper never changes its state.')
    require(isinstance(mission.get('assets'), list) and {item.get('asset_id') for item in mission['assets']} == {'A-17', 'A-18'},
            'Both existing synthetic mission assets must be available.')
    return {'run': {key: run.get(key) for key in ('id', 'state', 'source_id', 'step')},
            'history_samples': mission.get('total_history_samples'), 'case_counts': mission.get('case_counts'),
            'assets': [{'asset_id': item['asset_id'], 'acquired_samples': item.get('acquired_samples'),
                        'last_observed_at': item.get('last_observed_at'), 'delivery': item.get('delivery'),
                        'snapshot_id': (item.get('telemetry') or {}).get('snapshot_id')}
                       for item in sorted(mission['assets'], key=lambda item: item['asset_id'])]}


def preserved_rows(before, after, allow_additions=False):
    """Compare multisets, retaining duplicate logical rows and original schemas."""
    for database, tables in before['table_rows'].items():
        require(database in after['table_rows'], 'An existing state database disappeared.')
        require(set(before['databases'][database]) == set(after['databases'][database]),
                'The table inventory of an existing state database changed.')
        for table, value in tables.items():
            other = after['table_rows'][database].get(table)
            require(other is not None and other['schema_sha256'] == value['schema_sha256'],
                    'An existing state table schema changed.')
            if allow_additions and database in {'registry.sqlite3', 'onboarding.sqlite3'}:
                require(not (Counter(value['row_sha256']) - Counter(other['row_sha256'])),
                        'A pre-existing registry or onboarding row changed or disappeared.')
            else:
                require(other == value, 'A retained case, mission or application table changed.')
    require(set(after['databases']) == set(before['databases']), 'An unexpected durable database appeared.')
    require(before['case_rows'] == after['case_rows'] and before['mission_states'] == after['mission_states'],
            'An existing case or paused mission changed.')
    return True


def preserved_databases(before, after, additions=None):
    additions = additions or {}
    require(set(after) - set(before) <= set(additions), 'An unexpected KD database appeared.')
    require(set(before) <= set(after), 'An existing KD database disappeared.')
    for database in set(before) | set(additions):
        expected = before.get(database, {'count': 0, 'references': []})
        extra = additions.get(database, [])
        require(database in after and after[database]['count'] == expected['count'] + len(extra)
                and after[database]['references'] == sorted(set(expected['references']) | set(extra)),
                'KD reference sets/counts differ from the prior inventory plus explicitly recorded imports.')
    return True


class Verification:
    def __init__(self, output, exercise=False, timeout=600):
        no_symlinks(Path(output).absolute())
        self.path = Path(output).resolve()
        no_symlinks(self.path)
        require(not self.path.exists(), 'Choose a fresh report path; earlier receipts must remain intact.')
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fresh_write(self.path, b'{}\n')
        self.deadline = time.monotonic() + timeout
        self.exercise = exercise
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        self.client, self.release, self.unit_raw = None, None, None
        self.r = {'complete': False, 'passed': False, 'started_at': now(), 'origin': ORIGIN,
                  'exercise': exercise, 'application_mutations_authorized_by_cli': exercise,
                  'direct_native_index_calls': False, 'cache_sync_requested': False,
                  'service_restarts': False, 'container_restarts': False, 'browser_acceptance': False,
                  'timeout_seconds': timeout, 'checks': [], 'stages': [], 'mutations': [],
                  'scope': 'Installed API, exact KD import readback and preservation checks; no operational prediction validation or browser acceptance.'}
        self.save()

    def save(self):
        self.r['updated_at'] = now()
        temporary = self.path.with_name(self.path.name + '.updating')
        fresh_write(temporary, json.dumps(self.r, indent=2, allow_nan=False).encode() + b'\n')
        os.replace(temporary, self.path)

    def stage(self, name):
        value = {'stage': name, 'at': now()}
        self.r['stages'].append(value)
        self.save()
        print(json.dumps(value), flush=True)

    def check(self, name, condition, **details):
        self.r['checks'].append({'name': name, 'passed': bool(condition), **details})
        self.save()
        require(condition, name)

    def request(self, path, body=None, expected=200, binary=False):
        require(path.startswith('/api/') and not path.startswith('//') and '\\' not in path and '#' not in path,
                'Only bounded loopback application API routes are supported.')
        require(body is None or self.exercise, 'Mutating requests require the explicit --exercise flag.')
        remaining = self.deadline - time.monotonic()
        require(remaining > 0, 'The bounded verification deadline expired.')
        intent = None
        if body is not None:
            # These bodies contain only this helper's synthetic data, never credentials.
            intent = {'path': path, 'body': body, 'intent_at': now(), 'result': 'unknown'}
            self.r['mutations'].append(intent)
            self.save()
        request = urllib.request.Request(ORIGIN + path, data=canonical(body) if body is not None else None,
                                         headers={'Content-Type': 'application/json', 'Cache-Control': 'no-store'})
        try:
            response = self.opener.open(request, timeout=min(45, max(.1, remaining)))
        except urllib.error.HTTPError as error:
            response = error
        with response:
            raw, status = response.read(MAX_BODY + 1), response.code
            content_type = response.headers.get('Content-Type', '')
        require(len(raw) <= MAX_BODY, 'The application response exceeded its bound.')
        if intent is not None:
            intent.update(result='response_received', status=status, received_at=now())
            self.save()
        require(status == expected, 'Unexpected HTTP status ' + str(status) + ' for ' + path + '; writes are not replayed.')
        if binary:
            return raw
        require('application/json' in content_type, 'Expected an application JSON response.')
        value = json.loads(raw)
        require(isinstance(value, dict), 'Expected a JSON object.')
        return value

    def prepare(self):
        self.stage('checking-installed-release-and-paused-runtime')
        no_symlinks(UNIT)
        require(UNIT.is_file(), 'The installed application service unit is absent.')
        self.unit_raw = UNIT.read_bytes()
        _, self.release, environment = inspect_unit(self.unit_raw)
        require(Path(__file__).resolve().parent == self.release,
                'Run the verification helper from the active installed release directory.')
        for property_name, expected in (('FragmentPath', str(UNIT)), ('WorkingDirectory', str(self.release)),
                                        ('User', 'nobody'), ('Group', 'nogroup'), ('StateDirectory', 'fleet-evidence')):
            require(command(['systemctl', 'show', SERVICE, '--property=' + property_name, '--value']).strip() == expected,
                    'The loaded service contract differs from its retained unit.')
        require(not command(['systemctl', 'show', SERVICE, '--property=DropInPaths', '--value']).strip(),
                'Unexpected service drop-ins require review.')
        require(command(['systemctl', 'is-active', SERVICE]).strip() == 'active', 'The app service must already be active.')
        require((APP_STATE / 'registry.sqlite3').is_file() and (APP_STATE / 'onboarding.sqlite3').is_file(),
                'Run the reviewed onboarding deployment first; this verifier does not initialize the installed registry.')
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(self.release))
        kd = importlib.import_module('kd_client')
        # Deliberately omit the index endpoint: independent verification only reads KD.
        self.client = kd.KDClient(aci_url=environment['KD_CONTENT_URL'], index_url=None, timeout=10)
        self.r.update(release=str(self.release), unit_sha256=digest(self.unit_raw),
                      connection_sha256=digest(self.client.aci_url.encode()))

    def capture(self):
        return {'state': app_state_snapshot(), 'databases': database_snapshot(self.client),
                'containers': container_snapshot(), 'mission': mission_identity(self.request('/api/mission')),
                'cases': self.request('/api/cases')}

    def readonly_checks(self):
        health = self.request('/api/health')
        self.check('existing-48-evidence-record-health', health.get('ok') is True and health.get('indexed_records') == 48)
        registry = self.request('/api/registry/equipment')
        equipment = registry.get('equipment')
        self.check('registry-expands-beyond-two-pumps', isinstance(equipment, list) and len(equipment) >= 6
                   and {'A-17', 'A-18'}.issubset({row.get('id') for row in equipment}), count=len(equipment or []))
        fleet = self.request('/api/fleet')
        self.check('fleet-covers-registered-inventory', {row['id'] for row in fleet.get('equipment', [])} == {row['id'] for row in equipment}
                   and fleet.get('summary', {}).get('equipment') == len(equipment))
        imports, sources = self.request('/api/imports'), self.request('/api/source-configs')
        self.check('durable-import-and-source-routes', isinstance(imports.get('imports'), list) and isinstance(sources.get('sources'), list))
        self.check('saved-sources-separate-observation-and-verification', all(isinstance(source.get('health'), dict)
                   and all(key in source for key in ('last_received_at', 'last_verified_at', 'latest_reading_at'))
                   and source.get('prediction_status') == 'observation_only' for source in sources['sources']))
        model = self.request('/api/model-evidence')
        self.check('model-evidence-retains-illustrative-boundary', model.get('status') == 'illustrative'
                   and model.get('synthetic_only') is True and model.get('model_matches') is True
                   and model.get('evaluation_matches') is True and model.get('external_histories', {}).get('available') is False)
        self.r['api_snapshot'] = {'registry': registry, 'fleet': fleet, 'imports': imports, 'sources': sources,
                                  'model_evidence': model}
        self.save()

    def wait_receipt(self, receipt):
        ident = receipt['import_id']
        previous = None
        while time.monotonic() < self.deadline:
            if receipt['status'] == 'verified':
                self.check('import-verified-' + ident, receipt['verified_count'] == receipt['accepted_count']
                           and all(job['status'] == 'verified' for job in receipt['jobs']))
                return receipt
            require(receipt['status'] not in {'rejected', 'duplicates_only'}
                    and not any(job['status'] == 'failed' for job in receipt['jobs']),
                    'A synthetic acceptance import was rejected or failed. Retain the receipt; do not replay it.')
            summary = [(job['job_id'], job['status'], job['index_id']) for job in receipt['jobs']]
            if summary != previous:
                print(json.dumps({'stage': 'waiting-for-exact-kd-readback', 'import_id': ident,
                                  'status': receipt['status'], 'jobs': summary}), flush=True)
                previous = summary
            time.sleep(min(3, max(0, self.deadline - time.monotonic())))
            receipt = self.request('/api/imports/' + ident + '/poll', {})
        raise RuntimeError('Timed out waiting for the original import receipts. Retain their native IDs; do not resubmit input.')

    def exact_import_readback(self, receipt):
        records = []
        by_database = {}
        for job in receipt['jobs']:
            if job['action'] != 'DREADDDATA':
                continue
            database = job['database_name']
            if database not in by_database:
                result = self.client.query('*', database=database, limit=10000, print_fields=True)
                require(result['total'] == len(result['hits']) <= 10000, 'Independent import readback is incomplete.')
                by_database[database] = result['hits']
            hits = [row for row in by_database[database] if row.get('reference') == job['reference']]
            require(len(hits) == 1 and hits[0]['database'].casefold() == database.casefold(),
                    'The exact immutable import reference did not read back from its dedicated database.')
            fields = hits[0].get('fields', {})
            payload = json.loads(fields.get('fe_import_payload', ''))
            require(fields.get('fe_import_sha256') == digest(canonical(payload)) and fields.get('fe_import_id') == receipt['import_id'],
                    'The independently read import payload hash or import identity differs.')
            if receipt['kind'] == 'csv':
                expected = [row['sample'] for row in receipt['rows']['accepted_rows']]
                expected.sort(key=lambda row: row['timestamp'])
                require(payload.get('schema') == 'fleet.sensor.v1' and payload.get('synthetic') is True
                        and payload.get('asset_id') == self.r['exercise_ids']['equipment_id']
                        and payload.get('source_id') == self.r['exercise_ids']['source_id']
                        and payload.get('samples') == expected,
                        'KD imported readings differ from every accepted synthetic input sample.')
            else:
                document = self.request('/api/documents/' + receipt['document_id'])
                require(payload.get('schema') == 'fleet.import.document.v1' and payload.get('document_id') == receipt['document_id']
                        and payload.get('metadata') == receipt['metadata'] and payload.get('text') == document['text']
                        and payload.get('original_sha256') == receipt['original_sha256']
                        and hits[0].get('text', '').strip() == document['text'].strip(),
                        'KD document metadata, original hash, payload or searchable text differs from retained input.')
            records.append({'database': database, 'reference': job['reference'], 'payload_sha256': digest(canonical(payload))})
        self.check('independent-kd-readback-' + receipt['kind'], bool(records), records=records)
        return records

    def exercise_workflow(self):
        token = uuid.uuid4().hex[:12]
        asset, part, source = 'QA-' + token.upper(), 'QA-PART-' + token.upper(), 'qa-import-' + token
        self.r['exercise_ids'] = {'equipment_id': asset, 'part_id': part, 'source_id': source,
                                  'retention': 'All synthetic acceptance records intentionally remain available for review.'}
        self.save()
        self.stage('registering-distinct-fictional-equipment-and-catalog-part')
        fit = {'model': 'QA-PUMP-' + token.upper(), 'configuration': 'SYNTHETIC-ACCEPTANCE'}
        equipment = self.request('/api/registry/equipment', {'id': asset, 'name': 'Synthetic onboarding acceptance pump ' + token,
                                 **fit, 'kind': 'pump', 'location': 'Fictional acceptance bench', 'synthetic_demo': True,
                                 'description': 'Synthetic acceptance fixture only; no physical equipment or customer data.'})
        self.check('arbitrary-equipment-created-without-code-change', equipment.get('id') == asset)
        self.request('/api/registry/parts', {'id': part, 'name': 'Synthetic acceptance bearing',
                     'manufacturer': 'Fictional acceptance manufacturer', 'part_number': 'TEST-' + token,
                     'applicability': [fit]})
        self.request('/api/registry/stock', {'part_id': part, 'location': 'Fictional spare locker', 'quantity': 3})
        installed_at = (datetime.now(timezone.utc) - timedelta(days=2)).isoformat().replace('+00:00', 'Z')
        replaced_at = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat().replace('+00:00', 'Z')
        installed = self.request('/api/registry/install', {'equipment_id': asset, 'part_id': part, 'serial': 'TEST-OLD-' + token,
                                 'position': 'Illustrative bearing position', 'installed_at': installed_at,
                                 'notes': 'Synthetic acceptance installation; spare stock is separately recorded.'})
        replacement = self.request('/api/registry/replace', {'component_id': installed['id'], 'part_id': part,
                                   'serial': 'TEST-NEW-' + token, 'installed_at': replaced_at,
                                   'notes': 'Synthetic replacement history; no repair effectiveness claim.'})
        detail = self.request('/api/registry/equipment/' + asset)
        old = next(row for row in detail['components'] if row['id'] == installed['id'])
        self.check('replacement-retains-old-installed-item', old.get('removed_at') and old.get('replaced_by') == replacement['id']
                   and len(detail['installed_components']) == 1 and detail['installed_components'][0]['id'] == replacement['id'])
        catalog = next(row for row in self.request('/api/registry/parts')['parts'] if row['id'] == part)
        self.check('catalog-installed-and-spare-counts-remain-distinct', catalog.get('installed_quantity') == 1
                   and len(catalog['spare_stock']) == 1 and catalog['spare_stock'][0]['quantity'] == 3)
        self.stage('previewing-mixed-csv-and-importing-accepted-synthetic-readings')
        mapping = {'asset_id': 'equipment', 'timestamp': 'utc_time', 'quality': 'quality', 'vibration_mm_s': 'vibration',
                   'temperature_c': 'temperature', 'pressure_bar': 'pressure', 'rpm': 'speed', 'load_pct': 'load'}
        self.request('/api/source-configs', {'source_id': source, 'label': 'Synthetic acceptance CSV ' + token,
                     'kind': 'csv', 'synthetic': True, 'expected_interval_seconds': 300, 'mapping': mapping})
        base_time = datetime.now(timezone.utc) - timedelta(minutes=4)
        stamps = [(base_time + timedelta(minutes=index)).isoformat(timespec='seconds').replace('+00:00', 'Z') for index in range(4)]
        good1 = ','.join((asset, stamps[0], 'good', '2.1', '50', '3.2', '1780', '65'))
        good2 = ','.join((asset, stamps[1], 'good', '2.2', '51', '3.1', '1782', '66'))
        invalid = ','.join((asset, stamps[2], 'good', 'not-a-number', '50', '3.2', '1780', '65'))
        unknown = ','.join(('UNREGISTERED-' + token, stamps[3], 'good', '2.1', '50', '3.2', '1780', '65'))
        content = ','.join(mapping.values()) + '\n' + '\n'.join((good1, good2, invalid, unknown, good1)) + '\n'
        csv_input = {'kind': 'csv', 'source_id': source, 'filename': 'synthetic-acceptance-' + token + '.csv',
                     'content': content, 'mapping': mapping}
        preview = self.request('/api/imports/preview', csv_input)
        self.check('mapped-preview-identifies-good-bad-and-duplicate-rows',
                   (preview.get('accepted_count'), preview.get('rejected_count'), preview.get('duplicate_count')) == (2, 2, 1)
                   and all(row.get('reasons') for row in preview['rejected_rows']))
        receipt = self.wait_receipt(self.request('/api/imports/commit', csv_input))
        self.r['csv_receipt'] = receipt
        self.save()
        csv_records = self.exact_import_readback(receipt)
        # Replay of identical input tests application idempotency after settled
        # readback. It must return the same receipt and produce no new references.
        replay = self.request('/api/imports/commit', csv_input)
        self.check('identical-csv-reuses-original-receipt', replay.get('import_id') == receipt['import_id']
                   and replay.get('status') == 'verified' and replay.get('jobs') == receipt.get('jobs'))
        self.stage('retaining-and-indexing-an-explicitly-applicable-synthetic-manual')
        manual = ('<h1>Synthetic onboarding acceptance manual</h1>\r\n'
                  '<p>Fictional equipment ' + asset + '. Inspect the illustrative bearing before review.</p>'
                  '<script>window.syntheticAcceptanceShouldNotExecute=true;</script>')
        doc_input = {'kind': 'document', 'filename': 'synthetic-manual-' + token + '.html', 'content': manual,
                     'metadata': {'title': 'Synthetic acceptance manual ' + token, 'revision': 'TEST-R1',
                                  'document_type': 'manual', 'asset_ids': [asset]}}
        doc_receipt = self.wait_receipt(self.request('/api/imports/commit', doc_input))
        self.r['document_receipt'] = doc_receipt
        self.save()
        doc_records = self.exact_import_readback(doc_receipt)
        document = self.request('/api/documents/' + doc_receipt['document_id'])
        original = self.request('/api/documents/' + doc_receipt['document_id'] + '/original', binary=True)
        self.check('safe-preview-and-exact-original-retention', original == manual.encode('utf-8')
                   and document.get('original_sha256') == digest(original) and 'syntheticAcceptanceShouldNotExecute' not in document['text']
                   and asset in document.get('applicable_asset_ids', []))
        attached = self.request('/api/registry/manuals', {'equipment_id': asset, 'reference': doc_receipt['document_id']})
        self.check('manual-attached-with-retained-revision-and-applicability', attached.get('revision') == 'TEST-R1'
                   and attached.get('model') == fit['model'] and attached.get('configuration') == fit['configuration'])
        saved_source = next(row for row in self.request('/api/source-configs')['sources'] if row['source_id'] == source)
        self.check('source-health-records-reception-readback-and-rejections', saved_source.get('mapping') == mapping
                   and saved_source.get('last_received_at') and saved_source.get('last_verified_at')
                   and saved_source.get('latest_reading_at') == stamps[1] and saved_source.get('rejected_count') == 2
                   and saved_source.get('prediction_status') == 'observation_only')
        overview = self.request('/api/fleet')
        fleet_asset = next(row for row in overview['equipment'] if row['id'] == asset)
        self.check('expanded-fleet-shows-imported-observation-without-pump-prediction', fleet_asset.get('condition', {}).get('status') == 'observed'
                   and fleet_asset.get('source_id') == source and fleet_asset.get('last_verified_at'))
        # Re-read persisted records through fresh HTTP requests, without claiming
        # that this helper restarted the service or tested host reboot.
        reread = self.request('/api/registry/equipment/' + asset)
        self.check('equipment-history-and-manual-remain-retrievable', len(reread['components']) == 2
                   and any(item['reference'] == doc_receipt['document_id'] for item in reread['manuals']))
        additions = {}
        for record in csv_records + doc_records:
            additions.setdefault(record['database'], []).append(record['reference'])
        return additions

    def run(self):
        self.prepare()
        before = self.capture()
        self.r['before'] = before
        self.save()
        self.stage('checking-new-read-only-api-surfaces')
        self.readonly_checks()
        additions = self.exercise_workflow() if self.exercise else {}
        self.stage('verifying-preserved-state-kd-inventory-and-container-lifecycles')
        after = self.capture()
        self.r['after'] = after
        self.save()
        self.check('all-existing-durable-rows-and-schemas-preserved', preserved_rows(before['state'], after['state'], self.exercise))
        self.check('kd-inventory-matches-only-explicit-import-additions', preserved_databases(before['databases'], after['databases'], additions),
                   explicit_additions=additions)
        self.check('existing-container-identities-and-start-times-preserved', before['containers'] == after['containers'])
        self.check('existing-case-inventory-and-paused-mission-preserved', before['cases'] == after['cases'] and before['mission'] == after['mission'])
        self.check('service-unit-remains-unchanged', UNIT.read_bytes() == self.unit_raw)
        self.r.update(complete=True, passed=True, completed_at=now(),
                      persistent_records_retained=True, service_restart_test=False)
        self.stage('onboarding-' + ('synthetic-exercise' if self.exercise else 'read-only') + '-accepted')

    def execute(self):
        try:
            self.run()
            return 0
        except BaseException as error:
            self.r.update(complete=False, passed=False,
                          error={'type': type(error).__name__, 'message': str(error)[:600]},
                          failure_policy='No cleanup, input replay, mission control, service restart or cache sync. Inspect the retained mutation/import receipts before any further action.')
            self.save()
            print(json.dumps({'complete': False, 'report': str(self.path), 'error': self.r['error']}), flush=True)
            return 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True, help='Fresh private JSON acceptance receipt.')
    parser.add_argument('--exercise', action='store_true', help='Explicitly create and retain a unique synthetic registry/import demonstration through the app.')
    parser.add_argument('--timeout', type=int, default=600, help='Total bounded runtime in seconds (60–900).')
    args = parser.parse_args()
    require(sys.platform == 'linux' and os.geteuid() == 0, 'Run the installed verifier as Linux root for protected read-only state inspection.')
    require(60 <= args.timeout <= 900, 'Timeout must be 60–900 seconds.')
    return Verification(args.output, args.exercise, args.timeout).execute()


if __name__ == '__main__':
    raise SystemExit(main())
