"""Evaluate the unchanged demo rule on separately authored synthetic trajectories.

This is a stress benchmark, not equipment validation or a trained-model test set.
The generator below never calls telemetry.simulate or telemetry._normalize. Its
latent reference vibration is retained only for outcome scoring. The analyzer
receives a bounded prefix of measurements at each issue time, never the future.
No fitting, parameter selection or threshold tuning occurs in this program.
"""

import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
import math
from pathlib import Path
import random
import statistics

import telemetry


PROTOCOL_VERSION = 'fleet-synthetic-evaluation-v1'
GENERATOR_VERSION = 'independent-pump-trajectories-v1'
SEEDS = (731, 1429, 2203, 3251, 4421, 5501)
FAMILIES = ('steady', 'load_cycle', 'linear_degradation', 'accelerating_degradation',
            'abrupt_change', 'sensor_bias', 'missing_during_degradation',
            'repaired_before_crossing', 'unsuccessful_repair', 'nonlinear_context')
DURATION_MINUTES = 300
WINDOW_SAMPLES = 181
HORIZON_MINUTES = 120
USEFUL_LEAD_MINUTES = 10
TARGET_MM_S = 4.3
FIRST_SCORE_MINUTE = 19
START = datetime(2026, 9, 8, tzinfo=timezone.utc)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     allow_nan=False).encode()).hexdigest()


def trajectory(family, seed):
    """Return a complete observed series and a separate synthetic outcome series.

    Plant/context coefficients deliberately differ from the demo correction;
    latent reference vibration excludes measurement noise, bias and load effects.
    Every trajectory lasts 300 minutes, including event/non-event follow-up.
    """
    if family not in FAMILIES or isinstance(seed, bool) or not isinstance(seed, int):
        raise ValueError('An evaluation family and integer seed are required.')
    rng = random.Random(f'{GENERATOR_VERSION}:{family}:{seed}')
    base = rng.uniform(1.7, 2.2)
    onset = rng.randint(30, 50)
    rate = rng.uniform(.019, .033)
    load_coefficient = rng.uniform(.012, .033)
    speed_coefficient = rng.uniform(.00025, .00115)
    noise_sigma = rng.uniform(.02, .07)
    phase = rng.uniform(0, math.tau)
    intervention = onset + rng.randint(38, 48)
    abrupt_minute = rng.randint(100, 140)
    latent = []
    for minute in range(DURATION_MINUTES + 1):
        age = max(0, minute - onset)
        if family in ('linear_degradation', 'missing_during_degradation'):
            drift = rate * age
        elif family == 'accelerating_degradation':
            drift = .00015 * age ** 2
        elif family == 'abrupt_change':
            drift = 2.9 if minute >= abrupt_minute else 0
        elif family == 'repaired_before_crossing':
            drift = rate * age if minute <= intervention else rate * (intervention - onset) * math.exp(-(minute - intervention) / 13)
        elif family == 'unsuccessful_repair':
            drift = rate * age - (.55 * math.exp(-(minute - intervention) / 24) if minute >= intervention else 0)
        else:
            drift = 0
        latent.append(round(base + drift, 6))
    crossing = next((i for i, value in enumerate(latent) if value >= TARGET_MM_S), None)
    samples = []
    for minute, reference in enumerate(latent):
        load = 57 + 8 * math.sin(minute / 23 + phase)
        speed = 1760 + 95 * math.sin(minute / 31 + phase)
        if family in ('load_cycle', 'nonlinear_context'):
            pulse = max(0, min(1, (minute - 55) / 25, (230 - minute) / 25))
            load += 35 * pulse
            speed += 430 * pulse
        context = load_coefficient * (load - 60) + speed_coefficient * (speed - 1800)
        if family == 'nonlinear_context':
            context += .00095 * max(load - 60, 0) ** 2
        bias = .034 * max(0, minute - 75) if family == 'sensor_bias' else 0
        row = {
            'timestamp': (START + timedelta(minutes=minute)).isoformat(timespec='seconds').replace('+00:00', 'Z'),
            'vibration_mm_s': round(reference + context + bias + rng.gauss(0, noise_sigma), 6),
            'temperature_c': round(61 + .09 * (load - 60) + 3.1 * (reference - base) + rng.gauss(0, .2), 6),
            'pressure_bar': round(5.5 + .004 * (load - 60) - .19 * (reference - base) + rng.gauss(0, .025), 6),
            'rpm': round(speed, 6), 'load_pct': round(load, 6), 'quality': 'good',
        }
        if family == 'missing_during_degradation' and crossing - 20 <= minute <= crossing + 8:
            row['quality'] = 'missing' if minute % 2 else 'suspect'
            if row['quality'] == 'missing':
                row.update({field: None for field in telemetry.SIGNALS})
        samples.append(row)
    return {
        'id': f'{family}-{seed}', 'family': family, 'seed': seed,
        'samples': samples, 'latent_reference_vibration_mm_s': latent,
        'first_target_crossing_minute': crossing,
        'parameters': {'base_mm_s': base, 'onset_minute': onset, 'drift_mm_s_per_minute': rate,
                       'load_coefficient': load_coefficient, 'speed_coefficient': speed_coefficient,
                       'noise_sigma_mm_s': noise_sigma, 'phase': phase,
                       'intervention_minute': intervention, 'abrupt_minute': abrupt_minute},
    }


def threshold_baseline(analysis):
    """Review-threshold detector sharing the model's quality/context processing.

    It has no trend projection and never warns before its adjusted measurement
    reaches 4.3 mm/s. Sharing preprocessing isolates the incremental warning rule.
    """
    adjusted = analysis['latest']['normalized_vibration_mm_s']
    return analysis['status'] != 'insufficient' and adjusted is not None and adjusted >= TARGET_MM_S


def score_alerts(alert_minutes, crossing):
    """One target event per trajectory; match alerts within 120 minutes before it."""
    if crossing is None:
        return {'false_alert_without_event': bool(alert_minutes), 'detected_by_crossing': None,
                'useful_warning': None, 'lead_minutes': None, 'first_alert_minute': next(iter(alert_minutes), None)}
    matched = [minute for minute in alert_minutes if max(0, crossing - HORIZON_MINUTES) <= minute <= crossing]
    lead = crossing - matched[0] if matched else None
    return {'false_alert_without_event': False, 'detected_by_crossing': bool(matched),
            'useful_warning': lead is not None and lead >= USEFUL_LEAD_MINUTES,
            'lead_minutes': lead, 'first_alert_minute': next(iter(alert_minutes), None)}


def evaluate_trajectory(item, analyzer=None):
    analyzer = analyzer or telemetry.analyze_samples
    samples = item['samples']
    crossing = item['first_target_crossing_minute']
    model_alerts, baseline_alerts, forecasts, reasons = [], [], [], {}
    condition_abstentions = forecast_opportunities = forecast_abstentions = 0
    for minute in range(FIRST_SCORE_MINUTE, len(samples)):
        # A copy isolates the recorded trajectory even from a mutating analyzer.
        window = [dict(row) for row in samples[max(0, minute - WINDOW_SAMPLES + 1):minute + 1]]
        analysis = analyzer(window, synthetic=True)
        forecast = analysis['forecast']
        if analysis['status'] in ('watch', 'review') or forecast['available']:
            model_alerts.append(minute)
        if threshold_baseline(analysis):
            baseline_alerts.append(minute)
        if analysis['status'] == 'insufficient':
            condition_abstentions += 1
        # The forecast denominator includes every pre-target issue time with a
        # complete 120-minute outcome horizon, including missing/bad observations.
        if minute + HORIZON_MINUTES < len(samples) and (crossing is None or minute < crossing):
            forecast_opportunities += 1
            if not forecast['available']:
                forecast_abstentions += 1
                reason = forecast['reason']
                reasons[reason] = reasons.get(reason, 0) + 1
        if forecast['available'] and (crossing is None or minute < crossing):
            predicted = minute + forecast['minutes_to_review']
            forecasts.append({'issued_minute': minute, 'predicted_crossing_minute': round(predicted, 6),
                              'error_minutes': round(predicted - crossing, 6) if crossing is not None and crossing <= minute + HORIZON_MINUTES else None,
                              'complete_horizon': minute + HORIZON_MINUTES < len(samples),
                              'target_within_horizon': crossing is not None and minute < crossing <= minute + HORIZON_MINUTES})
    matched_forecasts = [row for row in forecasts if row['error_minutes'] is not None]
    return {
        'trajectory_id': item['id'], 'family': item['family'], 'seed': item['seed'],
        'sample_count': len(samples), 'trajectory_sha256': digest(item),
        'first_target_crossing_minute': crossing, 'parameters': item['parameters'],
        'model': score_alerts(model_alerts, crossing),
        'threshold_baseline': score_alerts(baseline_alerts, crossing),
        'condition_opportunities': len(samples) - FIRST_SCORE_MINUTE,
        'condition_abstentions': condition_abstentions,
        'forecast_opportunities_with_complete_followup': forecast_opportunities,
        'forecast_abstentions': forecast_abstentions,
        'forecast_abstention_reasons': reasons,
        'forecast_count': len(forecasts),
        'first_matched_forecast_error_minutes': matched_forecasts[0]['error_minutes'] if matched_forecasts else None,
        'matched_forecast_count': len(matched_forecasts),
        'false_forecasts_with_complete_followup': sum(row['complete_horizon'] and not row['target_within_horizon'] for row in forecasts),
        'forecasts': forecasts,
    }


def ratio(numerator, denominator):
    return round(numerator / denominator, 6) if denominator else None


def summarize(rows):
    event_rows = [row for row in rows if row['first_target_crossing_minute'] is not None]
    non_event_rows = [row for row in rows if row['first_target_crossing_minute'] is None]
    result = {'trajectories': len(rows), 'target_events': len(event_rows),
              'no_target_event_trajectories': len(non_event_rows)}
    for key in ('model', 'threshold_baseline'):
        missed = sum(not row[key]['detected_by_crossing'] for row in event_rows)
        false = sum(row[key]['false_alert_without_event'] for row in non_event_rows)
        useful = sum(row[key]['useful_warning'] for row in event_rows)
        leads = [row[key]['lead_minutes'] for row in event_rows if row[key]['lead_minutes'] is not None]
        result[key] = {
            'false_alert_trajectories_without_event': false,
            'false_alert_rate_among_no_event_trajectories': ratio(false, len(non_event_rows)),
            'missed_events_by_crossing': missed, 'missed_event_rate': ratio(missed, len(event_rows)),
            'events_with_at_least_10_minutes_warning': useful,
            'useful_warning_rate': ratio(useful, len(event_rows)),
            'median_lead_minutes_among_detected_events': statistics.median(leads) if leads else None,
        }
    errors = [row['first_matched_forecast_error_minutes'] for row in event_rows if row['first_matched_forecast_error_minutes'] is not None]
    opportunities = sum(row['forecast_opportunities_with_complete_followup'] for row in rows)
    abstentions = sum(row['forecast_abstentions'] for row in rows)
    condition_opportunities = sum(row['condition_opportunities'] for row in rows)
    result['forecast'] = {
        'events_with_a_matched_forecast': len(errors),
        'first_matched_forecast_mean_absolute_error_minutes': round(statistics.mean(map(abs, errors)), 6) if errors else None,
        'first_matched_forecast_mean_signed_error_minutes': round(statistics.mean(errors), 6) if errors else None,
        'opportunities_with_complete_followup': opportunities, 'abstentions': abstentions,
        'abstention_rate': ratio(abstentions, opportunities),
        'false_forecasts_with_complete_followup': sum(row['false_forecasts_with_complete_followup'] for row in rows),
        'condition_abstention_rate': ratio(sum(row['condition_abstentions'] for row in rows), condition_opportunities),
    }
    return result


def run_evaluation(seeds=SEEDS, families=FAMILIES):
    seeds, families = tuple(seeds), tuple(families)
    if not seeds or len(set(seeds)) != len(seeds) or not families or len(set(families)) != len(families):
        raise ValueError('Choose nonempty, unique seeds and families.')
    # This records the existing rule before any predictions. It never edits it.
    model_path = Path(telemetry.__file__)
    model_hash = hashlib.sha256(model_path.read_bytes()).hexdigest()
    rows = [evaluate_trajectory(trajectory(family, seed)) for family in families for seed in seeds]
    if hashlib.sha256(model_path.read_bytes()).hexdigest() != model_hash:
        raise RuntimeError('The model changed during evaluation; discard this run.')
    return {
        'protocol_version': PROTOCOL_VERSION, 'generator_version': GENERATOR_VERSION,
        'model_version': telemetry.MODEL_VERSION, 'model_source_sha256': model_hash,
        'evaluation_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'synthetic_only': True, 'model_tuned_during_evaluation': False,
        'seeds': list(seeds), 'families': list(families),
        'duration_minutes': DURATION_MINUTES, 'observation_window_samples': WINDOW_SAMPLES,
        'target': 'First latent reference-vibration crossing of the authored 4.3 mm/s review threshold; not equipment failure.',
        'definitions': {
            'independence': 'Full trajectories are authored separately from telemetry.simulate. This rule has no training phase. The benchmark is a fixed stress suite, not unseen customer data or externally blinded validation.',
            'ground_truth': 'Latent reference vibration excludes load effects, noise and sensor bias; it is available only to scoring. All complete trajectories have a 300-minute observation horizon.',
            'model_alert': 'Status watch/review or an available trend forecast; evaluated at each minute starting with minute 19.',
            'baseline_alert': 'Adjusted current vibration at least 4.3 mm/s after the same model quality/context preprocessing; no projection.',
            'event_matching': 'Any alert from 120 minutes before the first target crossing through the crossing minute. Later alerts count as missed by crossing. Useful warning requires at least 10 minutes.',
            'false_alert_rate': 'Fraction of complete trajectories with no target crossing that produce any alert; not per-hour alarm frequency. This is target-specific: a review warning can still be reasonable when a later intervention prevents crossing.',
            'forecast_error': 'One error per event: the first issued forecast within 120 minutes of the true crossing. Signed error is predicted minus actual minute; error excludes non-events/misses and must be read with their rates.',
            'forecast_abstention': 'No forecast at a pre-crossing issue time with 120 complete minutes of outcome follow-up, including missing data; often appropriate, not intrinsically an error.',
            'false_forecasts': 'Forecast issues with complete 120-minute follow-up and no target crossing in that horizon; repeated issues are correlated, not independent event counts.',
            'baseline_forecast': 'The baseline does not forecast; crossing-time error and forecast availability are not applicable to it.',
        },
        'limitations': [
            'Small authored synthetic stress suite; no real equipment, PACFLT data, failure labels or operational maintenance limits.',
            'Benchmark design was informed by the existing rule; separately authored does not imply an independently blinded study.',
            'Complete trajectories, not adjacent windows, form the evaluation units. No training, validation split, tuning or equipment-specific calibration is performed.',
            'Sensor-bias and unfamiliar load effects can appear as degradation to this vibration-only rule. Outcome truth is known solely because this is a simulation.',
            'Forecasts have no calibrated uncertainty interval. Point error does not imply reliability, failure probability or remaining useful life.',
            'Intervention branches are authored scenarios; improvement after an intervention is not causal evidence of repair effectiveness.',
            'The repair-before-crossing branch counts as a non-event. Its earlier warning is false against the eventual crossing target, not proof that requesting review was inappropriate.',
            'Repeated per-minute forecasts are dependent. Main false-alert/miss and first-forecast error summaries use trajectory/event units.',
        ],
        'summary': summarize(rows),
        'by_family': {family: summarize([row for row in rows if row['family'] == family]) for family in families},
        'trajectories': rows,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = run_evaluation()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({'report': str(args.output.resolve()), **report['summary']}, indent=2))


if __name__ == '__main__':
    main()
