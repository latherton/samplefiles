"""Read bounded sensor snapshots from a separate KD Content database.

This is a normalized-record bridge, not a direct equipment protocol driver.
No document manifest, simulated fallback, or KD write is used here.
"""
from datetime import datetime, timezone
import hashlib
import json
import math
import os
import re

from kd_client import BACKEND, KDError

SCHEMA = 'fleet.sensor.v1'
DEFAULT_DATABASE = 'FLEET_SENSOR_DEMO'
MAX_SAMPLES = 181
MAX_RECORDS = 1000
MAX_PAYLOAD_BYTES = 128 * 1024
METRICS = ('vibration_mm_s', 'temperature_c', 'pressure_bar', 'rpm', 'load_pct')
UNITS = {'vibration_mm_s': 'mm/s RMS', 'temperature_c': 'degC', 'pressure_bar': 'bar',
         'rpm': 'rev/min', 'load_pct': '%'}
ASSETS = frozenset({'A-17', 'A-18'})
_SOURCE = re.compile(r'[a-z][a-z0-9_-]{0,63}\Z')
_UTC = re.compile(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?Z\Z')


def sensor_database(value=None):
    value = os.getenv('KD_SENSOR_DATABASE', DEFAULT_DATABASE) if value is None else value
    if (not isinstance(value, str) or not re.fullmatch(r'[A-Z][A-Z0-9_]{0,63}', value)
            or value.casefold() in {'default', 'archive', 'fleet_evidence_demo'}):
        raise ValueError('KD_SENSOR_DATABASE must name a dedicated uppercase sensor database; Default, Archive and FLEET_EVIDENCE_DEMO are prohibited.')
    return value


def source_identifier(value):
    if not isinstance(value, str) or not _SOURCE.fullmatch(value):
        raise ValueError('source_id must be a lowercase identifier of 1–64 letters, digits, underscores or hyphens, starting with a letter.')
    return value


def asset_identifier(value):
    if not isinstance(value, str) or value not in ASSETS:
        raise ValueError('Sensor asset_id must be A-17 or A-18.')
    return value


def utc_timestamp(value):
    if not isinstance(value, str) or not _UTC.fullmatch(value):
        raise ValueError('Sensor timestamps must be UTC ISO 8601 strings ending in Z, with seconds and at most six fractional digits.')
    try:
        return datetime.fromisoformat(value[:-1] + '+00:00')
    except ValueError as exc:
        raise ValueError('Sensor timestamp has an invalid calendar date or time.') from exc


def canonical(payload):
    return json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(',', ':'), allow_nan=False)


def payload_hash(payload):
    return hashlib.sha256(canonical(payload).encode('utf-8')).hexdigest()


def reference_for(source_id, asset_id):
    return 'urn:fleet-sensor:' + source_identifier(source_id) + ':' + asset_identifier(asset_id)


def _object(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError('Sensor JSON contains a repeated object key.')
        obj[key] = value
    return obj


def load_json(raw):
    if not isinstance(raw, (str, bytes)) or len(raw.encode('utf-8') if isinstance(raw, str) else raw) > MAX_PAYLOAD_BYTES:
        raise ValueError('Sensor payload is missing or exceeds the 128 KiB bound.')
    def bad_constant(value):
        raise ValueError('Sensor JSON cannot contain non-finite numeric constants.')
    try:
        return json.loads(raw, object_pairs_hook=_object, parse_constant=bad_constant)
    except (json.JSONDecodeError, UnicodeError, RecursionError) as exc:
        raise ValueError('Sensor payload is not valid bounded JSON.') from exc


def validate_snapshot(payload):
    """Return a fresh canonical-shaped snapshot; never sort or fill missing input."""
    keys = {'schema', 'source_id', 'asset_id', 'synthetic', 'samples'}
    if not isinstance(payload, dict) or set(payload) != keys or payload.get('schema') != SCHEMA:
        raise ValueError('Sensor snapshot must have exactly the fleet.sensor.v1 contract fields.')
    source_identifier(payload['source_id'])
    asset_identifier(payload['asset_id'])
    if type(payload['synthetic']) is not bool:
        raise ValueError('Sensor synthetic must be the JSON boolean true or false.')
    samples = payload['samples']
    if not isinstance(samples, list) or not 1 <= len(samples) <= MAX_SAMPLES:
        raise ValueError('A complete sensor snapshot must contain 1–181 samples.')
    normalized, prior = [], None
    for sample in samples:
        if not isinstance(sample, dict) or set(sample) != {'timestamp', 'quality', *METRICS}:
            raise ValueError('Every sensor sample must contain timestamp, quality and all five metric fields.')
        stamp = utc_timestamp(sample['timestamp'])
        if prior is not None and stamp <= prior:
            raise ValueError('Sensor timestamps must be strictly increasing; repeated or conflicting equal timestamps are not accepted.')
        prior = stamp
        if sample['quality'] not in ('good', 'missing', 'suspect'):
            raise ValueError('Sensor quality must be good, missing or suspect.')
        for name in METRICS:
            value = sample[name]
            try:
                valid_number = type(value) in (int, float) and math.isfinite(value)
            except OverflowError:
                valid_number = False
            if value is not None and not valid_number:
                raise ValueError('Sensor metric ' + name + ' must be a finite JSON number or null, never a boolean.')
        if sample['quality'] == 'good' and any(sample[name] is None for name in METRICS):
            raise ValueError('A sample with missing values cannot be labeled good.')
        normalized.append(dict(sample))
    result = {key: payload[key] for key in ('schema', 'source_id', 'asset_id', 'synthetic')}
    result['samples'] = normalized
    if len(canonical(result).encode()) > MAX_PAYLOAD_BYTES:
        raise ValueError('Sensor snapshot exceeds the bounded payload size.')
    return result


class SensorKD:
    def __init__(self, client, database=None):
        self.client = client
        self.database = sensor_database(database)

    def records(self):
        """Retrieve and validate the complete bounded database, without truncation."""
        result = self.client.query('*', database=self.database, limit=MAX_RECORDS, print_fields=True)
        if (not isinstance(result, dict) or type(result.get('total')) is not int
                or not isinstance(result.get('hits'), list) or result['total'] != len(result['hits'])
                or not 0 <= result['total'] <= MAX_RECORDS):
            raise KDError('Sensor query is incomplete or exceeds 1,000 snapshot records; no truncated series is shown.', 'sensor_results_incomplete')
        rows = []
        try:
            for hit in result['hits']:
                if not isinstance(hit, dict) or str(hit.get('database', '')).casefold() != self.database.casefold():
                    raise KDError('Sensor KD returned a record outside the configured database.', 'sensor_scope_error')
                fields = hit.get('fields')
                if not isinstance(fields, dict):
                    raise ValueError('Sensor record metadata is absent.')
                payload = validate_snapshot(load_json(fields.get('fe_sensor_payload')))
                required = {'fe_sensor_schema': SCHEMA, 'fe_sensor_source_id': payload['source_id'],
                            'fe_sensor_asset_id': payload['asset_id'],
                            'fe_sensor_synthetic': str(payload['synthetic']).lower()}
                if any(fields.get(key) != expected for key, expected in required.items()):
                    raise ValueError('Sensor record metadata and JSON payload disagree.')
                if hit.get('reference') != reference_for(payload['source_id'], payload['asset_id']):
                    raise ValueError('Sensor snapshot has an unexpected source reference.')
                if fields.get('fe_sensor_sha256', payload_hash(payload)) != payload_hash(payload):
                    raise ValueError('Sensor payload hash does not match its stored record.')
                rows.append({'payload': payload, 'reference': hit['reference'],
                             'latest_timestamp': payload['samples'][-1]['timestamp']})
        except (ValueError, TypeError, KeyError, OverflowError) as exc:
            raise KDError('Sensor KD record failed contract validation: ' + str(exc), 'sensor_record_invalid') from exc
        # A single source cannot silently switch between simulated and real origin.
        origins = {}
        for row in rows:
            data = row['payload']
            if data['source_id'] in origins and origins[data['source_id']] != data['synthetic']:
                raise KDError('Sensor source has conflicting synthetic/real origin labels.', 'sensor_origin_conflict')
            origins[data['source_id']] = data['synthetic']
        return rows

    @staticmethod
    def latest(rows):
        if not rows:
            raise KDError('No complete indexed sensor snapshot exists for this source and asset.', 'sensor_snapshot_missing')
        ordered = sorted(rows, key=lambda row: utc_timestamp(row['latest_timestamp']), reverse=True)
        newest = ordered[0]
        # Equal end times must identify exactly the same snapshot, not an arbitrary winner.
        for row in ordered[1:]:
            if utc_timestamp(row['latest_timestamp']) == utc_timestamp(newest['latest_timestamp']) and canonical(row['payload']) != canonical(newest['payload']):
                raise KDError('Sensor snapshots conflict at the latest timestamp; review the source before use.', 'sensor_timestamp_conflict')
        return newest

    def sources(self):
        rows = self.records()
        groups = {}
        for row in rows:
            groups.setdefault(row['payload']['source_id'], []).append(row)
        sources = []
        for source_id, group in sorted(groups.items()):
            # Validate ties within each asset. Different assets may legitimately share a time.
            assets = sorted({row['payload']['asset_id'] for row in group})
            for asset_id in assets:
                self.latest([row for row in group if row['payload']['asset_id'] == asset_id])
            synthetic = group[0]['payload']['synthetic']
            sources.append({'source_id': source_id,
                            'label': source_id + (' · synthetic via KD' if synthetic else ' · source-reported measurements via KD'),
                            'asset_ids': assets, 'synthetic': synthetic,
                            'latest_timestamp': max((row['latest_timestamp'] for row in group), key=utc_timestamp),
                            'record_count': len(group)})
        return {'available': True, 'database': self.database,
                'message': 'Live KD sensor snapshot inventory.' if sources else 'KD sensor database is available; no validated snapshots are indexed.',
                'sources': sources,
                'connection': {'configured': True, 'endpoint_label': 'Existing KD Content connection'}}

    def snapshot(self, source_id, asset_id):
        source_identifier(source_id)
        asset_identifier(asset_id)
        rows = [row for row in self.records() if row['payload']['source_id'] == source_id and row['payload']['asset_id'] == asset_id]
        newest = self.latest(rows)
        result = dict(newest['payload'])
        result['provenance'] = {'backend': BACKEND, 'database': self.database,
                                'reference': newest['reference'], 'source_id': source_id, 'asset_id': asset_id,
                                'synthetic': result['synthetic'], 'latest_timestamp': newest['latest_timestamp'],
                                'record_count': len(rows), 'sample_count': len(result['samples']),
                                'payload_sha256': payload_hash(newest['payload']),
                                'retrieved_at': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
                                'live': True}
        return result
