# Fleet Evidence: Mission Control presenter guide

This release adds a complete fictional maintenance episode. All asset readings, evidence, role labels and outcomes are synthetic demonstration material. The trend projects an authored review threshold; it is not a validated prediction of equipment failure.

## Before presenting

Open `http://localhost:8095` in Chrome **inside cdms-mgmt-01's remote Windows desktop**. The Fleet Evidence app has no separate login. AWS, Remote Desktop and the independent KD applications can each have their own session expiry. The local workspace guide `docs/demo-session-runbook.md` describes reconnecting with the existing authorized account.

Open **Mission control** and start **A-17 · Persistent change**. A-18 uses a load-change comparator. Allow several minutes for acquisition and KD commit before presenting the case: the observed Content configuration uses `MaxSyncDelay=120`, and the producer retains one pending publication at a time. The interface distinguishes acquired readings, a pending index job and the last window actually read back from KD. It never replaces a failed KD delivery with browser-generated data.

Acquisition runs in the application service independently of the browser. It records actual UTC timestamps; the underlying synthetic scenario advances one authored step per acquired reading. This is compressed demonstration time, not a recreation of the minute-spaced original replay. Missed ticks are not backfilled. Pause the source when the episode is ready, or leave it running to show incoming measurements.

## Tell the episode

1. **Signal:** Compare the two cards. Point out the source, quality, observation time, acquired count and last verified KD window. A delayed or missing measurement is a reason to withhold a conclusion.
2. **Case:** A verified watch/review condition opens one case for that asset/run. Open **Maintenance cases**. The opening window remains fixed; the latest available window is displayed separately. A planner can also explicitly capture a verified condition.
3. **Evidence:** Use **Find supporting evidence**. Inspect the source records and select the relevant guidance/history, preserving revision and applicability differences. Return to the case.
4. **Review:** Enter a fictional reviewer role, an evidence-based finding and the proposed reviewed action. Save the review with selected sources and planner notes. This stores the captured content and history; it does not submit a work order or control equipment.
5. **Follow-up:** With the source running, expand **Direct the synthetic scenario** and select **Trend eases**, **Change persists** or **Uncertain readings**. This explicitly authors the next fictional readings. Wait until a later window is verified in KD, then capture it with a follow-up note.
6. **Outcome:** Record a disposition and its rationale. Closure requires a saved review and a later observation window. An easing trend alone is not proof that the proposed action caused a repair. An inconclusive outcome is a valid demonstration result.
7. **Takeaway:** Export the case brief. The HTML contains the opening condition identity, captured evidence, review timeline and follow-up condition identities. Reload the browser and reopen the same case to demonstrate server persistence.

## Show the real-source boundary

**Data sources** remains the interface for already-normalized sensor records in KD. Download `fleet.sensor.v1`, map the source's units, timestamps, asset identity and quality, then deliver using the reviewed importer/integration route described in `SENSOR-SOURCES.md`. The mission producer uses its own `mission-pump-feed` source and preserves the original `demo-pump-replay` snapshots. The source selector is not a native historian or device protocol driver. Real-source records remain observation-only; synthetic thresholds are not applied to them.

## Persistence and recovery

The server retains cases and raw acquired history in the configured `FLEET_STATE_DIR`, outside versioned release directories. The remote deployment uses systemd `StateDirectory=fleet-evidence` at `/var/lib/fleet-evidence`, owned by `nobody:nogroup`. Restart resumes the state of an explicitly started source; a fresh installation begins idle. A pause stops new acquisition/windows while an already submitted native job can finish reconciliation.

Unknown index outcomes keep their original intent/receipt and block later writes. Do not reset state or submit the same request again to hide an uncertain result. A normal pending KD commit is visible and is polled by its retained native ID; the producer does not send `DRESYNC`.

## Model evidence

`evaluate_prognostics.py` evaluates the unchanged rule on separately authored complete synthetic trajectories. The initial 60-trajectory stress suite exposes both useful warnings and substantial false alerts/crossing error. Read `docs/synthetic-model-evaluation-2026-09-08.md` and its reproducible JSON report before presenting model quality. Those results are synthetic stress-test behavior, not operational accuracy or a claimed maintenance savings figure.
