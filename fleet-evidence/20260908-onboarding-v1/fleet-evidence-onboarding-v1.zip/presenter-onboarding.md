# Fleet Evidence: equipment and data onboarding presenter guide

This guide describes the new application increment. It is not a record of remote installation or live KD acceptance; use the dated release/build record for those results. The six initial registry entries are fictional. New equipment, parts, documents and reading sources are application records, not customer-approved configuration or inventory.

## Before presenting

Open the version being demonstrated and confirm **Fleet overview**, **Equipment & parts**, **Import workspace**, **Source setup & health** and **Model evidence** appear in navigation. The installed remote application is reached inside the existing owner desktop; use `docs/demo-session-runbook.md` to maintain the four-minute activity cadence and separate connection timers. Preserve the paused synthetic source and saved cases. This onboarding story does not require starting Mission control.

Prepare one small UTF-8 CSV and one text, Markdown or HTML manual. PDF and Office extraction are not connected to this import workspace. Use fictional material, and inspect the actual indexing result instead of rehearsing a guaranteed success state.

## Tell the onboarding story

1. **Fleet overview:** Show the six initially registered assets. Equipment without readings remains unassessed. Explain the review ordering: condition, missing/stale data, delivery problems and open cases. The queue is not a fleet-readiness score.
2. **Equipment & parts → Add equipment:** Register `A-19`, name `Auxiliary cooling pump`, model `P-200`, configuration `C`, location `Training space`. Leave **Fictional demonstration equipment** checked. Choose a different unique ID for a repeated rehearsal; do not overwrite retained records to reset the presentation.
3. **Add catalog part:** Create `DEMO-SEAL-C`, name `Training pump seal`, manufacturer `Fictional demo manufacturer`, part number `SEAL-C`. Declare model `P-200`, configuration `C`. This explicit entry establishes the demonstration fitment, not a vendor compatibility claim.
4. **Catalog & spares → Record stock:** Record quantity `3` at `Training locker`. Then **Installed components → Install component**, select the seal, enter serial `DEMO-S001` and position `Pump seal`. Show that one installed item and three separately recorded spares are different records. Installing does not automatically consume stock; record a stock change separately if it is part of the story.
5. **Manuals → Upload document:** Select `A-19`, enter title `A-19 training manual`, revision `DEMO-1`, and type **Manual**. Upload the prepared document and review its plain-text preview. Import it, inspect the receipt and its actual KD state, then return to A-19's **Manuals** tab. Open **Preview & original**, download the retained original, and **Attach as manual**. Applicability and indexing are distinct; an attachment is not a document-authority decision.
6. **Import workspace → CSV readings → Set up a source:** Save source ID `a19-training-csv`, name `A-19 training upload`, source type **CSV upload**, expected interval `300` seconds. Check the synthetic-readings box. Keep normalized column names, or enter the real column names from the prepared file. Normalized units are vibration `mm/s RMS`, temperature `degC`, pressure `bar`, speed `rev/min` and load `%`; this importer does not convert units.
7. **Preview & validate:** Choose the CSV and inspect all field mappings. Point out accepted, rejected and duplicate counts and the specific row errors. Change a mapping and use **Validate mapping** before importing. **Save mapping to source** retains the validated column selection for a later file.
8. **Import accepted rows:** Read the saved receipt. Accepted rows are retained locally before every KD job has necessarily finished. **Refresh receipt** reads the saved state; **Check KD delivery** reconciles retained native jobs. **Submit / resume indexing** is available for queued work when initial KD access was unavailable. An uncertain result retains its original intent and must not be hidden by importing or submitting a fresh copy. Only **Verified** establishes the exact readback for that receipt.
9. **Source setup & health:** Show expected cadence, last received time, latest reading time, last KD verification and rejected records. Old observations should remain visibly stale even if their upload just arrived. Saving an API/historian endpoint records connection metadata; it does not connect an acquisition adapter. Real-source observations do not receive the illustrative synthetic condition model.
10. **Replacement history:** Return to A-19, replace `DEMO-S001` with serial `DEMO-S002`, and record a fictional maintenance note. Open **History** and show the retained earlier installation/removal. Update spare stock separately if appropriate. A subsequent measurement change is an observation, not proof that the replacement caused improvement.
11. **Reopen and compare:** Refresh the browser and reopen A-19, its documents, source and import receipt. For restart acceptance, follow the release checklist and inspect actual preserved state. Use the existing **Maintenance cases** view to demonstrate its separate saved episode; this increment does not add arbitrary newly registered assets to the original A-17/A-18 condition/case analyzer.

## Small CSV for the validation step

Save the following as `a19-training-readings.csv`. With A-19 registered and a fresh source, the expected preview is **3 accepted, 2 rejected, 1 duplicate**. The timestamps are deliberately historical, so the source-health view should show stale readings. Replace them consistently with recent past UTC times if presenting freshness. Future timestamps more than 60 seconds ahead are rejected. Reimporting previously retained readings changes duplicate outcomes.

```csv
asset_id,timestamp,quality,vibration_mm_s,temperature_c,pressure_bar,rpm,load_pct
A-19,2026-09-07T10:00:00Z,good,2.1,52,4.2,1780,65
A-19,2026-09-07T10:01:00Z,good,2.2,53,4.2,1782,66
A-19,2026-09-07T10:02:00Z,good,2.3,53,4.1,1781,66
A-19,2026-09-07T10:02:00Z,good,2.3,53,4.1,1781,66
A-19,2026-09-07T10:03:00Z,good,not-a-number,54,4.1,1780,66
UNREGISTERED,2026-09-07T10:04:00Z,good,2.5,54,4.1,1780,66
```

A suitable short manual specimen is: “Fictional training reference for A-19, model P-200 configuration C. Revision DEMO-1. Confirm equipment identity and record inspection observations. This text contains no operational maintenance limits or approved repair procedure.”

## Model evidence: say exactly what was measured

**Model evidence** shows the frozen 60-trajectory synthetic stress suite and compares the illustrative rule with a current-threshold baseline. The reported target is an authored vibration review-threshold crossing, not equipment failure. The recorded model has false alerts on **18/30** non-event histories and at least ten minutes of warning for **24/30** target events; the threshold baseline has **6/30** false-alert histories and **0/30** useful warnings. The displayed report verifies its model/evaluator code hashes. Describe these as historical report results if either hash no longer matches.

No independent real equipment histories or adjudicated failure outcomes have been supplied. The separate `evaluate_histories.py` command prepares that evaluation path; it does not replace the displayed fixed report or enable predictions for live real sources. Input must be a JSON list of complete histories with unique `id`, `asset_id`, `partition: "held-out"`, provenance, minute-cadence samples, an explicitly supplied first `event_timestamp` or `null`, and `followup_end`. Preserve gaps as missing samples and establish outcome labels outside the model. Duplicate measurement histories and same-equipment overlapping intervals are rejected; provenance declarations do not prove independence.

Validate supplied histories first:

```powershell
python evaluate_histories.py --input histories.json --output history-validation.json --event-definition "First independently adjudicated event; describe the label protocol here"
```

An explicit offline study can opt into the uncalibrated demonstration rule:

```powershell
python evaluate_histories.py --input histories.json --output history-evaluation.json --event-definition "First independently adjudicated event; describe the label protocol here" --apply-demo-rule
```

The report records denominators, warnings, misses, false alarms, censored outcomes, exclusions and hashes. It does not establish equipment-specific calibration, independently verified labels, remaining useful life or repair effectiveness. Run commands from the application directory and keep the original histories separate from the output report.
